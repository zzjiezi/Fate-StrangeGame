package com.game.rpg.util.map;

import com.game.rpg.util.resource.ResourceLoader;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class SpriteManager {
    private static final Logger logger = LoggerFactory.getLogger(SpriteManager.class);

    private final ResourceLoader resourceLoader;
    private final Map<String, Image> cache = new HashMap<>();

    public SpriteManager(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }

    public Image getSprite(String path) {
        return cache.computeIfAbsent(path, p -> {
            try {
                return resourceLoader.loadImage(p);
            } catch (Exception e) {
                logger.warn("Failed to load sprite: {}", p, e);
                return null;
            }
        });
    }

    public ImageView createSpriteView(String path, double fitWidth, double fitHeight) {
        Image img = getSprite(path);
        ImageView view = new ImageView(img);
        view.setFitWidth(fitWidth);
        view.setFitHeight(fitHeight);
        view.setPreserveRatio(true);
        return view;
    }
}