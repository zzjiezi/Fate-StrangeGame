package com.game.rpg.view.scene;

import com.game.rpg.util.resource.ResourceLoader;
import javafx.animation.AnimationTimer;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoadingScreenView extends StackPane {
    private static final Logger logger = LoggerFactory.getLogger(LoadingScreenView.class);

    private static final int WINDOW_WIDTH = 800;
    private static final int WINDOW_HEIGHT = 600;
    private static final double TOTAL_DURATION_NS = 6_000_000_000L;

    private static final String TIP_TEXT =
            "提示:本作为RPG类,包含多个不同游戏,动漫的梗和要素,不限于:Fate系列,魔法少女小圆,怪诞小镇,崩坏:星穹铁道,传说之下等. " +
            "所有的画面都是人工绘制, 受限于精力所以有些粗糙. " +
            "如果你能接受—夹带众多私货,且有不同作品的大乱斗,对原作的一些浅薄的解构,幼稚的文笔以及多变的画风的话." +
            "就请开始游戏吧!希望你能在这一场冒险中获得些许愉悦~";

    private final ResourceLoader resourceLoader;

    private Text tipText;
    private AnimationTimer typewriterTimer;
    private long startTimeNs;
    private boolean allTextShown = false;
    private boolean animationSkipped = false;
    private Runnable onFinished;

    public LoadingScreenView(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;

        setPrefSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        initializeUI();
        setupClickHandler();
    }

    private void initializeUI() {
        ImageView backgroundView = loadBackgroundImage("/images/ui/加载页面.jpg");
        if (backgroundView != null) {
            getChildren().add(backgroundView);
        }

        tipText = new Text();
        tipText.setFont(Font.font("SimSun", 20));
        tipText.setFill(Color.WHITE);
        tipText.setWrappingWidth(700);
        tipText.setTextAlignment(TextAlignment.CENTER);
        tipText.setText("");

        getChildren().add(tipText);
        StackPane.setAlignment(tipText, javafx.geometry.Pos.CENTER);

        logger.info("Loading screen view initialized");
    }

    private ImageView loadBackgroundImage(String path) {
        try {
            Image image = resourceLoader.loadImage(path);
            ImageView imageView = new ImageView(image);
            imageView.setFitWidth(WINDOW_WIDTH);
            imageView.setFitHeight(WINDOW_HEIGHT);
            imageView.setPreserveRatio(false);
            return imageView;
        } catch (Exception e) {
            logger.warn("Failed to load loading screen background: {}", path, e);
            ImageView fallback = new ImageView();
            fallback.setFitWidth(WINDOW_WIDTH);
            fallback.setFitHeight(WINDOW_HEIGHT);
            return fallback;
        }
    }

    private void setupClickHandler() {
        setOnMouseClicked(e -> {
            if (e.getButton() != MouseButton.PRIMARY) return;

            if (!allTextShown) {
                skipToShowAllText();
            } else {
                goToMainMenu();
            }
        });
    }

    public void startTypewriter() {
        startTimeNs = System.nanoTime();

        typewriterTimer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                if (animationSkipped) return;

                long elapsed = now - startTimeNs;
                double progress = Math.min(1.0, (double) elapsed / TOTAL_DURATION_NS);
                int charCount = (int) Math.floor(progress * TIP_TEXT.length());
                charCount = Math.min(charCount, TIP_TEXT.length());

                tipText.setText(TIP_TEXT.substring(0, charCount));

                if (charCount >= TIP_TEXT.length()) {
                    allTextShown = true;
                    stop();
                    logger.info("Loading screen typewriter completed");
                }
            }
        };

        typewriterTimer.start();
        logger.info("Loading screen typewriter started");
    }

    private void skipToShowAllText() {
        animationSkipped = true;
        if (typewriterTimer != null) {
            typewriterTimer.stop();
        }
        tipText.setText(TIP_TEXT);
        allTextShown = true;
        logger.info("Loading screen typewriter skipped by user");
    }

    private void goToMainMenu() {
        if (typewriterTimer != null) {
            typewriterTimer.stop();
        }
        logger.info("Leaving loading screen to main menu");
        if (onFinished != null) {
            onFinished.run();
        }
    }

    public void setOnFinished(Runnable onFinished) {
        this.onFinished = onFinished;
    }
}
