package com.game.rpg.view.scene;

import com.game.rpg.util.map.SpriteManager;
import com.game.rpg.util.map.TiledMapParser;
import com.game.rpg.util.resource.ResourceLoader;
import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.animation.Timeline;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.function.Consumer;

public class GameMapView extends StackPane {
    private static final Logger logger = LoggerFactory.getLogger(GameMapView.class);

    public static final int GAME_WIDTH = 800;
    public static final int GAME_HEIGHT = 600;
    private static final double PLAYER_SPEED = 1.0;
    private static final double PLAYER_SIZE = 48;

    private final ResourceLoader resourceLoader;
    private final SpriteManager spriteManager;

    private Pane mapPane;
    private ImageView mapBackground;
    private ImageView playerSprite;
    private Pane interactionLayer;
    private Pane npcLayer;

    private StackPane dialogOverlay;
    private ImageView dialogBackground;
    private Text dialogText;
    private VBox dialogChoiceBox;

    private double playerX;
    private double playerY;
    private TiledMapParser.TiledMapData currentMapData;
    private String currentMapImagePath;
    private double mapScaleX = 1.0;
    private double mapScaleY = 1.0;

    private final Set<KeyCode> pressedKeys = new HashSet<>();
    private javafx.animation.AnimationTimer gameLoop;

    private boolean inputLocked = false;
    private Runnable onClickCallback;
    private boolean waitingForClick = false;

    private final List<InteractionZone> interactionZones = new ArrayList<>();
    private final List<NPCSprite> npcSprites = new ArrayList<>();
    private final Map<String, Boolean> gameFlags = new HashMap<>();

    private String playerDirection = "down";

    private static final String PLAYER_FRONT = "/images/characters/player/player 1正面 .png";
    private static final String PLAYER_BACK = "/images/characters/player/player 1背面 .png";
    private static final String PLAYER_LEFT = "/images/characters/player/player 1左视图.png";
    private static final String PLAYER_RIGHT = "/images/characters/player/player 1右视图.png";

    public GameMapView(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
        this.spriteManager = new SpriteManager(resourceLoader);

        setPrefSize(GAME_WIDTH, GAME_HEIGHT);
        initializeUI();
        setupInput();
    }

    private void initializeUI() {
        mapPane = new Pane();
        mapPane.setPrefSize(GAME_WIDTH, GAME_HEIGHT);

        mapBackground = new ImageView();
        mapBackground.setFitWidth(GAME_WIDTH);
        mapBackground.setFitHeight(GAME_HEIGHT);
        mapBackground.setPreserveRatio(false);

        interactionLayer = new Pane();
        npcLayer = new Pane();

        playerSprite = new ImageView();
        playerSprite.setFitWidth(PLAYER_SIZE);
        playerSprite.setFitHeight(PLAYER_SIZE);
        playerSprite.setPreserveRatio(true);

        mapPane.getChildren().addAll(mapBackground, interactionLayer, npcLayer, playerSprite);

        dialogOverlay = new StackPane();
        dialogOverlay.setPrefSize(GAME_WIDTH, GAME_HEIGHT);
        dialogOverlay.setVisible(false);
        dialogOverlay.setMouseTransparent(true);

        dialogBackground = new ImageView();
        dialogBackground.setPreserveRatio(true);

        dialogText = new Text();
        dialogText.setFont(Font.font("SimSun", 18));
        dialogText.setFill(Color.WHITE);
        dialogText.setWrappingWidth(700);

        StackPane dialogBgAndText = new StackPane();
        dialogBgAndText.getChildren().addAll(dialogBackground, dialogText);
        StackPane.setAlignment(dialogText, javafx.geometry.Pos.CENTER);

        dialogChoiceBox = new VBox(10);
        dialogChoiceBox.setStyle("-fx-alignment: center;");

        VBox dialogContainer = new VBox(5);
        dialogContainer.getChildren().addAll(dialogBgAndText, dialogChoiceBox);
        StackPane.setAlignment(dialogContainer, javafx.geometry.Pos.BOTTOM_CENTER);

        dialogOverlay.getChildren().add(dialogContainer);

        getChildren().addAll(mapPane, dialogOverlay);

        setupClickHandler();
    }

    private void setupClickHandler() {
        setOnMouseClicked(e -> {
            if (waitingForClick) {
                waitingForClick = false;
                if (onClickCallback != null) {
                    Runnable cb = onClickCallback;
                    onClickCallback = null;
                    cb.run();
                }
            }
        });
    }

    private void setupInput() {
        sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                bindKeyHandlers(newScene);
            }
        });

        gameLoop = new javafx.animation.AnimationTimer() {
            @Override
            public void handle(long now) {
                if (inputLocked) return;
                updatePlayer();
            }
        };
    }

    private void bindKeyHandlers(Scene scene) {
        scene.setOnKeyPressed(e -> {
            if (!inputLocked) pressedKeys.add(e.getCode());
        });
        scene.setOnKeyReleased(e -> pressedKeys.remove(e.getCode()));
    }

    public void ensureKeyBindings() {
        Scene scene = getScene();
        if (scene != null) {
            bindKeyHandlers(scene);
        }
    }

    private void updatePlayer() {
        double dx = 0, dy = 0;

        if (pressedKeys.contains(KeyCode.UP) || pressedKeys.contains(KeyCode.W)) {
            dy = -PLAYER_SPEED;
            playerDirection = "up";
        }
        if (pressedKeys.contains(KeyCode.DOWN) || pressedKeys.contains(KeyCode.S)) {
            dy = PLAYER_SPEED;
            playerDirection = "down";
        }
        if (pressedKeys.contains(KeyCode.LEFT) || pressedKeys.contains(KeyCode.A)) {
            dx = -PLAYER_SPEED;
            playerDirection = "left";
        }
        if (pressedKeys.contains(KeyCode.RIGHT) || pressedKeys.contains(KeyCode.D)) {
            dx = PLAYER_SPEED;
            playerDirection = "right";
        }

        if (dx == 0 && dy == 0) return;

        updatePlayerSprite();

        double newX = playerX + dx;
        double newY = playerY + dy;

        if (currentMapData != null) {
            double pw = PLAYER_SIZE / mapScaleX;
            double ph = PLAYER_SIZE / mapScaleY;
            if (currentMapData.isColliding(newX, newY, pw, ph)) return;
        }

        double screenX = newX * mapScaleX;
        double screenY = newY * mapScaleY;
        if (screenX >= 0 && screenX <= GAME_WIDTH - PLAYER_SIZE &&
            screenY >= 0 && screenY <= GAME_HEIGHT - PLAYER_SIZE) {
            playerX = newX;
            playerY = newY;
            updatePlayerScreenPosition();
        }

        checkInteractionZones();
    }

    private void updatePlayerSprite() {
        String spritePath = switch (playerDirection) {
            case "up" -> PLAYER_BACK;
            case "down" -> PLAYER_FRONT;
            case "left" -> PLAYER_LEFT;
            case "right" -> PLAYER_RIGHT;
            default -> PLAYER_FRONT;
        };
        Image img = spriteManager.getSprite(spritePath);
        if (img != null) playerSprite.setImage(img);
    }

    private void updatePlayerScreenPosition() {
        playerSprite.setLayoutX(playerX * mapScaleX);
        playerSprite.setLayoutY(playerY * mapScaleY);
    }

    private void checkInteractionZones() {
        for (InteractionZone zone : interactionZones) {
            if (!zone.triggered && zone.proximityCheck.test(playerX, playerY)) {
                zone.triggered = true;
                zone.onTrigger.run();
                return;
            }
        }
    }

    public void loadMap(String mapImagePath, String tmjPath, double spawnX, double spawnY) {
        currentMapImagePath = mapImagePath;
        try {
            Image img = resourceLoader.loadImage(mapImagePath);
            mapBackground.setImage(img);
        } catch (Exception e) {
            logger.warn("Failed to load map image: {}", mapImagePath, e);
        }

        if (tmjPath != null) {
            currentMapData = TiledMapParser.parse(tmjPath);
            if (currentMapData.mapWidth() > 0 && currentMapData.mapHeight() > 0) {
                mapScaleX = (double) GAME_WIDTH / currentMapData.mapWidth();
                mapScaleY = (double) GAME_HEIGHT / currentMapData.mapHeight();
            }
        } else {
            currentMapData = null;
            mapScaleX = 1.0;
            mapScaleY = 1.0;
        }

        playerX = spawnX;
        playerY = spawnY;
        updatePlayerScreenPosition();
        updatePlayerSprite();

        interactionLayer.getChildren().clear();
        npcLayer.getChildren().clear();
        interactionZones.clear();
        npcSprites.clear();

        logger.info("Map loaded: {} at ({}, {}) scaleX={} scaleY={}", mapImagePath, spawnX, spawnY, mapScaleX, mapScaleY);
    }

    public void addInteractionZone(String id, double x, double y, double w, double h,
                                    java.util.function.BiPredicate<Double, Double> proximityCheck,
                                    Runnable onTrigger, boolean showSparkle) {
        InteractionZone zone = new InteractionZone(id, x, y, w, h, proximityCheck, onTrigger);
        interactionZones.add(zone);

        if (showSparkle) {
            Circle sparkle = new Circle((x + w / 2) * mapScaleX, (y + h / 2) * mapScaleY, 3, Color.WHITE);
            sparkle.setOpacity(0);
            FadeTransition ft = new FadeTransition(Duration.millis(800), sparkle);
            ft.setFromValue(0.2);
            ft.setToValue(1.0);
            ft.setCycleCount(Timeline.INDEFINITE);
            ft.setAutoReverse(true);
            ft.play();
            interactionLayer.getChildren().add(sparkle);
        }
    }

    public void addNPC(String id, double x, double y, String spritePath) {
        ImageView npcView = spriteManager.createSpriteView(spritePath, 24, 24);
        npcView.setLayoutX(x * mapScaleX);
        npcView.setLayoutY(y * mapScaleY);
        npcLayer.getChildren().add(npcView);
        npcSprites.add(new NPCSprite(id, x, y, npcView));
    }

    public void updateNPCSprite(String id, String newSpritePath) {
        for (NPCSprite npc : npcSprites) {
            if (npc.id.equals(id)) {
                Image img = spriteManager.getSprite(newSpritePath);
                if (img != null) npc.view.setImage(img);
                break;
            }
        }
    }

    private void applyDialogBackground(String dialogBgPath) {
        try {
            Image bgImg = resourceLoader.loadImage(dialogBgPath);
            dialogBackground.setImage(bgImg);
            double maxH = GAME_HEIGHT * 0.35;
            double scaleW = GAME_WIDTH / bgImg.getWidth();
            double scaleH = maxH / bgImg.getHeight();
            double scale = Math.min(scaleW, scaleH);
            dialogBackground.setFitWidth(bgImg.getWidth() * scale);
            dialogBackground.setFitHeight(bgImg.getHeight() * scale);
        } catch (Exception e) {
            logger.warn("Failed to load dialog background: {}", dialogBgPath);
            dialogBackground.setImage(null);
        }
    }

    public void showDialogWithBackground(String dialogBgPath, String text, Runnable onAdvance) {
        inputLocked = true;
        applyDialogBackground(dialogBgPath);
        dialogText.setText(text);
        dialogChoiceBox.getChildren().clear();
        dialogOverlay.setVisible(true);
        dialogOverlay.setMouseTransparent(false);
        waitingForClick = true;
        onClickCallback = () -> {
            hideDialog();
            if (onAdvance != null) onAdvance.run();
        };
    }

    public void showDialogWithChoice(String dialogBgPath, String text,
                                      List<String> choices, Consumer<Integer> onChoice) {
        inputLocked = true;
        applyDialogBackground(dialogBgPath);
        dialogText.setText(text);
        dialogChoiceBox.getChildren().clear();

        for (int i = 0; i < choices.size(); i++) {
            final int idx = i;
            Button btn = new Button(choices.get(i));
            btn.setFont(Font.font("SimSun", 16));
            btn.setPrefWidth(300);
            btn.setStyle("-fx-background-color: rgba(40,40,40,0.9); -fx-text-fill: white; " +
                    "-fx-border-color: #5a5a5a; -fx-border-width: 2; -fx-padding: 8 16;");
            btn.setOnMouseEntered(e -> btn.setStyle(
                    "-fx-background-color: rgba(60,60,60,0.9); -fx-text-fill: cyan; " +
                            "-fx-border-color: cyan; -fx-border-width: 2; -fx-padding: 8 16;"));
            btn.setOnMouseExited(e -> btn.setStyle(
                    "-fx-background-color: rgba(40,40,40,0.9); -fx-text-fill: white; " +
                            "-fx-border-color: #5a5a5a; -fx-border-width: 2; -fx-padding: 8 16;"));
            btn.setOnAction(e -> {
                hideDialog();
                onChoice.accept(idx);
            });
            dialogChoiceBox.getChildren().add(btn);
        }

        dialogOverlay.setVisible(true);
        dialogOverlay.setMouseTransparent(false);
    }

    public void showFullScreenImage(String imagePath, Runnable onAdvance) {
        inputLocked = true;
        ImageView fullScreen = new ImageView();
        try {
            Image img = resourceLoader.loadImage(imagePath);
            fullScreen.setImage(img);
            double scale = Math.min(GAME_WIDTH / img.getWidth(), GAME_HEIGHT / img.getHeight());
            fullScreen.setFitWidth(img.getWidth() * scale);
            fullScreen.setFitHeight(img.getHeight() * scale);
            fullScreen.setPreserveRatio(true);
        } catch (Exception e) {
            logger.warn("Failed to load full screen image: {}", imagePath);
        }

        getChildren().add(fullScreen);
        waitingForClick = true;
        onClickCallback = () -> {
            getChildren().remove(fullScreen);
            if (onAdvance != null) onAdvance.run();
        };
    }

    public void showTextOverlay(String text, Runnable onAdvance) {
        inputLocked = true;
        StackPane textContainer = new StackPane();
        textContainer.setStyle("-fx-background-color: rgba(0,0,0,0.7); -fx-padding: 20 30;");
        Text overlayText = new Text(text);
        overlayText.setFont(Font.font("SimSun", 20));
        overlayText.setFill(Color.WHITE);
        overlayText.setWrappingWidth(700);
        textContainer.getChildren().add(overlayText);
        StackPane.setAlignment(textContainer, javafx.geometry.Pos.CENTER);

        getChildren().add(textContainer);
        waitingForClick = true;
        onClickCallback = () -> {
            getChildren().remove(textContainer);
            if (onAdvance != null) onAdvance.run();
        };
    }

    public void showScreenShake(Runnable onComplete) {
        inputLocked = true;
        double origX = mapPane.getTranslateX();
        double origY = mapPane.getTranslateY();

        javafx.animation.Timeline shake = new javafx.animation.Timeline(
                new javafx.animation.KeyFrame(Duration.millis(50), e -> mapPane.setTranslateX(origX + 8)),
                new javafx.animation.KeyFrame(Duration.millis(100), e -> mapPane.setTranslateX(origX - 8)),
                new javafx.animation.KeyFrame(Duration.millis(150), e -> mapPane.setTranslateX(origX + 5)),
                new javafx.animation.KeyFrame(Duration.millis(200), e -> mapPane.setTranslateX(origX - 5)),
                new javafx.animation.KeyFrame(Duration.millis(250), e -> {
                    mapPane.setTranslateX(origX);
                    mapPane.setTranslateY(origY);
                })
        );
        shake.setOnFinished(e -> {
            if (onComplete != null) onComplete.run();
        });
        shake.play();
    }

    public void showRedFlash(Runnable onComplete) {
        Rectangle redFlash = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.RED);
        redFlash.setOpacity(0);
        redFlash.setMouseTransparent(true);
        getChildren().add(redFlash);

        FadeTransition flashIn = new FadeTransition(Duration.millis(150), redFlash);
        flashIn.setFromValue(0.0);
        flashIn.setToValue(0.8);

        FadeTransition flashOut = new FadeTransition(Duration.millis(300), redFlash);
        flashOut.setFromValue(0.8);
        flashOut.setToValue(0.0);
        flashOut.setOnFinished(e -> {
            getChildren().remove(redFlash);
            if (onComplete != null) onComplete.run();
        });

        SequentialTransition seq = new SequentialTransition(flashIn, flashOut);
        seq.play();
    }

    public void showBlackScreen(long waitMs, Runnable onComplete) {
        inputLocked = true;
        Rectangle black = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.BLACK);
        black.setMouseTransparent(true);
        getChildren().add(black);

        PauseTransition wait = new PauseTransition(Duration.millis(waitMs));
        wait.setOnFinished(e -> {
            getChildren().remove(black);
            if (onComplete != null) onComplete.run();
        });
        wait.play();
    }

    public void hideDialog() {
        dialogOverlay.setVisible(false);
        dialogOverlay.setMouseTransparent(true);
        dialogChoiceBox.getChildren().clear();
        inputLocked = false;
    }

    public void unlockInput() {
        inputLocked = false;
    }

    public void lockInput() {
        inputLocked = true;
    }

    public void startGameLoop() {
        gameLoop.start();
    }

    public void stopGameLoop() {
        gameLoop.stop();
        pressedKeys.clear();
    }

    public void setFlag(String key, boolean value) {
        gameFlags.put(key, value);
    }

    public boolean getFlag(String key) {
        return gameFlags.getOrDefault(key, false);
    }

    public void resetInteractionZone(String id) {
        for (InteractionZone zone : interactionZones) {
            if (zone.id.equals(id)) {
                zone.triggered = false;
            }
        }
    }

    private static class InteractionZone {
        final String id;
        final double x, y, w, h;
        final java.util.function.BiPredicate<Double, Double> proximityCheck;
        final Runnable onTrigger;
        boolean triggered;

        InteractionZone(String id, double x, double y, double w, double h,
                         java.util.function.BiPredicate<Double, Double> proximityCheck,
                         Runnable onTrigger) {
            this.id = id;
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            this.proximityCheck = proximityCheck;
            this.onTrigger = onTrigger;
            this.triggered = false;
        }
    }

    private record NPCSprite(String id, double x, double y, ImageView view) {}
}
