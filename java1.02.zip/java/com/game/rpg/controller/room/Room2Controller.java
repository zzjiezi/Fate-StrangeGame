package com.game.rpg.controller.room;

import com.game.rpg.util.resource.ResourceLoader;
import com.game.rpg.view.scene.GameMapView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class Room2Controller {
    private static final Logger logger = LoggerFactory.getLogger(Room2Controller.class);

    private final GameMapView gameMap;
    private final ResourceLoader resourceLoader;

    public Room2Controller(GameMapView gameMap, ResourceLoader resourceLoader) {
        this.gameMap = gameMap;
        this.resourceLoader = resourceLoader;
    }

    public void setup() {
        gameMap.loadMap(
                "/images/ui/totalmap(8).png",
                "/maps/totalmap(8).tmj",
                18, 79
        );

        gameMap.addNPC("saberAlter", 53, 71, "/images/enemies/Saber Alter1.png");
        gameMap.addNPC("saber", 53, 87, "/images/characters/Saber/Saber 1背面 .png");

        gameMap.startGameLoop();

        showSaberDialogue();
    }

    private void showSaberDialogue() {
        gameMap.lockInput();
        gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "???: 试问, 你就是我的御主吗?",
                () -> {
                    gameMap.updateNPCSprite("saber", "/images/characters/Saber/Saber 1正面 .png");
                    gameMap.showDialogWithChoice("/images/ui/dialogbackground.png",
                            "（该说些什么回答她……）",
                            List.of("是啊, 你就是我的从者!", "从者… 那是什么?"),
                            choice -> {
                                if (choice == 0) {
                                    gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                                            "金发少女: 嗯, 那么请下指令击退敌人吧, 御主",
                                            () -> onRoom2Complete());
                                } else {
                                    gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                                            "金发少女: 我是会保护你的存在, 情况紧急, 请允许我击退敌人后再解释.",
                                            () -> onRoom2Complete());
                                }
                            });
                });
    }

    private void onRoom2Complete() {
        logger.info("Room 2 completed");
        gameMap.unlockInput();
        if (onComplete != null) onComplete.run();
    }

    private Runnable onComplete;

    public void setOnComplete(Runnable onComplete) {
        this.onComplete = onComplete;
    }
}