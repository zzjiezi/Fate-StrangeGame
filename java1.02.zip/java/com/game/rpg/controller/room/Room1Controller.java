package com.game.rpg.controller.room;

import com.game.rpg.util.resource.ResourceLoader;
import com.game.rpg.view.scene.GameMapView;
import javafx.animation.PauseTransition;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class Room1Controller {
    private static final Logger logger = LoggerFactory.getLogger(Room1Controller.class);

    private final GameMapView gameMap;
    private final ResourceLoader resourceLoader;

    private boolean hasReadBook = false;
    private boolean hasPickedGem = false;
    private boolean hasSeenInitialDialog = false;

    public Room1Controller(GameMapView gameMap, ResourceLoader resourceLoader) {
        this.gameMap = gameMap;
        this.resourceLoader = resourceLoader;
    }

    public void setup() {
        gameMap.loadMap(
                "/images/ui/totalmap(10).png",
                "/maps/totalmap(10).tmj",
                18, 79
        );

        gameMap.addInteractionZone("book", 115, 89, 23, 16,
                (px, py) -> px >= 149 - 20 && px <= 149 + 20 && py >= 89 - 20 && py <= 89 + 20,
                () -> handleBookInteraction(), true);

        gameMap.addInteractionZone("gem", 115, 100, 28, 14,
                (px, py) -> px >= 106 - 20 && px <= 106 + 20 && py >= 100 - 20 && py <= 100 + 20,
                () -> handleGemInteraction(), true);

        gameMap.addInteractionZone("summon", 18, 79, 72, 59,
                (px, py) -> px >= 18 && px <= 18 + 72 && py >= 79 && py <= 79 + 59,
                () -> handleSummonInteraction(), true);

        gameMap.startGameLoop();

        showInitialDialog();
    }

    private void showInitialDialog() {
        gameMap.lockInput();
        hasSeenInitialDialog = true;
        gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "召唤法阵没有反应,应该需要一些特殊的操作\n也许周围的书里有说怎么启动它……",
                () -> {
                    gameMap.resetInteractionZone("summon");
                    gameMap.unlockInput();
                });
    }

    private void handleBookInteraction() {
        gameMap.showDialogWithChoice("/images/ui/dialogbackground.png",
                "", List.of("查看"), idx -> {
                    gameMap.lockInput();
                    gameMap.showFullScreenImage("/images/ui/背景保留.png", () -> {
                        gameMap.showTextOverlay(
                                "(扉页上写了\"远坂\"两个字, 应该是笔记本的主人吧…)\n" +
                                "[…圣杯战争是为了得到能够实现持有者心愿的\"圣杯\"展开的残酷争斗.\n" +
                                "…被选中的御主master手背会显现红色的令咒……\n" +
                                "…可以使用触媒或直接在召唤阵念出下列…召唤从者servant…]\n" +
                                "(笔记本中附有一张考究的羊皮纸,召唤所需的咒语经娟秀的字体被记录于其中)",
                                () -> {
                                    hasReadBook = true;
                                    gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                                            "(这里面的内容…看不太懂…但既然提到召唤阵,应该是要用这个咒语来召唤吧…)",
                                            () -> gameMap.unlockInput());
                                });
                    });
                });
    }

    private void handleGemInteraction() {
        gameMap.showDialogWithChoice("/images/ui/dialogbackground.png",
                "", List.of("拾取"), idx -> {
                    hasPickedGem = true;
                    gameMap.unlockInput();
                });
    }

    private void handleSummonInteraction() {
        if (!hasReadBook || !hasPickedGem) {
            if (!hasSeenInitialDialog) {
                hasSeenInitialDialog = true;
                gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                        "召唤法阵没有反应,应该需要一些特殊的操作……",
                        () -> {
                            gameMap.resetInteractionZone("summon");
                            gameMap.unlockInput();
                        });
            } else {
                gameMap.resetInteractionZone("summon");
                gameMap.unlockInput();
            }
            return;
        }
        gameMap.showDialogWithChoice("/images/ui/dialogbackgroundBlack.png",
                "", List.of("召唤"), idx -> {
                    gameMap.lockInput();
                    gameMap.showDialogWithBackground("/images/ui/dialogbackgroundBlack.png",
                            "你: …汝为身缠三大言灵之七天 于抑止之轮降临此处, 天平之守护者!",
                            () -> {
                                gameMap.showDialogWithBackground("/images/ui/dialogbackgroundBlack.png",
                                        "（明明是第一次念出这些咒语, 你却莫名的熟练）",
                                        () -> transitionToMap9());
                            });
                });
    }

    private void transitionToMap9() {
        gameMap.lockInput();
        gameMap.loadMap("/images/ui/totalmap(9).png", null, 18, 79);

        PauseTransition wait3s = new PauseTransition(Duration.seconds(3));
        wait3s.setOnFinished(e -> {
            gameMap.showBlackScreen(0, () -> {
                gameMap.showTextOverlay("什么也没出现吗…?", () -> {
                    gameMap.showBlackScreen(0, () -> {
                        gameMap.showScreenShake(() -> {
                            gameMap.showRedFlash(() -> {
                                gameMap.showBlackScreen(2000, () -> {
                                    onRoom1Complete();
                                });
                            });
                        });
                    });
                });
            });
        });
        wait3s.play();
    }

    private void onRoom1Complete() {
        logger.info("Room 1 completed, transitioning to Room 2");
        if (onComplete != null) onComplete.run();
    }

    private Runnable onComplete;

    public void setOnComplete(Runnable onComplete) {
        this.onComplete = onComplete;
    }
}