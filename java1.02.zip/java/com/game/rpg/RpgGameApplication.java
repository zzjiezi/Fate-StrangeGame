package com.game.rpg;

import com.game.rpg.controller.menu.MenuController;
import com.game.rpg.controller.save.SaveController;
import com.game.rpg.controller.achievement.AchievementController;
import com.game.rpg.controller.story.StoryController;
import com.game.rpg.model.state.GameStateManager;
import com.game.rpg.util.config.GameConfig;
import com.game.rpg.util.config.ResourceConfig;
import com.game.rpg.util.resource.ResourceLoader;
import com.game.rpg.view.scene.MainMenuView;
import com.game.rpg.view.scene.LoadingScreenView;
import com.game.rpg.view.scene.OpeningSceneView;
import com.game.rpg.view.scene.GameMapView;
import com.game.rpg.controller.room.RoomManager;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RpgGameApplication extends Application {
    private static final Logger logger = LoggerFactory.getLogger(RpgGameApplication.class);
    
    private static final String TITLE = "RPG Game - 圣杯战争";
    private static final int WINDOW_WIDTH = 800;
    private static final int WINDOW_HEIGHT = 600;
    
    private GameConfig gameConfig;
    private ResourceConfig resourceConfig;
    private ResourceLoader resourceLoader;
    private GameStateManager stateManager;
    
    private MenuController menuController;
    private SaveController saveController;
    private AchievementController achievementController;
    private StoryController storyController;
    
    private StackPane root;
    private MainMenuView mainMenuView;
    private RoomManager roomManager;

    @Override
    public void start(Stage primaryStage) {
        try {
            logger.info("Starting RPG Game Application...");
            
            initializeComponents();
            
            StackPane root = new StackPane();
            this.root = root;
            Scene scene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);
            
            scene.getStylesheets().add(getClass().getResource("/css/global.css").toExternalForm());

            LoadingScreenView loadingScreen = new LoadingScreenView(resourceLoader);
            loadingScreen.setOnFinished(() -> showMainMenu());
            root.getChildren().add(loadingScreen);
            loadingScreen.startTypewriter();
            
            primaryStage.setTitle(TITLE);
            primaryStage.setScene(scene);
            primaryStage.setResizable(false);
            primaryStage.centerOnScreen();
            
            primaryStage.show();
            
            logger.info("Application started successfully");
        } catch (Exception e) {
            logger.error("Failed to start application", e);
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    private void initializeComponents() {
        gameConfig = new GameConfig();
        resourceConfig = new ResourceConfig();
        resourceLoader = new ResourceLoader(resourceConfig);
        stateManager = new GameStateManager();
        
        menuController = new MenuController(stateManager);
        saveController = new SaveController(stateManager);
        achievementController = new AchievementController(stateManager);
        storyController = new StoryController(stateManager, resourceLoader);
        
        menuController.setOnNewGame(v -> {
            logger.info("Starting new game...");
            startOpeningScene();
        });
        
        logger.info("Components initialized");
    }

    private void showMainMenu() {
        MainMenuView mainMenuView = new MainMenuView(resourceLoader, menuController);
        this.mainMenuView = mainMenuView;
        root.getChildren().clear();
        root.getChildren().add(mainMenuView);
    }

    private void startOpeningScene() {
        OpeningSceneView openingScene = new OpeningSceneView(resourceLoader, storyController);
        root.getChildren().clear();
        root.getChildren().add(openingScene);
        openingScene.startOpeningSequence();

        openingScene.setOnSequenceComplete(() -> startRoomSystem());
    }

    private void startRoomSystem() {
        GameMapView gameMap = new GameMapView(resourceLoader);
        roomManager = new RoomManager(gameMap, resourceLoader);
        root.getChildren().clear();
        root.getChildren().add(gameMap);
        roomManager.startRoom(1);
    }

    @Override
    public void stop() {
        logger.info("Application shutting down...");
    }

    public static void main(String[] args) {
        launch(args);
    }
}
