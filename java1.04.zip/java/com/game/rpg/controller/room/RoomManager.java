package com.game.rpg.controller.room;

import com.game.rpg.util.resource.ResourceLoader;
import com.game.rpg.view.scene.GameMapView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RoomManager {
    private static final Logger logger = LoggerFactory.getLogger(RoomManager.class);

    private final GameMapView gameMap;
    private final ResourceLoader resourceLoader;
    private int currentRoom = 0;

    public RoomManager(GameMapView gameMap, ResourceLoader resourceLoader) {
        this.gameMap = gameMap;
        this.resourceLoader = resourceLoader;
    }

    public void startRoom(int roomNumber) {
        currentRoom = roomNumber;
        gameMap.stopGameLoop();
        gameMap.ensureKeyBindings();

        switch (roomNumber) {
            case 1 -> startRoom1();
            case 2 -> startRoom2();
            case 3 -> startRoom3();
            default -> logger.warn("Room {} not implemented yet", roomNumber);
        }
    }

    private void startRoom1() {
        Room1Controller controller = new Room1Controller(gameMap, resourceLoader);
        controller.setOnComplete(() -> startRoom(2));
        controller.setup();
    }

    private void startRoom2() {
        Room2Controller controller = new Room2Controller(gameMap, resourceLoader);
        controller.setOnComplete(() -> startRoom(3));
        controller.setup();
    }

    private void startRoom3() {
        Room3Controller controller = new Room3Controller(gameMap, resourceLoader);
        controller.setOnComplete(() -> {
            logger.info("All current rooms completed");
        });
        controller.setup();
    }

    public int getCurrentRoom() {
        return currentRoom;
    }
}
