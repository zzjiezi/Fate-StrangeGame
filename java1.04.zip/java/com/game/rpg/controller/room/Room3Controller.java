package com.game.rpg.controller.room;

import com.game.rpg.util.resource.ResourceLoader;
import com.game.rpg.view.scene.GameMapView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class Room3Controller {
    private static final Logger logger = LoggerFactory.getLogger(Room3Controller.class);

    private final GameMapView gameMap;
    private final ResourceLoader resourceLoader;

    private int dialogChoice = -1;

    public Room3Controller(GameMapView gameMap, ResourceLoader resourceLoader) {
        this.gameMap = gameMap;
        this.resourceLoader = resourceLoader;
    }

    public void setup() {
        gameMap.loadMap(
                "/images/backgrounds/roomAttacked.png",
                "/maps/roomAttacked.tmj",
                428, 387
        );

        gameMap.addNPC("saberAlter", 429, 262, "/images/enemies/Saber Alter1.png", 80, 80);
        gameMap.addNPC("saber", 442, 348, "/images/characters/Saber/Saber 1背面 .png", 80, 80);

        gameMap.startGameLoop();
        gameMap.lockInput();

        showSaberDialogue();
    }

    private void showSaberDialogue() {
        gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "???: 试问，你就是我的御主吗？",
                () -> {
                    gameMap.updateNPCSprite("saber", "/images/characters/Saber/Saber 1正面 .png");
                    gameMap.showDialogWithChoice("/images/ui/dialogbackground.png",
                            "（该说些什么回答她……）",
                            List.of("是啊，你就是我的从者！", "从者… 那是什么？"),
                            choice -> {
                                dialogChoice = choice;
                                if (choice == 0) {
                                    gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                                            "金发少女：嗯，那么请下指令击退敌人吧，御主",
                                            () -> onRoom3Complete());
                                } else {
                                    gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                                            "金发少女：我是会保护你的存在，情况紧急，请允许我击退敌人后再解释。",
                                            () -> onRoom3Complete());
                                }
                            });
                });
    }

    private void onRoom3Complete() {
        logger.info("Room 3 completed, dialog choice was: {}", dialogChoice);
        gameMap.unlockInput();
        if (onComplete != null) onComplete.run();
    }

    private Runnable onComplete;

    public void setOnComplete(Runnable onComplete) {
        this.onComplete = onComplete;
    }

    public int getDialogChoice() {
        return dialogChoice;
    }
}