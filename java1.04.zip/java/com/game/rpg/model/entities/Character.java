package com.game.rpg.model.entities;

import com.game.rpg.model.enums.CommandSpellBranch;
import com.game.rpg.model.enums.CommandSpellEffect;
import com.game.rpg.util.ValidationUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class Character {
    private final String id;
    private final String name;
    private int hp;
    private int maxHp;
    private int mp;
    private int maxMp;
    private int attackPower;
    private int commandSpellCount;
    private final CommandSpellBranch commandSpellBranch;
    private final List<Skill> skills;
    private final double hitRate;
    private final double dodgeRate;
    private final boolean alwaysHit;
    private final double phaseShiftChance;
    protected final Random random;
    private final Set<CommandSpellEffect> usedCommandSpells;
    private boolean damageBoostActive;
    private int poisonDamage;
    private int poisonTurnsRemaining;
    private int attackReduction;
    private int attackReductionTurnsRemaining;
    private int skillSealTurnsRemaining;
    private boolean delayedNextTurn;
    private double damageReduction;
    private int mpRegenPerTurn;
    private boolean damagedThisTurn;
    private double healReduction;
    private double dodgeRateReduction;
    private int dodgeRateReductionTurnsRemaining;
    private int curseDamage;
    private int curseTurnsRemaining;
    private int curseStacks;
    private boolean preventRevive;
    private int mpDrainPerTurn;
    private int mpDrainTurnsRemaining;
    private boolean buffSuppressed;
    private int buffSuppressedTurnsRemaining;

    public Character(String id, String name, int maxHp, int maxMp, int initialMp, int attackPower,
                     CommandSpellBranch commandSpellBranch, double hitRate, double dodgeRate) {
        this(id, name, maxHp, maxMp, initialMp, attackPower, commandSpellBranch, hitRate, dodgeRate, false, 0.0, 0.0, 0);
    }

    public Character(String id, String name, int maxHp, int maxMp, int initialMp, int attackPower,
                     CommandSpellBranch commandSpellBranch, double hitRate, double dodgeRate,
                     boolean alwaysHit, double phaseShiftChance, double damageReduction, int mpRegenPerTurn) {
        ValidationUtils.requireNonNull(id, "Character ID cannot be null");
        ValidationUtils.requireNonNull(name, "Character name cannot be null");
        ValidationUtils.requirePositive(maxHp, "Max HP must be positive");
        ValidationUtils.requirePositive(maxMp, "Max MP must be positive");
        ValidationUtils.requireNonNegative(attackPower, "Attack power must be non-negative");
        ValidationUtils.requireInRange(hitRate, 0.0, 1.0, "Hit rate must be between 0.0 and 1.0");
        ValidationUtils.requireInRange(dodgeRate, 0.0, 1.0, "Dodge rate must be between 0.0 and 1.0");
        ValidationUtils.requireInRange(phaseShiftChance, 0.0, 1.0, "Phase shift chance must be between 0.0 and 1.0");

        this.id = id;
        this.name = name;
        this.maxHp = maxHp;
        this.hp = maxHp;
        this.maxMp = maxMp;
        this.mp = initialMp;
        this.attackPower = attackPower;
        this.commandSpellCount = 3;
        this.commandSpellBranch = commandSpellBranch;
        this.skills = new ArrayList<>();
        this.hitRate = hitRate;
        this.dodgeRate = dodgeRate;
        this.alwaysHit = alwaysHit;
        this.phaseShiftChance = phaseShiftChance;
        this.random = new Random();
        this.usedCommandSpells = EnumSet.noneOf(CommandSpellEffect.class);
        this.damageBoostActive = false;
        this.poisonDamage = 0;
        this.poisonTurnsRemaining = 0;
        this.attackReduction = 0;
        this.attackReductionTurnsRemaining = 0;
        this.skillSealTurnsRemaining = 0;
        this.delayedNextTurn = false;
        this.damageReduction = damageReduction;
        this.mpRegenPerTurn = mpRegenPerTurn;
        this.damagedThisTurn = false;
        this.healReduction = 0.0;
        this.dodgeRateReduction = 0.0;
        this.dodgeRateReductionTurnsRemaining = 0;
        this.curseDamage = 0;
        this.curseTurnsRemaining = 0;
        this.curseStacks = 0;
        this.preventRevive = false;
        this.mpDrainPerTurn = 0;
        this.mpDrainTurnsRemaining = 0;
        this.buffSuppressed = false;
        this.buffSuppressedTurnsRemaining = 0;
    }

    public boolean isAlive() {
        return hp > 0;
    }

    public boolean canCastSkill(Skill skill) {
        ValidationUtils.requireNonNull(skill, "Skill cannot be null");
        return mp >= skill.getMpCost();
    }

    public void takeDamage(int damage) {
        takeDamage(damage, false);
    }

    public void takeDamage(int damage, boolean ignoreReduction) {
        ValidationUtils.requireNonNegative(damage, "Damage must be non-negative");
        int actualDamage = damage;
        if (!ignoreReduction && damageReduction > 0) {
            actualDamage = (int) Math.round(damage * (1.0 - damageReduction));
        }
        hp = Math.max(0, hp - actualDamage);
        if (actualDamage > 0) {
            damagedThisTurn = true;
        }
    }

    public void heal(int amount) {
        ValidationUtils.requireNonNegative(amount, "Heal amount must be non-negative");
        int effectiveAmount = amount;
        if (healReduction > 0) {
            effectiveAmount = (int) Math.round(amount * (1.0 - healReduction));
        }
        hp = Math.min(maxHp, hp + effectiveAmount);
    }

    public void consumeMP(int amount) {
        ValidationUtils.requireNonNegative(amount, "MP amount must be non-negative");
        mp = Math.max(0, mp - amount);
    }

    public void restoreMP(int amount) {
        ValidationUtils.requireNonNegative(amount, "MP amount must be non-negative");
        mp = Math.min(maxMp, mp + amount);
    }

    public boolean canUseCommandSpell(CommandSpellEffect effect) {
        return commandSpellCount > 0 && !usedCommandSpells.contains(effect);
    }

    public boolean useCommandSpell(CommandSpellEffect effect) {
        if (!canUseCommandSpell(effect)) {
            return false;
        }
        commandSpellCount--;
        usedCommandSpells.add(effect);
        return true;
    }

    public void resetCommandSpells() {
        commandSpellCount = 3;
        usedCommandSpells.clear();
        damageBoostActive = false;
    }

    public void applyPoison(int damage, int turns) {
        this.poisonDamage = damage;
        this.poisonTurnsRemaining = turns;
    }

    public void tickPoison() {
        if (poisonTurnsRemaining > 0) {
            takeDamage(poisonDamage);
            poisonTurnsRemaining--;
        }
    }

    public int getPoisonTurnsRemaining() {
        return poisonTurnsRemaining;
    }

    public void applyAttackReduction(int reduction, int turns) {
        this.attackReduction = reduction;
        this.attackReductionTurnsRemaining = turns;
    }

    public int getEffectiveAttackPower() {
        int power = attackPower;
        if (attackReductionTurnsRemaining > 0) {
            power = Math.max(0, power - attackReduction);
        }
        return power;
    }

    public void tickAttackReduction() {
        if (attackReductionTurnsRemaining > 0) {
            attackReductionTurnsRemaining--;
            if (attackReductionTurnsRemaining == 0) {
                attackReduction = 0;
            }
        }
    }

    public int getAttackReductionTurnsRemaining() {
        return attackReductionTurnsRemaining;
    }

    public void applySkillSeal(int turns) {
        this.skillSealTurnsRemaining = turns;
    }

    public boolean isSkillSealed() {
        return skillSealTurnsRemaining > 0;
    }

    public void tickSkillSeal() {
        if (skillSealTurnsRemaining > 0) {
            skillSealTurnsRemaining--;
        }
    }

    public int getSkillSealTurnsRemaining() {
        return skillSealTurnsRemaining;
    }

    public void setDelayedNextTurn(boolean delayed) {
        this.delayedNextTurn = delayed;
    }

    public boolean isDelayedNextTurn() {
        return delayedNextTurn;
    }

    public void clearDelayedNextTurn() {
        this.delayedNextTurn = false;
    }

    public void tickAllEffects() {
        tickPoison();
        tickAttackReduction();
        tickSkillSeal();
    }

    public void onTurnEnd() {
        if (mpRegenPerTurn > 0) {
            restoreMP(mpRegenPerTurn);
        }
        tickCurse();
        tickMpDrain();
        tickDodgeRateReduction();
        tickBuffSuppression();
        damagedThisTurn = false;
    }

    public double getDamageReduction() {
        return damageReduction;
    }

    public void setDamageReduction(double reduction) {
        this.damageReduction = Math.max(0.0, Math.min(1.0, reduction));
    }

    public int getMpRegenPerTurn() {
        return mpRegenPerTurn;
    }

    public void setMpRegenPerTurn(int regen) {
        this.mpRegenPerTurn = Math.max(0, regen);
    }

    public boolean wasDamagedThisTurn() {
        return damagedThisTurn;
    }

    public void setDamagedThisTurn(boolean damaged) {
        this.damagedThisTurn = damaged;
    }

    public Set<CommandSpellEffect> getUsedCommandSpells() {
        return Collections.unmodifiableSet(usedCommandSpells);
    }

    public boolean isCommandSpellUsed(CommandSpellEffect effect) {
        return usedCommandSpells.contains(effect);
    }

    public boolean isDamageBoostActive() {
        return damageBoostActive;
    }

    public void setDamageBoostActive(boolean active) {
        this.damageBoostActive = active;
    }

    public void addSkill(Skill skill) {
        ValidationUtils.requireNonNull(skill, "Skill cannot be null");
        skills.add(skill);
    }

    public List<Skill> getSkills() {
        return Collections.unmodifiableList(skills);
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getHp() {
        return hp;
    }

    public int getMaxHp() {
        return maxHp;
    }

    public int getMp() {
        return mp;
    }

    public int getMaxMp() {
        return maxMp;
    }

    public int getAttackPower() {
        return attackPower;
    }

    public int getCommandSpellCount() {
        return commandSpellCount;
    }

    public CommandSpellBranch getCommandSpellBranch() {
        return commandSpellBranch;
    }

    public double getHitRate() {
        return hitRate;
    }

    public double getDodgeRate() {
        return dodgeRate;
    }

    public boolean isAlwaysHit() {
        return alwaysHit;
    }

    public double getPhaseShiftChance() {
        return phaseShiftChance;
    }

    public double getEffectiveDodgeRate() {
        double rate = dodgeRate;
        if (dodgeRateReductionTurnsRemaining > 0 && dodgeRateReduction > 0) {
            rate = Math.max(0.0, rate - dodgeRateReduction);
        }
        return rate;
    }

    public double getHealReduction() {
        return healReduction;
    }

    public void setHealReduction(double reduction) {
        this.healReduction = Math.max(0.0, Math.min(1.0, reduction));
    }

    public void applyDodgeRateReduction(double reduction, int turns) {
        this.dodgeRateReduction = reduction;
        this.dodgeRateReductionTurnsRemaining = turns;
    }

    public double getDodgeRateReduction() {
        return dodgeRateReduction;
    }

    public int getDodgeRateReductionTurnsRemaining() {
        return dodgeRateReductionTurnsRemaining;
    }

    public void tickDodgeRateReduction() {
        if (dodgeRateReductionTurnsRemaining > 0) {
            dodgeRateReductionTurnsRemaining--;
            if (dodgeRateReductionTurnsRemaining == 0) {
                dodgeRateReduction = 0.0;
            }
        }
    }

    public void applyCurse(int damagePerStack, int stacks, int turns) {
        this.curseDamage = damagePerStack;
        this.curseStacks = stacks;
        this.curseTurnsRemaining = turns;
        if (stacks > 0) {
            this.preventRevive = true;
        }
    }

    public void tickCurse() {
        if (curseTurnsRemaining > 0 && curseStacks > 0) {
            int totalCurseDamage = curseDamage * curseStacks;
            takeDamage(totalCurseDamage, true);
            curseTurnsRemaining--;
            if (curseTurnsRemaining == 0) {
                curseDamage = 0;
                curseStacks = 0;
                preventRevive = false;
            }
        }
    }

    public int getCurseDamage() {
        return curseDamage;
    }

    public int getCurseStacks() {
        return curseStacks;
    }

    public int getCurseTurnsRemaining() {
        return curseTurnsRemaining;
    }

    public boolean isPreventRevive() {
        return preventRevive;
    }

    public void setPreventRevive(boolean prevent) {
        this.preventRevive = prevent;
    }

    public void applyMpDrain(int drain, int turns) {
        this.mpDrainPerTurn = drain;
        this.mpDrainTurnsRemaining = turns;
    }

    public void tickMpDrain() {
        if (mpDrainTurnsRemaining > 0 && mpDrainPerTurn > 0) {
            consumeMP(mpDrainPerTurn);
            mpDrainTurnsRemaining--;
            if (mpDrainTurnsRemaining == 0) {
                mpDrainPerTurn = 0;
            }
        }
    }

    public int getMpDrainPerTurn() {
        return mpDrainPerTurn;
    }

    public int getMpDrainTurnsRemaining() {
        return mpDrainTurnsRemaining;
    }

    public boolean isBuffSuppressed() {
        return buffSuppressed;
    }

    public void setBuffSuppressed(boolean suppressed) {
        this.buffSuppressed = suppressed;
    }

    public void applyBuffSuppression(int turns) {
        this.buffSuppressed = true;
        this.buffSuppressedTurnsRemaining = turns;
    }

    public void tickBuffSuppression() {
        if (buffSuppressedTurnsRemaining > 0) {
            buffSuppressedTurnsRemaining--;
            if (buffSuppressedTurnsRemaining == 0) {
                buffSuppressed = false;
            }
        }
    }

    public int getBuffSuppressedTurnsRemaining() {
        return buffSuppressedTurnsRemaining;
    }

    @Override
    public String toString() {
        return String.format("Character{id='%s', name='%s', hp=%d/%d, mp=%d/%d, hitRate=%.0f%%, dodgeRate=%.0f%%}",
                id, name, hp, maxHp, mp, maxMp, hitRate * 100, dodgeRate * 100);
    }
}