package com.game.rpg.model.entities;

import com.game.rpg.core.battle.HitSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

public class Mummy extends Enemy {
    private static final Logger logger = LoggerFactory.getLogger(Mummy.class);

    private static final int MAX_HP = 220;
    private static final int MAX_MP = 45;
    private static final int INITIAL_MP = 23;
    private static final int ATTACK_POWER = 55;
    private static final double HIT_RATE = 0.90;
    private static final double DODGE_RATE = 0.05;
    private static final double HEAL_REDUCTION = 0.20;

    private final HitSystem hitSystem;

    public Mummy() {
        super("mummy", "木乃伊怪", MAX_HP, MAX_MP, INITIAL_MP, ATTACK_POWER,
                HIT_RATE, DODGE_RATE, false, 0.0);
        this.hitSystem = new HitSystem();
    }

    public double getHealReduction() {
        return HEAL_REDUCTION;
    }

    @Override
    public void heal(int amount) {
        int reducedAmount = (int) Math.round(amount * (1.0 - HEAL_REDUCTION));
        super.heal(reducedAmount);
    }

    public AttackResult normalAttack(Character target, Consumer<String> battleLog) {
        HitSystem.HitResult hitResult = hitSystem.resolveHit(this, target);

        if (hitResult.isMissed()) {
            String msg = String.format("「绷带抽击」被 %s 闪避了！", target.getName());
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
            return AttackResult.missed("绷带抽击", 0);
        }

        int damage = getAttackPower();
        target.takeDamage(damage);

        String msg = String.format("「绷带抽击」命中！对 %s 造成 %d 点伤害！", target.getName(), damage);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("绷带抽击", damage);
    }
}
