package com.game.rpg.model.entities;

import com.game.rpg.core.battle.HitSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

public class SaberAlter extends Enemy {
    private static final Logger logger = LoggerFactory.getLogger(SaberAlter.class);

    private static final int MAX_HP = 550;
    private static final int MAX_MP = 150;
    private static final int INITIAL_MP = 70;
    private static final int ATTACK_POWER = 100;
    private static final double HIT_RATE = 1.0;
    private static final double DODGE_RATE = 0.0;
    private static final double DAMAGE_REDUCTION = 0.20;
    private static final int MP_REGEN_PER_TURN = 15;
    private static final double SELF_DAMAGE_RATIO = 0.05;
    private static final int GRAIL_LIBERATION_MP_THRESHOLD = 80;
    private static final double GRAIL_LIBERATION_ATK_BOOST = 0.30;

    private static final int NORMAL_ATTACK_DAMAGE = 100;
    private static final int NORMAL_ATTACK_DAMAGE_GRAIL = 180;
    private static final int NOBLE_PHANTASM_MP_COST = 20;
    private static final int DEBUFF_DURATION = 3;
    private static final int DEBUFF_DOT_DAMAGE = 25;
    private static final int DEBUFF_MP_DRAIN = 10;
    private static final double DEBUFF_HEAL_REDUCTION = 0.50;

    private static final double HIDDEN_SKILL_HP_THRESHOLD = 0.30;
    private static final int HIDDEN_SKILL_DAMAGE = 180;

    private boolean grailLiberation;
    private boolean hiddenSkillTriggered;

    public SaberAlter() {
        super("saber_alter", "黑化阿尔托莉雅", MAX_HP, MAX_MP, INITIAL_MP, ATTACK_POWER,
                HIT_RATE, DODGE_RATE, true, 0.0);
        setDamageReduction(DAMAGE_REDUCTION);
        this.grailLiberation = false;
        this.hiddenSkillTriggered = false;
    }

    public boolean isGrailLiberation() {
        return grailLiberation;
    }

    public boolean isHiddenSkillTriggered() {
        return hiddenSkillTriggered;
    }

    @Override
    public void onTurnEnd() {
        restoreMP(MP_REGEN_PER_TURN);

        int selfDamage = (int) Math.round(getHp() * SELF_DAMAGE_RATIO);
        takeDamage(selfDamage, true);

        if (!grailLiberation && getMp() >= GRAIL_LIBERATION_MP_THRESHOLD) {
            grailLiberation = true;
            logger.info("圣杯解放！攻击力提升30%！");
        }

        checkHiddenSkill(null);
    }

    public AttackResult normalAttack(Character target, Consumer<String> battleLog) {
        int damage = grailLiberation ? NORMAL_ATTACK_DAMAGE_GRAIL : NORMAL_ATTACK_DAMAGE;
        target.takeDamage(damage, true);

        String skillName = "誓约胜利之剑";
        if (grailLiberation) {
            target.applyBuffSuppression(DEBUFF_DURATION);
            String msg = String.format("「%s」命中！圣杯解放状态！对 %s 造成 %d 点伤害！清除增益效果（%d回合后恢复）！",
                    skillName, target.getName(), damage, DEBUFF_DURATION);
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
        } else {
            String msg = String.format("「%s」命中！对 %s 造成 %d 点伤害！", skillName, target.getName(), damage);
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
        }

        return AttackResult.hit(skillName, damage);
    }

    public AttackResult noblePhantasm(Character target, Consumer<String> battleLog) {
        if (!canCastSkill(NOBLE_PHANTASM_MP_COST)) {
            String msg = "蓝量不足，无法释放「圣杯诅咒」！";
            logger.warn(msg);
            if (battleLog != null) battleLog.accept(msg);
            return AttackResult.missed("圣杯诅咒", 0);
        }

        consumeMP(NOBLE_PHANTASM_MP_COST);

        target.applyPoison(DEBUFF_DOT_DAMAGE, DEBUFF_DURATION);
        target.applyMpDrain(DEBUFF_MP_DRAIN, DEBUFF_DURATION);
        target.setHealReduction(DEBUFF_HEAL_REDUCTION);

        String msg = String.format("「圣杯诅咒」命中！对 %s 施加诅咒：每回合 %d 点伤害、%d 点MP流失、治疗降低50%%，持续 %d 回合！",
                target.getName(), DEBUFF_DOT_DAMAGE, DEBUFF_MP_DRAIN, DEBUFF_DURATION);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("圣杯诅咒", 0);
    }

    public void checkHiddenSkill(Consumer<String> battleLog) {
        if (hiddenSkillTriggered || !isAlive()) {
            return;
        }
        if (getHp() <= (int) Math.round(getMaxHp() * HIDDEN_SKILL_HP_THRESHOLD)) {
            hiddenSkillTriggered = true;
            logger.info("终焉一击触发条件达成！HP降至30%以下！");
        }
    }

    public AttackResult executeHiddenSkill(Character target, Consumer<String> battleLog) {
        if (!hiddenSkillTriggered) {
            return null;
        }

        target.takeDamage(HIDDEN_SKILL_DAMAGE, true);

        String msg = String.format("「终焉一击」！对 %s 造成 %d 点真实伤害！强制结束当前回合！",
                target.getName(), HIDDEN_SKILL_DAMAGE);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("终焉一击", HIDDEN_SKILL_DAMAGE);
    }
}