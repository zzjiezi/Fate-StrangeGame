package com.game.rpg.model.entities;

import com.game.rpg.core.battle.HitSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

public class ArcherAlter extends Enemy {
    private static final Logger logger = LoggerFactory.getLogger(ArcherAlter.class);

    private static final int MAX_HP = 500;
    private static final int MAX_MP = 40;
    private static final int INITIAL_MP = 40;
    private static final int ATTACK_POWER = 100;
    private static final double HIT_RATE = 0.85;
    private static final double DODGE_RATE = 0.10;
    private static final double DAMAGE_REDUCTION = 0.15;

    private static final double DMG_BONUS_PER_10HP = 0.05;
    private static final double DMG_BONUS_CAP = 0.30;
    private static final double LOW_HP_THRESHOLD = 0.30;
    private static final int LOW_HP_AOE_DAMAGE = 20;

    private static final int NORMAL_ATTACK_DAMAGE = 70;

    private static final int NOBLE_PHANTASM_MP_COST = 50;
    private static final int NOBLE_PHANTASM_DAMAGE = 180;
    private static final int CURSE_DAMAGE_PER_STACK = 15;
    private static final int CURSE_STACKS = 2;
    private static final int CURSE_DURATION = 3;

    private static final double HIDDEN_SKILL_HP_THRESHOLD = 0.30;
    private static final int HIDDEN_SKILL_DAMAGE = 110;

    private final HitSystem hitSystem;
    private boolean hiddenSkillTriggered;

    public ArcherAlter() {
        super("archer_alter", "黑化鹿目圆", MAX_HP, MAX_MP, INITIAL_MP, ATTACK_POWER,
                HIT_RATE, DODGE_RATE, false, 0.0);
        setDamageReduction(DAMAGE_REDUCTION);
        this.hitSystem = new HitSystem();
        this.hiddenSkillTriggered = false;
    }

    public boolean isHiddenSkillTriggered() {
        return hiddenSkillTriggered;
    }

    public double getDamageBonus() {
        double hpLostRatio = 1.0 - ((double) getHp() / getMaxHp());
        double bonus = (int) (hpLostRatio * 10) * DMG_BONUS_PER_10HP;
        return Math.min(bonus, DMG_BONUS_CAP);
    }

    @Override
    public void onTurnEnd() {
        if (getHp() < (int) Math.round(getMaxHp() * LOW_HP_THRESHOLD)) {
            logger.debug("因果逆转：低血量自动AOE {} 真伤", LOW_HP_AOE_DAMAGE);
        }
        checkHiddenSkill(null);
    }

    public int getLowHpAoeDamage() {
        if (getHp() < (int) Math.round(getMaxHp() * LOW_HP_THRESHOLD)) {
            return LOW_HP_AOE_DAMAGE;
        }
        return 0;
    }

    public AttackResult normalAttack(Character target, Consumer<String> battleLog) {
        HitSystem.HitResult hitResult = hitSystem.resolveHit(this, target);

        if (hitResult.isMissed()) {
            String msg = String.format("「绝望之矢」被 %s 闪避了！", target.getName());
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
            return AttackResult.missed("绝望之矢", 0);
        }

        double bonus = getDamageBonus();
        int damage = (int) Math.round(NORMAL_ATTACK_DAMAGE * (1.0 + bonus));
        target.takeDamage(damage);

        String msg = String.format("「绝望之矢」命中！对 %s 造成 %d 点伤害！%.0f%%伤害加成",
                target.getName(), damage, bonus * 100);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("绝望之矢", damage);
    }

    public AttackResult noblePhantasm(Character target, Consumer<String> battleLog) {
        if (!canCastSkill(NOBLE_PHANTASM_MP_COST)) {
            String msg = "蓝量不足，无法释放「裁决魔女」！";
            logger.warn(msg);
            if (battleLog != null) battleLog.accept(msg);
            return AttackResult.missed("裁决魔女", 0);
        }

        consumeMP(NOBLE_PHANTASM_MP_COST);

        HitSystem.HitResult hitResult = hitSystem.resolveHit(this, target);

        if (hitResult.isMissed()) {
            String msg = String.format("「裁决魔女」被 %s 闪避了！", target.getName());
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
            return AttackResult.missed("裁决魔女", 0);
        }

        int damage = NOBLE_PHANTASM_DAMAGE;
        target.takeDamage(damage, true);
        target.applyCurse(CURSE_DAMAGE_PER_STACK, CURSE_STACKS, CURSE_DURATION);

        String msg = String.format("「裁决魔女」命中！对 %s 造成 %d 点固定伤害！附加 %d 层诅咒（每回合 %d 点，持续 %d 回合）！带诅咒印记死亡无法复活！",
                target.getName(), damage, CURSE_STACKS, CURSE_DAMAGE_PER_STACK * CURSE_STACKS, CURSE_DURATION);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("裁决魔女", damage);
    }

    public void checkHiddenSkill(Consumer<String> battleLog) {
        if (hiddenSkillTriggered || !isAlive()) {
            return;
        }
        if (getHp() <= (int) Math.round(getMaxHp() * HIDDEN_SKILL_HP_THRESHOLD)) {
            hiddenSkillTriggered = true;
            logger.info("终末救赎触发条件达成！HP降至30%以下！");
        }
    }

    public AttackResult executeHiddenSkill(Character target, Consumer<String> battleLog) {
        if (!hiddenSkillTriggered) {
            return null;
        }

        target.takeDamage(HIDDEN_SKILL_DAMAGE, true);
        target.applyBuffSuppression(2);

        String msg = String.format("「终末救赎」！对 %s 造成 %d 点真实伤害！清除所有增益效果（2回合后恢复）！",
                target.getName(), HIDDEN_SKILL_DAMAGE);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("终末救赎", HIDDEN_SKILL_DAMAGE);
    }
}