package com.game.rpg.view.scene;

import com.game.rpg.util.map.SpriteManager;
import com.game.rpg.util.map.TiledMapParser;
import com.game.rpg.util.resource.ResourceLoader;
import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.function.Consumer;

public class GameMapView extends StackPane {
    private static final Logger logger = LoggerFactory.getLogger(GameMapView.class);

    public static final int GAME_WIDTH = 1280;
    public static final int GAME_HEIGHT = 720;
    private static final double PLAYER_SPEED = 2.0;
    private static final double PLAYER_SIZE = 80;

    private final ResourceLoader resourceLoader;
    private final SpriteManager spriteManager;

    private Pane mapPane;
    private ImageView mapBackground;
    private ImageView playerSprite;
    private Pane interactionLayer;
    private Pane npcLayer;

    private StackPane dialogOverlay;
    private ImageView dialogBackgroundImg;
    private Text dialogText;
    private Text dialogContinueHint;
    private VBox dialogChoiceBox;

    private double playerX;
    private double playerY;
    private TiledMapParser.TiledMapData currentMapData;
    private double mapWidth = GAME_WIDTH;
    private double mapHeight = GAME_HEIGHT;

    private double cameraOffsetX = 0;
    private double cameraOffsetY = 0;

    private final Set<KeyCode> pressedKeys = new HashSet<>();
    private javafx.animation.AnimationTimer gameLoop;

    private boolean inputLocked = false;
    private Runnable onClickCallback;
    private boolean waitingForClick = false;

    private final List<InteractionZone> interactionZones = new ArrayList<>();
    private final List<NPCSprite> npcSprites = new ArrayList<>();
    private final Map<String, Boolean> gameFlags = new HashMap<>();

    private String playerDirection = "down";
    private Runnable onFirstMoveCallback;
    private boolean hasMovedOnce = false;

    private static final String PLAYER_FRONT = "/images/characters/player/player 1正面 .png";
    private static final String PLAYER_BACK = "/images/characters/player/player 1背面 .png";
    private static final String PLAYER_LEFT = "/images/characters/player/player 1左视图.png";
    private static final String PLAYER_RIGHT = "/images/characters/player/player 1右视图.png";

    public GameMapView(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
        this.spriteManager = new SpriteManager(resourceLoader);

        setPrefSize(GAME_WIDTH, GAME_HEIGHT);
        setMaxSize(GAME_WIDTH, GAME_HEIGHT);
        setMinSize(GAME_WIDTH, GAME_HEIGHT);
        initializeUI();
        setupInput();
    }

    private void initializeUI() {
        mapPane = new Pane();
        mapPane.setPrefSize(GAME_WIDTH, GAME_HEIGHT);
        mapPane.setClip(new Rectangle(GAME_WIDTH, GAME_HEIGHT));

        mapBackground = new ImageView();
        mapBackground.setPreserveRatio(false);

        interactionLayer = new Pane();
        npcLayer = new Pane();

        playerSprite = new ImageView();
        playerSprite.setFitWidth(PLAYER_SIZE);
        playerSprite.setFitHeight(PLAYER_SIZE);
        playerSprite.setPreserveRatio(true);

        mapPane.getChildren().addAll(mapBackground, interactionLayer, npcLayer, playerSprite);

        dialogOverlay = new StackPane();
        dialogOverlay.setPrefSize(GAME_WIDTH, GAME_HEIGHT);
        dialogOverlay.setVisible(false);
        dialogOverlay.setMouseTransparent(true);

        dialogBackgroundImg = new ImageView();
        dialogBackgroundImg.setPreserveRatio(true);

        dialogText = new Text();
        dialogText.setFont(Font.font("SimSun", 20));
        dialogText.setFill(Color.WHITE);
        dialogText.setWrappingWidth(1140);

        dialogContinueHint = new Text("▼ 点击继续");
        dialogContinueHint.setFont(Font.font("SimSun", 16));
        dialogContinueHint.setFill(Color.WHITE);

        Pane dialogBgPane = new Pane();
        dialogBgPane.getChildren().add(dialogBackgroundImg);

        StackPane dialogTextContainer = new StackPane();
        dialogTextContainer.setPrefWidth(1200);
        dialogTextContainer.setPrefHeight(160);
        dialogTextContainer.getChildren().addAll(dialogBgPane, dialogText);
        StackPane.setAlignment(dialogText, javafx.geometry.Pos.CENTER_LEFT);

        Pane dialogContinuePane = new Pane();
        dialogContinuePane.setPrefWidth(1200);
        dialogContinuePane.setPrefHeight(160);
        dialogContinueHint.setLayoutX(1200 - 100);
        dialogContinueHint.setLayoutY(160 - 30);
        dialogContinuePane.getChildren().add(dialogContinueHint);

        StackPane dialogFrame = new StackPane();
        dialogFrame.setPrefWidth(1200);
        dialogFrame.setPrefHeight(160);
        dialogFrame.getChildren().addAll(dialogBgPane, dialogTextContainer, dialogContinuePane);

        dialogChoiceBox = new VBox(10);
        dialogChoiceBox.setStyle("-fx-alignment: center;");

        VBox dialogContainer = new VBox(5);
        dialogContainer.getChildren().addAll(dialogFrame, dialogChoiceBox);
        StackPane.setAlignment(dialogContainer, javafx.geometry.Pos.BOTTOM_CENTER);
        StackPane.setMargin(dialogContainer, new javafx.geometry.Insets(0, 40, 20, 40));

        dialogOverlay.getChildren().add(dialogContainer);

        getChildren().addAll(mapPane, dialogOverlay);

        setupClickHandler();
    }

    private void setupClickHandler() {
        setOnMouseClicked(e -> {
            if (waitingForClick) {
                waitingForClick = false;
                if (onClickCallback != null) {
                    Runnable cb = onClickCallback;
                    onClickCallback = null;
                    cb.run();
                }
            }
        });
    }

    private void setupInput() {
        sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                bindKeyHandlers(newScene);
            }
        });

        gameLoop = new javafx.animation.AnimationTimer() {
            @Override
            public void handle(long now) {
                if (inputLocked) return;
                updatePlayer();
            }
        };
    }

    private void bindKeyHandlers(Scene scene) {
        scene.setOnKeyPressed(e -> {
            if (!inputLocked) pressedKeys.add(e.getCode());
        });
        scene.setOnKeyReleased(e -> pressedKeys.remove(e.getCode()));
    }

    public void ensureKeyBindings() {
        Scene scene = getScene();
        if (scene != null) {
            bindKeyHandlers(scene);
        }
    }

    private void updatePlayer() {
        double dx = 0, dy = 0;

        if (pressedKeys.contains(KeyCode.UP) || pressedKeys.contains(KeyCode.W)) {
            dy = -PLAYER_SPEED;
            playerDirection = "up";
        }
        if (pressedKeys.contains(KeyCode.DOWN) || pressedKeys.contains(KeyCode.S)) {
            dy = PLAYER_SPEED;
            playerDirection = "down";
        }
        if (pressedKeys.contains(KeyCode.LEFT) || pressedKeys.contains(KeyCode.A)) {
            dx = -PLAYER_SPEED;
            playerDirection = "left";
        }
        if (pressedKeys.contains(KeyCode.RIGHT) || pressedKeys.contains(KeyCode.D)) {
            dx = PLAYER_SPEED;
            playerDirection = "right";
        }

        if (dx == 0 && dy == 0) return;

        if (!hasMovedOnce) {
            hasMovedOnce = true;
            if (onFirstMoveCallback != null) {
                onFirstMoveCallback.run();
                return;
            }
        }

        updatePlayerSprite();

        double newX = playerX + dx;
        double newY = playerY + dy;

        if (newX < 0 || newX + PLAYER_SIZE > mapWidth) dx = 0;
        if (newY < 0 || newY + PLAYER_SIZE > mapHeight) dy = 0;

        newX = playerX + dx;
        newY = playerY + dy;

        if (currentMapData != null) {
            if (currentMapData.isRectColliding(newX, newY, PLAYER_SIZE, PLAYER_SIZE)) {
                if (dx != 0 && currentMapData.isRectColliding(playerX + dx, playerY, PLAYER_SIZE, PLAYER_SIZE)) {
                    dx = 0;
                }
                if (dy != 0 && currentMapData.isRectColliding(playerX, playerY + dy, PLAYER_SIZE, PLAYER_SIZE)) {
                    dy = 0;
                }
                newX = playerX + dx;
                newY = playerY + dy;
                if (currentMapData.isRectColliding(newX, newY, PLAYER_SIZE, PLAYER_SIZE)) return;
            }
        }

        playerX = newX;
        playerY = newY;

        updateCamera();
        updatePlayerScreenPosition();
        checkInteractionZones();
    }

    private void updateCamera() {
        if (mapWidth <= GAME_WIDTH) {
            cameraOffsetX = 0;
        } else {
            double targetX = playerX + PLAYER_SIZE / 2 - GAME_WIDTH / 2;
            cameraOffsetX = Math.max(0, Math.min(targetX, mapWidth - GAME_WIDTH));
        }

        if (mapHeight <= GAME_HEIGHT) {
            cameraOffsetY = 0;
        } else {
            double targetY = playerY + PLAYER_SIZE / 2 - GAME_HEIGHT / 2;
            cameraOffsetY = Math.max(0, Math.min(targetY, mapHeight - GAME_HEIGHT));
        }

        mapBackground.setLayoutX(-cameraOffsetX);
        mapBackground.setLayoutY(-cameraOffsetY);
        interactionLayer.setLayoutX(-cameraOffsetX);
        interactionLayer.setLayoutY(-cameraOffsetY);
        npcLayer.setLayoutX(-cameraOffsetX);
        npcLayer.setLayoutY(-cameraOffsetY);
    }

    private void updatePlayerSprite() {
        String spritePath = switch (playerDirection) {
            case "up" -> PLAYER_BACK;
            case "down" -> PLAYER_FRONT;
            case "left" -> PLAYER_LEFT;
            case "right" -> PLAYER_RIGHT;
            default -> PLAYER_FRONT;
        };
        Image img = spriteManager.getSprite(spritePath);
        if (img != null) {
            playerSprite.setImage(img);
        } else {
            playerSprite.setImage(createPlaceholder(PLAYER_SIZE, PLAYER_SIZE));
        }
    }

    private void updatePlayerScreenPosition() {
        playerSprite.setLayoutX(playerX - cameraOffsetX);
        playerSprite.setLayoutY(playerY - cameraOffsetY);
    }

    private void checkInteractionZones() {
        for (InteractionZone zone : interactionZones) {
            if (!zone.triggered) {
                double playerCenterX = playerX + PLAYER_SIZE / 2;
                double playerCenterY = playerY + PLAYER_SIZE / 2;
                if (zone.rect.contains(playerCenterX, playerCenterY)) {
                    zone.triggered = true;
                    zone.onTrigger.run();
                    return;
                }
            }
        }
    }

    public void loadMap(String mapImagePath, String tmjPath, double spawnX, double spawnY) {
        try {
            Image img = resourceLoader.loadImage(mapImagePath);
            mapBackground.setImage(img);
            mapWidth = img.getWidth();
            mapHeight = img.getHeight();
            mapBackground.setFitWidth(mapWidth);
            mapBackground.setFitHeight(mapHeight);
        } catch (Exception e) {
            logger.warn("Failed to load map image: {}", mapImagePath, e);
            mapBackground.setImage(createPlaceholder(GAME_WIDTH, GAME_HEIGHT));
            mapWidth = GAME_WIDTH;
            mapHeight = GAME_HEIGHT;
            mapBackground.setFitWidth(mapWidth);
            mapBackground.setFitHeight(mapHeight);
        }

        if (tmjPath != null) {
            currentMapData = TiledMapParser.parse(tmjPath);
        } else {
            currentMapData = null;
        }

        playerX = spawnX;
        playerY = spawnY;
        cameraOffsetX = 0;
        cameraOffsetY = 0;

        interactionLayer.getChildren().clear();
        npcLayer.getChildren().clear();
        interactionZones.clear();
        npcSprites.clear();

        updatePlayerSprite();
        updateCamera();
        updatePlayerScreenPosition();

        logger.info("Map loaded: {} at ({}, {}) mapSize={}x{}", mapImagePath, spawnX, spawnY, mapWidth, mapHeight);
    }

    public void addInteractionZone(String id, double x, double y, double w, double h,
                                    Runnable onTrigger, boolean showStarTip) {
        InteractionZone zone = new InteractionZone(id, new TiledMapParser.CollisionRect(x, y, w, h), onTrigger);
        interactionZones.add(zone);

        if (showStarTip) {
            try {
                Image starImg = resourceLoader.loadImage("/images/ui/starTip.png");
                ImageView starView = new ImageView(starImg);
                starView.setLayoutX(x + w / 2 - 16);
                starView.setLayoutY(y + h / 2 - 16);
                interactionLayer.getChildren().add(starView);
            } catch (Exception e) {
                logger.warn("Failed to load starTip.png, using placeholder");
                Rectangle placeholder = new Rectangle(x + w / 2 - 16, y + h / 2 - 16, 32, 32);
                placeholder.setFill(Color.MAGENTA);
                interactionLayer.getChildren().add(placeholder);
            }
        }
    }

    public void addNPC(String id, double x, double y, String spritePath, double width, double height) {
        ImageView npcView;
        try {
            npcView = spriteManager.createSpriteView(spritePath, width, height);
        } catch (Exception e) {
            logger.warn("Failed to load NPC sprite: {}, using placeholder", spritePath);
            npcView = new ImageView(createPlaceholder(width, height));
        }
        npcView.setLayoutX(x);
        npcView.setLayoutY(y);
        npcLayer.getChildren().add(npcView);
        npcSprites.add(new NPCSprite(id, x, y, npcView));
    }

    public void updateNPCSprite(String id, String newSpritePath) {
        for (NPCSprite npc : npcSprites) {
            if (npc.id.equals(id)) {
                Image img = spriteManager.getSprite(newSpritePath);
                if (img != null) {
                    npc.view.setImage(img);
                } else {
                    npc.view.setImage(createPlaceholder(npc.view.getFitWidth(), npc.view.getFitHeight()));
                }
                break;
            }
        }
    }

    private void applyDialogBackground(String dialogBgPath) {
        try {
            Image bgImg = resourceLoader.loadImage(dialogBgPath);
            dialogBackgroundImg.setImage(bgImg);
            dialogBackgroundImg.setFitWidth(1200);
            dialogBackgroundImg.setFitHeight(160);
        } catch (Exception e) {
            logger.warn("Failed to load dialog background: {}", dialogBgPath);
            dialogBackgroundImg.setImage(createPlaceholder(1200, 160));
        }
    }

    public void showDialogWithBackground(String dialogBgPath, String text, Runnable onAdvance) {
        inputLocked = true;
        applyDialogBackground(dialogBgPath);
        dialogText.setText(text);
        dialogContinueHint.setVisible(true);
        dialogChoiceBox.getChildren().clear();
        dialogOverlay.setVisible(true);
        dialogOverlay.setMouseTransparent(false);
        waitingForClick = true;
        onClickCallback = () -> {
            hideDialog();
            if (onAdvance != null) onAdvance.run();
        };
    }

    public void showDialogWithChoice(String dialogBgPath, String text,
                                      List<String> choices, Consumer<Integer> onChoice) {
        inputLocked = true;
        applyDialogBackground(dialogBgPath);
        dialogText.setText(text);
        dialogContinueHint.setVisible(false);
        dialogChoiceBox.getChildren().clear();

        for (int i = 0; i < choices.size(); i++) {
            final int idx = i;
            Button btn = new Button(choices.get(i));
            btn.setFont(Font.font("SimSun", 16));
            btn.setPrefWidth(400);
            btn.setStyle("-fx-background-color: rgba(40,40,40,0.9); -fx-text-fill: white; " +
                    "-fx-border-color: #5a5a5a; -fx-border-width: 2; -fx-padding: 8 16;");
            btn.setOnMouseEntered(e -> btn.setStyle(
                    "-fx-background-color: rgba(60,60,60,0.9); -fx-text-fill: cyan; " +
                            "-fx-border-color: cyan; -fx-border-width: 2; -fx-padding: 8 16;"));
            btn.setOnMouseExited(e -> btn.setStyle(
                    "-fx-background-color: rgba(40,40,40,0.9); -fx-text-fill: white; " +
                            "-fx-border-color: #5a5a5a; -fx-border-width: 2; -fx-padding: 8 16;"));
            btn.setOnAction(e -> {
                hideDialog();
                onChoice.accept(idx);
            });
            dialogChoiceBox.getChildren().add(btn);
        }

        dialogOverlay.setVisible(true);
        dialogOverlay.setMouseTransparent(false);
    }

    public void showFullScreenOverlay(String text, Runnable onAdvance) {
        inputLocked = true;

        StackPane overlay = new StackPane();
        overlay.setPrefSize(GAME_WIDTH, GAME_HEIGHT);

        Rectangle bg = new Rectangle(GAME_WIDTH, GAME_HEIGHT);
        bg.setFill(Color.BLACK);
        bg.setOpacity(0.7);

        Text overlayText = new Text(text);
        overlayText.setFont(Font.font("SimSun", 24));
        overlayText.setFill(Color.WHITE);
        overlayText.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        overlayText.setWrappingWidth(1000);
        overlayText.setLineSpacing(24 * 0.8);

        Text continueHint = new Text("点击任意处继续");
        continueHint.setFont(Font.font("SimSun", 16));
        continueHint.setFill(Color.WHITE);

        VBox contentBox = new VBox(20);
        contentBox.setAlignment(javafx.geometry.Pos.CENTER);
        contentBox.getChildren().add(overlayText);

        overlay.getChildren().addAll(bg, contentBox, continueHint);
        StackPane.setAlignment(contentBox, javafx.geometry.Pos.CENTER);
        StackPane.setAlignment(continueHint, javafx.geometry.Pos.BOTTOM_CENTER);
        StackPane.setMargin(continueHint, new javafx.geometry.Insets(0, 0, 30, 0));

        getChildren().add(overlay);
        waitingForClick = true;
        onClickCallback = () -> {
            getChildren().remove(overlay);
            if (onAdvance != null) onAdvance.run();
        };
    }

    public void showScreenShake(Runnable onComplete) {
        inputLocked = true;
        double origX = mapPane.getTranslateX();
        double origY = mapPane.getTranslateY();

        javafx.animation.Timeline shake = new javafx.animation.Timeline(
                new javafx.animation.KeyFrame(Duration.millis(50), e -> mapPane.setTranslateX(origX + 10)),
                new javafx.animation.KeyFrame(Duration.millis(100), e -> mapPane.setTranslateX(origX - 10)),
                new javafx.animation.KeyFrame(Duration.millis(150), e -> mapPane.setTranslateX(origX + 6)),
                new javafx.animation.KeyFrame(Duration.millis(200), e -> mapPane.setTranslateX(origX - 6)),
                new javafx.animation.KeyFrame(Duration.millis(250), e -> mapPane.setTranslateX(origX + 3)),
                new javafx.animation.KeyFrame(Duration.millis(300), e -> {
                    mapPane.setTranslateX(origX);
                    mapPane.setTranslateY(origY);
                })
        );
        shake.setOnFinished(e -> {
            if (onComplete != null) onComplete.run();
        });
        shake.play();
    }

    public void showRedFlash(Runnable onComplete) {
        Rectangle redFlash = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.RED);
        redFlash.setOpacity(0);
        redFlash.setMouseTransparent(true);
        getChildren().add(redFlash);

        FadeTransition flashIn = new FadeTransition(Duration.millis(150), redFlash);
        flashIn.setFromValue(0.0);
        flashIn.setToValue(0.8);

        FadeTransition flashOut = new FadeTransition(Duration.millis(300), redFlash);
        flashOut.setFromValue(0.8);
        flashOut.setToValue(0.0);
        flashOut.setOnFinished(e -> {
            getChildren().remove(redFlash);
            if (onComplete != null) onComplete.run();
        });

        SequentialTransition seq = new SequentialTransition(flashIn, flashOut);
        seq.play();
    }

    public void showBlackScreen(long waitMs, Runnable onComplete) {
        inputLocked = true;
        Rectangle black = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.BLACK);
        black.setMouseTransparent(true);
        getChildren().add(black);

        if (waitMs > 0) {
            PauseTransition wait = new PauseTransition(Duration.millis(waitMs));
            wait.setOnFinished(e -> {
                getChildren().remove(black);
                if (onComplete != null) onComplete.run();
            });
            wait.play();
        } else {
            waitingForClick = true;
            onClickCallback = () -> {
                getChildren().remove(black);
                if (onComplete != null) onComplete.run();
            };
        }
    }

    public void showBlackScreenWithText(String text, Runnable onAdvance) {
        inputLocked = true;

        StackPane overlay = new StackPane();
        overlay.setPrefSize(GAME_WIDTH, GAME_HEIGHT);

        Rectangle bg = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.BLACK);

        Text overlayText = new Text(text);
        overlayText.setFont(Font.font("SimSun", 24));
        overlayText.setFill(Color.WHITE);
        overlayText.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);

        Text continueHint = new Text("点击任意处继续");
        continueHint.setFont(Font.font("SimSun", 16));
        continueHint.setFill(Color.WHITE);

        VBox contentBox = new VBox(20);
        contentBox.setAlignment(javafx.geometry.Pos.CENTER);
        contentBox.getChildren().add(overlayText);

        overlay.getChildren().addAll(bg, contentBox, continueHint);
        StackPane.setAlignment(contentBox, javafx.geometry.Pos.CENTER);
        StackPane.setAlignment(continueHint, javafx.geometry.Pos.BOTTOM_CENTER);
        StackPane.setMargin(continueHint, new javafx.geometry.Insets(0, 0, 30, 0));

        getChildren().add(overlay);
        waitingForClick = true;
        onClickCallback = () -> {
            getChildren().remove(overlay);
            if (onAdvance != null) onAdvance.run();
        };
    }

    public void showBlackScreenTimed(long waitMs, Runnable onComplete) {
        inputLocked = true;
        Rectangle black = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.BLACK);
        black.setMouseTransparent(true);
        getChildren().add(black);

        PauseTransition wait = new PauseTransition(Duration.millis(waitMs));
        wait.setOnFinished(e -> {
            getChildren().remove(black);
            if (onComplete != null) onComplete.run();
        });
        wait.play();
    }

    public void hideDialog() {
        dialogOverlay.setVisible(false);
        dialogOverlay.setMouseTransparent(true);
        dialogChoiceBox.getChildren().clear();
        inputLocked = false;
    }

    public void unlockInput() {
        inputLocked = false;
    }

    public void lockInput() {
        inputLocked = true;
    }

    public void startGameLoop() {
        gameLoop.start();
    }

    public void stopGameLoop() {
        gameLoop.stop();
        pressedKeys.clear();
    }

    public void setFlag(String key, boolean value) {
        gameFlags.put(key, value);
    }

    public boolean getFlag(String key) {
        return gameFlags.getOrDefault(key, false);
    }

    public void resetInteractionZone(String id) {
        for (InteractionZone zone : interactionZones) {
            if (zone.id.equals(id)) {
                zone.triggered = false;
            }
        }
    }

    public void setPlayerPosition(double x, double y) {
        playerX = x;
        playerY = y;
        updateCamera();
        updatePlayerScreenPosition();
    }

    public void setOnFirstMove(Runnable callback) {
        this.onFirstMoveCallback = callback;
    }

    private Image createPlaceholder(double w, double h) {
        javafx.scene.image.WritableImage placeholder = new javafx.scene.image.WritableImage((int) w, (int) h);
        var writer = placeholder.getPixelWriter();
        for (int py = 0; py < (int) h; py++) {
            for (int px = 0; px < (int) w; px++) {
                writer.setColor(px, py, Color.MAGENTA);
            }
        }
        return placeholder;
    }

    private static class InteractionZone {
        final String id;
        final TiledMapParser.CollisionRect rect;
        final Runnable onTrigger;
        boolean triggered;

        InteractionZone(String id, TiledMapParser.CollisionRect rect, Runnable onTrigger) {
            this.id = id;
            this.rect = rect;
            this.onTrigger = onTrigger;
            this.triggered = false;
        }
    }

    private record NPCSprite(String id, double x, double y, ImageView view) {}
}
