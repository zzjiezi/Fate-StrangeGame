package com.game.rpg.view.scene;

import com.game.rpg.model.entities.AttackResult;
import com.game.rpg.model.entities.Character;
import com.game.rpg.model.entities.Enemy;
import com.game.rpg.model.enums.CommandSpellEffect;
import com.game.rpg.util.resource.SoundManager;
import javafx.animation.FadeTransition;
import javafx.animation.Timeline;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class BattleView extends StackPane {
    private static final double WINDOW_WIDTH = 1280;
    private static final double WINDOW_HEIGHT = 720;

    private ImageView backgroundImage;
    private VBox enemyInfoBox;
    private ImageView enemyImageView;
    private ProgressBar enemyHpBar;
    private Label enemyHpLabel;
    private ProgressBar enemyMpBar;
    private Label enemyMpLabel;

    private HBox charactersBox;
    private final List<ImageView> characterImageViews = new ArrayList<>();
    private final List<Label> characterNameLabels = new ArrayList<>();
    private int selectedCharacterIndex = -1;

    private VBox selectedCharInfoBox;
    private ProgressBar selectedCharHpBar;
    private Label selectedCharHpLabel;
    private ProgressBar selectedCharMpBar;
    private Label selectedCharMpLabel;

    private VBox battleTextBox;
    private final List<Label> battleTextLabels = new ArrayList<>();

    private HBox actionButtonsBox;
    private Button attackButton;
    private Button noblePhantasmButton;
    private Button commandSpellButton;
    private Button fleeButton;
    private Label fleeDisabledLabel;

    private VBox commandSpellBox;
    private final List<Label> commandSpellLabels = new ArrayList<>();
    private Label noCommandSpellLabel;

    private ImageView fullScreenOverlay;

    private VBox mainBattleArea;

    private Consumer<Integer> onCharacterSelected;
    private Consumer<String> onAttack;
    private Consumer<String> onNoblePhantasm;
    private Consumer<CommandSpellEffect> onCommandSpell;
    private Runnable onFlee;
    private Runnable onContinueClicked;

    private boolean isBossBattle = false;

    public BattleView() {
        initializeUI();
    }

    private void initializeUI() {
        setPrefSize(WINDOW_WIDTH, WINDOW_HEIGHT);

        backgroundImage = new ImageView();
        backgroundImage.setFitWidth(WINDOW_WIDTH);
        backgroundImage.setFitHeight(WINDOW_HEIGHT);
        backgroundImage.setPreserveRatio(false);
        try {
            Image bg = new Image(getClass().getResource(SoundManager.BATTLE_BACKGROUND).toExternalForm());
            backgroundImage.setImage(bg);
        } catch (Exception e) {
            backgroundImage.setStyle("-fx-background-color: #0d0d1a;");
        }

        VBox container = new VBox();
        container.setAlignment(Pos.CENTER);
        container.setPrefWidth(WINDOW_WIDTH * 0.8);
        container.setMaxWidth(WINDOW_WIDTH * 0.8);

        enemyInfoBox = createEnemyInfoBox();
        mainBattleArea = createMainBattleArea();
        selectedCharInfoBox = createSelectedCharInfoBox();
        battleTextBox = createBattleTextBox();
        actionButtonsBox = createActionButtonsBox();
        commandSpellBox = createCommandSpellBox();

        container.getChildren().addAll(enemyInfoBox, mainBattleArea, selectedCharInfoBox, battleTextBox, actionButtonsBox, commandSpellBox);
        StackPane.setAlignment(container, Pos.BOTTOM_CENTER);
        StackPane.setMargin(container, new Insets(0, 0, 20, 0));

        fullScreenOverlay = new ImageView();
        fullScreenOverlay.setFitWidth(WINDOW_WIDTH);
        fullScreenOverlay.setFitHeight(WINDOW_HEIGHT);
        fullScreenOverlay.setPreserveRatio(false);
        fullScreenOverlay.setVisible(false);
        fullScreenOverlay.setMouseTransparent(false);

        getChildren().addAll(backgroundImage, container, fullScreenOverlay);
    }

    private VBox createEnemyInfoBox() {
        VBox box = new VBox(5);
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(10));

        enemyImageView = new ImageView();
        enemyImageView.setFitWidth(120);
        enemyImageView.setFitHeight(120);
        enemyImageView.setPreserveRatio(true);

        HBox hpBox = new HBox(5);
        hpBox.setAlignment(Pos.CENTER_LEFT);
        Label hpTitle = new Label("HP：");
        hpTitle.setTextFill(Color.WHITE);
        hpTitle.setFont(Font.font(14));
        enemyHpBar = new ProgressBar(1.0);
        enemyHpBar.setPrefWidth(200);
        enemyHpBar.setStyle("-fx-accent: red;");
        enemyHpLabel = new Label("0/0");
        enemyHpLabel.setTextFill(Color.WHITE);
        enemyHpLabel.setFont(Font.font(14));
        hpBox.getChildren().addAll(hpTitle, enemyHpBar, enemyHpLabel);

        HBox mpBox = new HBox(5);
        mpBox.setAlignment(Pos.CENTER_LEFT);
        Label mpTitle = new Label("MP：");
        mpTitle.setTextFill(Color.WHITE);
        mpTitle.setFont(Font.font(14));
        enemyMpBar = new ProgressBar(1.0);
        enemyMpBar.setPrefWidth(200);
        enemyMpBar.setStyle("-fx-accent: dodgerblue;");
        enemyMpLabel = new Label("0/0");
        enemyMpLabel.setTextFill(Color.WHITE);
        enemyMpLabel.setFont(Font.font(14));
        mpBox.getChildren().addAll(mpTitle, enemyMpBar, enemyMpLabel);

        box.getChildren().addAll(enemyImageView, hpBox, mpBox);
        return box;
    }

    private VBox createMainBattleArea() {
        VBox area = new VBox(10);
        area.setAlignment(Pos.CENTER);
        area.setPadding(new Insets(15));
        area.setStyle("-fx-background-color: rgba(20, 20, 40, 0.85); -fx-border-color: #e6b800; -fx-border-width: 2; -fx-border-radius: 5;");

        charactersBox = new HBox(40);
        charactersBox.setAlignment(Pos.CENTER);

        area.getChildren().add(charactersBox);
        return area;
    }

    private VBox createSelectedCharInfoBox() {
        VBox box = new VBox(5);
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(5));
        box.setVisible(false);

        HBox hpBox = new HBox(5);
        hpBox.setAlignment(Pos.CENTER_LEFT);
        Label hpTitle = new Label("HP：");
        hpTitle.setTextFill(Color.WHITE);
        hpTitle.setFont(Font.font(13));
        selectedCharHpBar = new ProgressBar(1.0);
        selectedCharHpBar.setPrefWidth(180);
        selectedCharHpBar.setStyle("-fx-accent: red;");
        selectedCharHpLabel = new Label("0/0");
        selectedCharHpLabel.setTextFill(Color.WHITE);
        selectedCharHpLabel.setFont(Font.font(13));
        hpBox.getChildren().addAll(hpTitle, selectedCharHpBar, selectedCharHpLabel);

        HBox mpBox = new HBox(5);
        mpBox.setAlignment(Pos.CENTER_LEFT);
        Label mpTitle = new Label("MP：");
        mpTitle.setTextFill(Color.WHITE);
        mpTitle.setFont(Font.font(13));
        selectedCharMpBar = new ProgressBar(1.0);
        selectedCharMpBar.setPrefWidth(180);
        selectedCharMpBar.setStyle("-fx-accent: dodgerblue;");
        selectedCharMpLabel = new Label("0/0");
        selectedCharMpLabel.setTextFill(Color.WHITE);
        selectedCharMpLabel.setFont(Font.font(13));
        mpBox.getChildren().addAll(mpTitle, selectedCharMpBar, selectedCharMpLabel);

        box.getChildren().addAll(hpBox, mpBox);
        return box;
    }

    private VBox createBattleTextBox() {
        VBox box = new VBox(5);
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(10));
        box.setVisible(false);
        box.setStyle("-fx-background-color: rgba(0, 0, 0, 0.6);");
        box.setOnMouseClicked(e -> {
            if (onContinueClicked != null) onContinueClicked.run();
        });
        return box;
    }

    private HBox createActionButtonsBox() {
        HBox box = new HBox(20);
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(10));

        attackButton = new Button("攻击");
        attackButton.setPrefWidth(100);
        attackButton.setOnAction(e -> {
            if (onAttack != null) onAttack.accept("attack");
        });

        noblePhantasmButton = new Button("宝具");
        noblePhantasmButton.setPrefWidth(100);
        noblePhantasmButton.setOnAction(e -> {
            if (onNoblePhantasm != null) onNoblePhantasm.accept("noble_phantasm");
        });

        commandSpellButton = new Button("令咒");
        commandSpellButton.setPrefWidth(100);
        commandSpellButton.setOnAction(e -> showCommandSpellSelection());

        fleeButton = new Button("逃跑");
        fleeButton.setPrefWidth(100);
        fleeButton.setOnAction(e -> {
            if (onFlee != null) onFlee.run();
        });

        fleeDisabledLabel = new Label("（你被注视着，无法离开）");
        fleeDisabledLabel.setTextFill(Color.GRAY);
        fleeDisabledLabel.setFont(Font.font(12));
        fleeDisabledLabel.setVisible(false);

        VBox fleeBox = new VBox(2);
        fleeBox.setAlignment(Pos.CENTER);
        fleeBox.getChildren().addAll(fleeButton, fleeDisabledLabel);

        box.getChildren().addAll(attackButton, noblePhantasmButton, commandSpellButton, fleeBox);
        return box;
    }

    private VBox createCommandSpellBox() {
        VBox box = new VBox(8);
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(10));
        box.setStyle("-fx-background-color: rgba(20, 20, 40, 0.9); -fx-border-color: #8b0000; -fx-border-width: 2;");
        box.setVisible(false);

        for (CommandSpellEffect effect : CommandSpellEffect.values()) {
            Label label = new Label(effect.getDisplayName());
            label.setTextFill(Color.WHITE);
            label.setFont(Font.font(16));
            label.setStyle("-fx-cursor: hand;");
            label.setOnMouseClicked(e -> {
                if (!label.isDisabled() && onCommandSpell != null) {
                    onCommandSpell.accept(effect);
                }
            });
            commandSpellLabels.add(label);
            box.getChildren().add(label);
        }

        noCommandSpellLabel = new Label("无令咒效果可选");
        noCommandSpellLabel.setTextFill(Color.GRAY);
        noCommandSpellLabel.setFont(Font.font(14));
        noCommandSpellLabel.setVisible(false);
        box.getChildren().add(noCommandSpellLabel);

        return box;
    }

    public void setupCharacters(List<Character> characters) {
        charactersBox.getChildren().clear();
        characterImageViews.clear();
        characterNameLabels.clear();

        for (int i = 0; i < characters.size(); i++) {
            Character ch = characters.get(i);
            VBox charBox = new VBox(5);
            charBox.setAlignment(Pos.CENTER);

            ImageView iv = new ImageView();
            iv.setFitWidth(80);
            iv.setFitHeight(80);
            iv.setPreserveRatio(true);
            iv.setStyle("-fx-cursor: hand;");

            int index = i;
            iv.setOnMouseClicked(e -> selectCharacter(index));

            Label nameLabel = new Label(ch.getName());
            nameLabel.setTextFill(Color.WHITE);
            nameLabel.setFont(Font.font(12));

            charBox.getChildren().addAll(iv, nameLabel);
            charactersBox.getChildren().add(charBox);
            characterImageViews.add(iv);
            characterNameLabels.add(nameLabel);
        }
    }

    public void selectCharacter(int index) {
        selectedCharacterIndex = index;
        for (int i = 0; i < characterImageViews.size(); i++) {
            ImageView iv = characterImageViews.get(i);
            if (i == index) {
                iv.setEffect(new DropShadow(10, Color.GOLD));
            } else {
                iv.setEffect(null);
            }
        }
        if (onCharacterSelected != null) onCharacterSelected.accept(index);
    }

    public void updateEnemyInfo(Enemy enemy) {
        if (enemy == null) return;
        enemyHpBar.setProgress((double) enemy.getHp() / enemy.getMaxHp());
        enemyHpLabel.setText(enemy.getHp() + "/" + enemy.getMaxHp());
        enemyMpBar.setProgress(enemy.getMaxMp() > 0 ? (double) enemy.getMp() / enemy.getMaxMp() : 0);
        enemyMpLabel.setText(enemy.getMp() + "/" + enemy.getMaxMp());
    }

    public void updateSelectedCharInfo(Character ch) {
        if (ch == null) {
            selectedCharInfoBox.setVisible(false);
            return;
        }
        selectedCharInfoBox.setVisible(true);
        selectedCharHpBar.setProgress((double) ch.getHp() / ch.getMaxHp());
        selectedCharHpLabel.setText(ch.getHp() + "/" + ch.getMaxHp());
        selectedCharMpBar.setProgress((double) ch.getMp() / ch.getMaxMp());
        selectedCharMpLabel.setText(ch.getMp() + "/" + ch.getMaxMp());
    }

    public void setCharacterDead(int index, boolean hasReviveSpell) {
        if (index < 0 || index >= characterImageViews.size()) return;
        ImageView iv = characterImageViews.get(index);
        iv.setOpacity(0.3);
        iv.setEffect(null);
        if (hasReviveSpell) {
            iv.setOnMouseClicked(e -> {
                showBattleText(List.of("该角色已阵亡，是否使用复活令咒？"));
            });
        } else {
            iv.setOnMouseClicked(e -> {
                showBattleText(List.of("该角色已阵亡，无可用复活令咒"));
            });
        }
    }

    public void setCharacterRevived(int index) {
        if (index < 0 || index >= characterImageViews.size()) return;
        ImageView iv = characterImageViews.get(index);
        iv.setOpacity(1.0);
        int idx = index;
        iv.setOnMouseClicked(e -> selectCharacter(idx));
    }

    public void showBattleText(List<String> lines) {
        battleTextBox.getChildren().clear();
        battleTextLabels.clear();
        for (String line : lines) {
            Label label = new Label(line);
            label.setTextFill(Color.WHITE);
            label.setFont(Font.font("Microsoft YaHei", 18));
            battleTextLabels.add(label);
            battleTextBox.getChildren().add(label);
        }
        battleTextBox.setVisible(true);
        charactersBox.setVisible(false);
    }

    public void hideBattleText() {
        battleTextBox.setVisible(false);
        charactersBox.setVisible(true);
    }

    public void showCommandSpellSelection() {
        commandSpellBox.setVisible(true);
        actionButtonsBox.setDisable(true);
    }

    public void hideCommandSpellSelection() {
        commandSpellBox.setVisible(false);
        actionButtonsBox.setDisable(false);
    }

    public void updateCommandSpellStates(Character character) {
        boolean allUsed = true;
        CommandSpellEffect[] effects = CommandSpellEffect.values();
        for (int i = 0; i < effects.length; i++) {
            boolean used = character.isCommandSpellUsed(effects[i]);
            commandSpellLabels.get(i).setDisable(used);
            commandSpellLabels.get(i).setOpacity(used ? 0.5 : 1.0);
            if (!used) allUsed = false;
        }
        noCommandSpellLabel.setVisible(allUsed);
    }

    public void flashRed() {
        Color originalBg = (Color) null;
        String originalStyle = getStyle();
        setStyle("-fx-background-color: rgba(255, 0, 0, 0.3);");
        Timeline timeline = new Timeline(
            new KeyFrame(Duration.millis(200), new KeyValue(styleProperty(), originalStyle != null && !originalStyle.isEmpty() ? originalStyle : ""))
        );
        timeline.setOnFinished(e -> setStyle(""));
        timeline.play();
    }

    public void showNoblePhantasmOverlay(Image image) {
        fullScreenOverlay.setImage(image);
        fullScreenOverlay.setVisible(true);
        fullScreenOverlay.toFront();
    }

    public void hideNoblePhantasmOverlay() {
        fullScreenOverlay.setVisible(false);
    }

    public void setBossBattle(boolean isBoss) {
        this.isBossBattle = isBoss;
        fleeButton.setDisable(isBoss);
        fleeDisabledLabel.setVisible(isBoss);
    }

    public void setActionButtonsEnabled(boolean enabled) {
        attackButton.setDisable(!enabled);
        noblePhantasmButton.setDisable(!enabled);
        commandSpellButton.setDisable(!enabled);
        if (!isBossBattle) {
            fleeButton.setDisable(!enabled);
        }
    }

    public void setOnCharacterSelected(Consumer<Integer> handler) { this.onCharacterSelected = handler; }
    public void setOnAttack(Consumer<String> handler) { this.onAttack = handler; }
    public void setOnNoblePhantasm(Consumer<String> handler) { this.onNoblePhantasm = handler; }
    public void setOnCommandSpell(Consumer<CommandSpellEffect> handler) { this.onCommandSpell = handler; }
    public void setOnFlee(Runnable handler) { this.onFlee = handler; }
    public void setOnContinueClicked(Runnable handler) { this.onContinueClicked = handler; }

    public int getSelectedCharacterIndex() { return selectedCharacterIndex; }
    public Button getAttackButton() { return attackButton; }
    public Button getNoblePhantasmButton() { return noblePhantasmButton; }
    public Button getCommandSpellButton() { return commandSpellButton; }
    public Button getFleeButton() { return fleeButton; }
    public ImageView getFullScreenOverlay() { return fullScreenOverlay; }
}