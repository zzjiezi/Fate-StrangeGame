package com.game.rpg.view.component;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class AchievementPopup {
    private static boolean ashGathererUnlocked = false;

    public static boolean isAshGathererUnlocked() {
        return ashGathererUnlocked;
    }

    public static void setAshGathererUnlocked(boolean unlocked) {
        ashGathererUnlocked = unlocked;
    }

    public static void reset() {
        ashGathererUnlocked = false;
    }

    public static void show(Stage ownerStage) {
        if (ashGathererUnlocked) {
            return;
        }
        ashGathererUnlocked = true;

        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.initOwner(ownerStage);
        popupStage.initStyle(StageStyle.UNDECORATED);
        popupStage.setWidth(500);
        popupStage.setHeight(300);

        VBox root = new VBox(10);
        root.setAlignment(Pos.CENTER);
        root.setPadding(new Insets(30));
        root.setStyle("-fx-background-color: #1a1a2e; -fx-border-color: #e6b800; -fx-border-width: 3;");

        Label title = new Label("获得成就：【拾烬者】");
        title.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 24));
        title.setStyle("-fx-text-fill: #e6b800;");
        title.setTextAlignment(TextAlignment.CENTER);

        Label emptyLine = new Label("");

        Label line1 = new Label("散落尘世的百枚残烬，在汝掌心重新相认。");
        line1.setFont(Font.font("Microsoft YaHei", 16));
        line1.setStyle("-fx-text-fill: #cccccc;");
        line1.setTextAlignment(TextAlignment.CENTER);

        Label line2 = new Label("星火自灰烬中抬头——星坠·劫烬 已成。");
        line2.setFont(Font.font("Microsoft YaHei", 16));
        line2.setStyle("-fx-text-fill: #cccccc;");
        line2.setTextAlignment(TextAlignment.CENTER);

        Label line3 = new Label("从此，你是拾烬之人");
        line3.setFont(Font.font("Microsoft YaHei", 16));
        line3.setStyle("-fx-text-fill: #cccccc;");
        line3.setTextAlignment(TextAlignment.CENTER);

        root.getChildren().addAll(title, emptyLine, line1, line2, line3);

        Scene scene = new Scene(root);
        popupStage.setScene(scene);

        root.setOnMouseClicked(e -> popupStage.close());

        popupStage.showAndWait();
    }
}