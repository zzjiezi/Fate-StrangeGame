package com.game.rpg.core.battle;

import com.game.rpg.util.resource.SoundManager;
import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.animation.Timeline;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.scene.Node;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BattleTransitionManager {
    private static final Logger logger = LoggerFactory.getLogger(BattleTransitionManager.class);

    private static final double COLLISION_FLASH_DURATION = 0.1;
    private static final double FADE_OUT_DURATION = 0.5;
    private static final double FADE_IN_DURATION = 0.5;

    private final StackPane rootContainer;
    private final SoundManager soundManager;
    private Node mapView;
    private Node battleView;

    public BattleTransitionManager(StackPane rootContainer, SoundManager soundManager) {
        this.rootContainer = rootContainer;
        this.soundManager = soundManager;
    }

    public void setMapView(Node mapView) {
        this.mapView = mapView;
    }

    public void setBattleView(Node battleView) {
        this.battleView = battleView;
    }

    public void transitionToBattle(Runnable onTransitionComplete) {
        if (mapView == null || battleView == null) {
            logger.warn("Map or battle view not set, skipping transition");
            if (onTransitionComplete != null) onTransitionComplete.run();
            return;
        }

        soundManager.playSfx(SoundManager.COLLISION_TRIGGER_SFX);

        StackPane whiteFlash = new StackPane();
        whiteFlash.setStyle("-fx-background-color: white;");
        whiteFlash.setOpacity(0);
        whiteFlash.setMouseTransparent(true);
        whiteFlash.prefWidthProperty().bind(rootContainer.widthProperty());
        whiteFlash.prefHeightProperty().bind(rootContainer.heightProperty());
        rootContainer.getChildren().add(whiteFlash);

        Timeline flashIn = new Timeline(
            new KeyFrame(Duration.seconds(COLLISION_FLASH_DURATION), new KeyValue(whiteFlash.opacityProperty(), 1.0))
        );
        Timeline flashOut = new Timeline(
            new KeyFrame(Duration.seconds(COLLISION_FLASH_DURATION), new KeyValue(whiteFlash.opacityProperty(), 0.0))
        );

        flashIn.setOnFinished(e -> flashOut.play());

        flashOut.setOnFinished(e -> {
            rootContainer.getChildren().remove(whiteFlash);

            FadeTransition mapFadeOut = new FadeTransition(Duration.seconds(FADE_OUT_DURATION), mapView);
            mapFadeOut.setFromValue(1.0);
            mapFadeOut.setToValue(0.0);

            battleView.setOpacity(0.0);
            if (!rootContainer.getChildren().contains(battleView)) {
                rootContainer.getChildren().add(battleView);
            }

            FadeTransition battleFadeIn = new FadeTransition(Duration.seconds(FADE_IN_DURATION), battleView);
            battleFadeIn.setFromValue(0.0);
            battleFadeIn.setToValue(1.0);

            mapFadeOut.setOnFinished(e2 -> {
                mapView.setVisible(false);
                battleFadeIn.play();
            });

            battleFadeIn.setOnFinished(e2 -> {
                logger.info("Battle transition complete");
                if (onTransitionComplete != null) onTransitionComplete.run();
            });

            mapFadeOut.play();
        });

        flashIn.play();
    }

    public void transitionFromBattle(Runnable onTransitionComplete) {
        if (mapView == null || battleView == null) {
            if (onTransitionComplete != null) onTransitionComplete.run();
            return;
        }

        FadeTransition battleFadeOut = new FadeTransition(Duration.seconds(FADE_OUT_DURATION), battleView);
        battleFadeOut.setFromValue(1.0);
        battleFadeOut.setToValue(0.0);

        mapView.setVisible(true);
        mapView.setOpacity(0.0);
        FadeTransition mapFadeIn = new FadeTransition(Duration.seconds(FADE_IN_DURATION), mapView);
        mapFadeIn.setFromValue(0.0);
        mapFadeIn.setToValue(1.0);

        battleFadeOut.setOnFinished(e -> {
            rootContainer.getChildren().remove(battleView);
            mapFadeIn.play();
        });

        mapFadeIn.setOnFinished(e -> {
            logger.info("Return to map transition complete");
            if (onTransitionComplete != null) onTransitionComplete.run();
        });

        battleFadeOut.play();
    }
}