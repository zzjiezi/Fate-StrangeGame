package com.game.rpg.core.battle;

import com.game.rpg.model.entities.Enemy;

public class BossBattleEndCondition {
    private static final double BOSS_EXIT_HP_RATIO = 0.60;

    public static boolean checkAndTriggerBossExit(Enemy boss) {
        if (boss == null || !boss.isAlive()) {
            return false;
        }
        return boss.getHp() < (int) Math.round(boss.getMaxHp() * BOSS_EXIT_HP_RATIO);
    }
}