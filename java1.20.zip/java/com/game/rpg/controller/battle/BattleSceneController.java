package com.game.rpg.controller.battle;

import com.game.rpg.model.entities.Archer;
import com.game.rpg.model.entities.ArcherAlter;
import com.game.rpg.model.entities.AttackResult;
import com.game.rpg.model.entities.Bat;
import com.game.rpg.model.entities.Caster;
import com.game.rpg.model.entities.CasterAlter;
import com.game.rpg.model.entities.Character;
import com.game.rpg.model.entities.Cyclone;
import com.game.rpg.model.entities.Enemy;
import com.game.rpg.model.entities.Ghost;
import com.game.rpg.model.entities.Mimic;
import com.game.rpg.model.entities.Mummy;
import com.game.rpg.model.entities.Saber;
import com.game.rpg.model.entities.RoseMonster;
import com.game.rpg.model.entities.RoseWitch;
import com.game.rpg.model.entities.SaberAlter;
import com.game.rpg.model.enums.BattlePhase;
import com.game.rpg.model.enums.CommandSpellEffect;
import com.game.rpg.model.state.BattleState;
import com.game.rpg.model.state.GameStateManager;
import com.game.rpg.util.map.SpriteManager;
import com.game.rpg.util.resource.SoundManager;
import com.game.rpg.view.component.AchievementPopup;
import com.game.rpg.view.scene.BattleView;
import javafx.animation.FadeTransition;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BattleSceneController {
    private static final Logger logger = LoggerFactory.getLogger(BattleSceneController.class);

    private static int totalKillCount = 0;

    private final GameStateManager stateManager;
    private final SoundManager soundManager;
    private final BattleView battleView;
    private final Random random = new Random();

    private List<Character> characters;
    private Enemy enemy;
    private int selectedCharIndex = -1;
    private boolean isBossBattle = false;
    private Runnable onBattleEnd;
    private Runnable onVictory;
    private Runnable onDefeat;
    private Stage primaryStage;
    private java.util.function.Predicate<Enemy> customEndCondition;
    private Runnable onCustomBattleEnd;
    private List<Integer> lockedCharacterIndices = new ArrayList<>();

    public BattleSceneController(GameStateManager stateManager, SoundManager soundManager) {
        this.stateManager = stateManager;
        this.soundManager = soundManager;
        this.battleView = new BattleView();
        setupHandlers();
    }

    private void setupHandlers() {
        battleView.setOnCharacterSelected(this::handleCharacterSelected);
        battleView.setOnAttack(s -> handleAttack());
        battleView.setOnNoblePhantasm(s -> handleNoblePhantasm());
        battleView.setOnCommandSpell(this::handleCommandSpell);
        battleView.setOnFlee(this::handleFlee);
        battleView.setOnContinueClicked(this::handleContinue);
    }

    public BattleView getBattleView() {
        return battleView;
    }

    public void startBattle(List<Character> characters, Enemy enemy, boolean isBossBattle, Stage primaryStage) {
        this.characters = new ArrayList<>(characters);
        this.enemy = enemy;
        this.isBossBattle = isBossBattle;
        this.primaryStage = primaryStage;
        this.selectedCharIndex = -1;

        battleView.setBossBattle(isBossBattle);
        battleView.setupCharacters(characters);

        for (int lockedIdx : lockedCharacterIndices) {
            battleView.setCharacterLocked(lockedIdx);
        }

        battleView.updateEnemyInfo(enemy);
        String enemySpritePath = enemy.getSpritePath();
        if (enemySpritePath != null) {
            try {
                Image raw = new Image(getClass().getResourceAsStream(enemySpritePath));
                battleView.setEnemyImage(SpriteManager.cropTransparent(raw, enemySpritePath));
            } catch (Exception e) {
                logger.warn("Failed to load enemy sprite: {}", enemySpritePath);
            }
        }

        battleView.setActionButtonsEnabled(false);
        battleView.hideBattleText();
        battleView.hideCommandSpellSelection();

        soundManager.playBgm(SoundManager.BATTLE_BGM);

        if (isFirstStrikeEnemy()) {
            executeEnemyTurn();
        } else {
            enablePlayerTurn();
        }
    }

    private boolean isFirstStrikeEnemy() {
        if (enemy instanceof Mimic) {
            return ((Mimic) enemy).isFirstStrike();
        }
        return false;
    }

    private void handleCharacterSelected(int index) {
        if (lockedCharacterIndices.contains(index)) {
            return;
        }
        Character ch = characters.get(index);
        if (!ch.isAlive()) {
            boolean hasRevive = !ch.isCommandSpellUsed(CommandSpellEffect.REVIVE_SERVANT) && ch.getCommandSpellCount() > 0;
            battleView.setCharacterDead(index, hasRevive);
            return;
        }
        selectedCharIndex = index;
        battleView.updateSelectedCharInfo(ch);
        battleView.setActionButtonsEnabled(true);
    }

    private void handleAttack() {
        if (selectedCharIndex < 0) return;
        Character ch = characters.get(selectedCharIndex);
        if (!ch.isAlive()) return;


        soundManager.playSfx(SoundManager.CHARACTER_ATTACK_SFX);

        AttackResult result;
        if (ch instanceof Saber) {
            result = ((Saber) ch).normalAttack(enemy, null);
        } else if (ch instanceof Archer) {
            result = ((Archer) ch).normalAttack(enemy, null);
        } else if (ch instanceof Caster) {
            result = ((Caster) ch).normalAttack(enemy, null);
        } else {
            result = AttackResult.hit("攻击", ch.getAttackPower());
            enemy.takeDamage(ch.getAttackPower());
        }

        battleView.updateEnemyInfo(enemy);
        battleView.shakeEnemy();

        List<String> lines = new ArrayList<>();
        lines.add("「" + result.getSkillName() + "」");
        if (result.isHit()) {
            lines.add("命中！造成 " + result.getDamage() + " 点伤害");
        } else {
            lines.add("未命中...");
        }

        if (enemy instanceof RoseWitch) {
            double prevReduction = ch.getHitRateReduction();
            ((RoseWitch) enemy).checkThornPassive(ch, null);
            if (ch.getHitRateReduction() > prevReduction) {
                lines.add("荆棘缠住了" + ch.getName() + "，下回合命中率降低15%！");
            }
        }

        if (!enemy.isAlive()) {
            if (AchievementPopup.isAshGathererUnlocked()) {
                lines.add("残烬，归于来处。");
            } else {
                lines.add("收集到十枚流尘·残烬");
            }
            battleView.showBattleText(lines);
            soundManager.stopBgm();
            handleVictory();
            return;
        }

        if (checkCustomEndCondition()) {
            lines.add("敌人的身影渐渐远去……");
            battleView.showBattleText(lines);
            soundManager.stopBgm();
            handleCustomBattleEnd();
            return;
        }

        battleView.showBattleText(lines);
        battleView.setActionButtonsEnabled(false);
    }

    private void handleNoblePhantasm() {
        if (selectedCharIndex < 0) return;
        Character ch = characters.get(selectedCharIndex);
        if (!ch.isAlive()) return;

        boolean canCast = false;
        if (ch instanceof Saber) canCast = ((Saber) ch).canCastNoblePhantasm();
        else if (ch instanceof Archer) canCast = ((Archer) ch).canCastNoblePhantasm();
        else if (ch instanceof Caster) canCast = ((Caster) ch).canCastNoblePhantasm();

        if (!canCast) {
            battleView.showBattleText(List.of("蓝量不足，无法释放宝具！"));
            return;
        }

        battleView.setActionButtonsEnabled(false);
        soundManager.pauseBgm();

        playNoblePhantasmAnimation(ch, () -> {
            soundManager.resumeBgm();

            executeNoblePhantasmDamage(ch);
        });
    }

    private void playNoblePhantasmAnimation(Character ch, Runnable onEnd) {
        String imagePath = "/images/characters/" + ch.getId() + "/noble_phantasm.png";
        String audioPath = "/sounds/noble_phantasm_" + ch.getId() + ".mp3";

        try {
            Image npImage = new Image(getClass().getResource(imagePath).toExternalForm());
            battleView.showNoblePhantasmOverlay(npImage);
        } catch (Exception e) {
            logger.warn("Noble Phantasm image not found: {}", imagePath);
        }

        soundManager.playNoblePhantasmAudio(audioPath, () -> {
            battleView.hideNoblePhantasmOverlay();
            if (onEnd != null) onEnd.run();
        });
    }

    private void executeNoblePhantasmDamage(Character ch) {
        AttackResult result;
        if (ch instanceof Saber) {
            result = ((Saber) ch).noblePhantasm(enemy, null);
        } else if (ch instanceof Archer) {
            result = ((Archer) ch).noblePhantasm(enemy, null);
        } else if (ch instanceof Caster) {
            Caster.MultiHitResult mhr = ((Caster) ch).noblePhantasm(enemy, null);
            result = mhr.hasAnyHit() ? AttackResult.hit("梦境入侵", mhr.getTotalDamage()) : AttackResult.missed("梦境入侵", 0);
        } else {
            result = AttackResult.hit("宝具", ch.getAttackPower());
        }

        battleView.updateEnemyInfo(enemy);
        battleView.shakeEnemy();

        List<String> lines = new ArrayList<>();
        lines.add("「" + result.getSkillName() + "」");
        if (result.isHit()) {
            lines.add("命中！造成 " + result.getDamage() + " 点伤害");
        } else {
            lines.add("未命中...");
        }

        if (!enemy.isAlive()) {
            if (AchievementPopup.isAshGathererUnlocked()) {
                lines.add("残烬，归于来处。");
            } else {
                lines.add("收集到十枚流尘·残烬");
            }
            battleView.showBattleText(lines);
            soundManager.stopBgm();
            handleVictory();
            return;
        }

        if (checkCustomEndCondition()) {
            lines.add("敌人的身影渐渐远去……");
            battleView.showBattleText(lines);
            soundManager.stopBgm();
            handleCustomBattleEnd();
            return;
        }

        battleView.showBattleText(lines);
        battleView.setActionButtonsEnabled(false);
    }


    private void handleCommandSpell(CommandSpellEffect effect) {
        if (selectedCharIndex < 0) return;
        Character ch = characters.get(selectedCharIndex);

        if (!ch.canUseCommandSpell(effect)) {
            return;
        }

        ch.useCommandSpell(effect);

        switch (effect) {
            case REVIVE_SERVANT:
                for (int i = 0; i < characters.size(); i++) {
                    Character c = characters.get(i);
                    if (!c.isAlive()) {
                        c.heal(c.getMaxHp());
                        battleView.setCharacterRevived(i);
                        battleView.showBattleText(List.of("令咒「复活从者」！" + c.getName() + " 以满血复活！"));
                        break;
                    }
                }
                break;
            case DAMAGE_BOOST:
                ch.setDamageBoostActive(true);
                battleView.showBattleText(List.of("令咒「伤害提升50%」！下一次攻击伤害提升！"));
                break;
            case HEAL_HP:
                ch.restoreMP(50);
                battleView.showBattleText(List.of("令咒「回复能量」！回复 50 点MP！"));
                battleView.updateSelectedCharInfo(ch);
                break;
        }

        battleView.updateCommandSpellStates(ch);
        battleView.hideCommandSpellSelection();
    }

    private void handleFlee() {
        if (isBossBattle) return;
        soundManager.stopBgm();
        battleView.showBattleText(List.of("成功逃离战斗！"));
        if (onBattleEnd != null) onBattleEnd.run();
    }

    private boolean isPlayerTurnPending = false;

    private void handleContinue() {
        battleView.hideBattleText();

        if (!enemy.isAlive()) {
            return;
        }

        if (checkCustomEndCondition()) {
            soundManager.stopBgm();
            handleCustomBattleEnd();
            return;
        }

        boolean allDead = characters.stream().noneMatch(Character::isAlive);
        if (allDead) {
            handleGameOver();
            return;
        }

        if (isPlayerTurnPending) {
            isPlayerTurnPending = false;
            enablePlayerTurn();
        } else {
            executeEnemyTurn();
        }
    }

    private void executeEnemyTurn() {
        battleView.setActionButtonsEnabled(false);

        if (checkCustomEndCondition()) {
            soundManager.stopBgm();
            battleView.showBattleText(List.of("敌人的身影渐渐远去……"));
            return;
        }

        List<Character> aliveChars = new ArrayList<>();
        for (int i = 0; i < characters.size(); i++) {
            if (characters.get(i).isAlive() && !lockedCharacterIndices.contains(i)) {
                aliveChars.add(characters.get(i));
            }
        }
        if (aliveChars.isEmpty()) {
            for (int i = 0; i < characters.size(); i++) {
                if (characters.get(i).isAlive()) {
                    aliveChars.add(characters.get(i));
                }
            }
        }
        if (aliveChars.isEmpty()) {
            handleGameOver();
            return;
        }

        Character target = aliveChars.get(random.nextInt(aliveChars.size()));

        battleView.flashRed();
        soundManager.playSfx(SoundManager.ENEMY_ATTACK_SFX);

        AttackResult result;
        if (enemy instanceof Ghost) {
            result = ((Ghost) enemy).normalAttack(target, null);
        } else if (enemy instanceof Mimic) {
            result = ((Mimic) enemy).normalAttack(target, null);
            ((Mimic) enemy).consumeFirstStrike();
        } else if (enemy instanceof Bat) {
            result = ((Bat) enemy).normalAttack(target, null);
        } else if (enemy instanceof Mummy) {
            result = ((Mummy) enemy).normalAttack(target, null);
        } else if (enemy instanceof Cyclone) {
            result = ((Cyclone) enemy).normalAttack(target, null);
        } else if (enemy instanceof SaberAlter) {
            result = ((SaberAlter) enemy).normalAttack(target, null);
        } else if (enemy instanceof CasterAlter) {
            result = ((CasterAlter) enemy).normalAttack(target, null);
        } else if (enemy instanceof ArcherAlter) {
            result = ((ArcherAlter) enemy).normalAttack(target, null);
        } else if (enemy instanceof RoseWitch) {
            result = ((RoseWitch) enemy).normalAttack(target, null);
        } else if (enemy instanceof RoseMonster) {
            result = ((RoseMonster) enemy).normalAttack(target, null);
        } else {
            result = AttackResult.hit("攻击", enemy.getAttackPower());
            target.takeDamage(enemy.getAttackPower());
        }

        battleView.updateEnemyInfo(enemy);
        updateCharacterDisplay();

        int targetIndex = characters.indexOf(target);
        battleView.shakeCharacter(targetIndex);

        String className = target.getClass().getSimpleName();

        List<String> lines = new ArrayList<>();
        lines.add("「" + result.getSkillName() + "」");
        if (result.isHit()) {
            lines.add("命中！对 " + className + " 造成 " + result.getDamage() + " 点伤害");
        } else {
            lines.add("未命中...");
        }

        if (!target.isAlive()) {
            lines.add(className + " 阵亡");
            boolean hasRevive = !target.isCommandSpellUsed(CommandSpellEffect.REVIVE_SERVANT) && target.getCommandSpellCount() > 0;
            battleView.setCharacterDead(targetIndex, hasRevive);
        }

        boolean allDead = characters.stream().noneMatch(Character::isAlive);
        if (allDead) {
            lines.add("全灭...");
            battleView.showBattleText(lines, true);
            soundManager.stopBgm();
            return;
        }

        isPlayerTurnPending = true;
        battleView.showBattleText(lines, true);
    }

    private void updateCharacterDisplay() {
        for (int i = 0; i < characters.size(); i++) {
            Character ch = characters.get(i);
            if (ch.isAlive()) {
                if (i == selectedCharIndex) {
                    battleView.updateSelectedCharInfo(ch);
                }
            }
        }
    }

    private void enablePlayerTurn() {
        for (Character ch : characters) {
            ch.onTurnEnd();
            ch.tickHitRateReduction();
            ch.tickBleed();
            ch.tickDodgeRateReduction();
        }
        if (enemy != null) {
            enemy.onTurnStart();
        }

        battleView.setActionButtonsEnabled(selectedCharIndex >= 0 && characters.get(selectedCharIndex).isAlive());

        if (selectedCharIndex >= 0 && !characters.get(selectedCharIndex).isAlive()) {
            selectedCharIndex = -1;
            battleView.setActionButtonsEnabled(false);
        }
    }

    private void handleVictory() {
        totalKillCount++;
        soundManager.stopBgm();
        battleView.showBattleResult("Victory", () -> {
            if (totalKillCount >= 10 && !AchievementPopup.isAshGathererUnlocked()) {
                AchievementPopup.show(primaryStage);
            }
            if (onVictory != null) onVictory.run();
            else if (onBattleEnd != null) onBattleEnd.run();
        });
    }

    private void handleGameOver() {
        soundManager.stopBgm();
        battleView.showBattleResult("Game Over", () -> {
            if (onDefeat != null) onDefeat.run();
            else if (onBattleEnd != null) onBattleEnd.run();
        });
    }

    public void setOnBattleEnd(Runnable onBattleEnd) {
        this.onBattleEnd = onBattleEnd;
    }

    public void setOnVictory(Runnable onVictory) {
        this.onVictory = onVictory;
    }

    public void setOnDefeat(Runnable onDefeat) {
        this.onDefeat = onDefeat;
    }

    public static int getTotalKillCount() {
        return totalKillCount;
    }

    public static void resetKillCount() {
        totalKillCount = 0;
    }

    public void setCustomEndCondition(java.util.function.Predicate<Enemy> condition, Runnable onEnd) {
        this.customEndCondition = condition;
        this.onCustomBattleEnd = onEnd;
    }

    public void setLockedCharacters(List<Integer> indices) {
        this.lockedCharacterIndices = new ArrayList<>(indices);
    }

    private boolean checkCustomEndCondition() {
        return customEndCondition != null && customEndCondition.test(enemy);
    }

    private void handleCustomBattleEnd() {
        logger.info("Custom battle end condition triggered");
        battleView.showBattleResult("黑影逃走了......", () -> {
            if (onCustomBattleEnd != null) {
                onCustomBattleEnd.run();
            } else if (onBattleEnd != null) {
                onBattleEnd.run();
            }
        });
    }
}