package com.game.rpg.controller.room;

import com.game.rpg.controller.battle.BattleSceneController;
import com.game.rpg.model.entities.Archer;
import com.game.rpg.model.entities.Caster;
import com.game.rpg.model.entities.Character;
import com.game.rpg.model.entities.Enemy;
import com.game.rpg.model.entities.Saber;
import com.game.rpg.model.entities.SaberAlter;
import com.game.rpg.model.state.GameStateManager;
import com.game.rpg.util.resource.ResourceLoader;
import com.game.rpg.util.resource.SoundManager;
import com.game.rpg.view.scene.BattleView;
import com.game.rpg.view.scene.GameMapView;
import com.game.rpg.view.scene.MainMenuView;
import javafx.animation.PauseTransition;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class Room3Controller {
    private static final Logger logger = LoggerFactory.getLogger(Room3Controller.class);

    private final GameMapView gameMap;
    private final ResourceLoader resourceLoader;
    private final GameStateManager stateManager;
    private final SoundManager soundManager;
    private final StackPane root;
    private final RoomManager roomManager;

    private int dialogChoice = -1;
    private int wishChoice = -1;

    public Room3Controller(GameMapView gameMap, ResourceLoader resourceLoader,
                           GameStateManager stateManager, SoundManager soundManager,
                           StackPane root, RoomManager roomManager) {
        this.gameMap = gameMap;
        this.resourceLoader = resourceLoader;
        this.stateManager = stateManager;
        this.soundManager = soundManager;
        this.root = root;
        this.roomManager = roomManager;
    }

    public void setup() {
        boolean introPlayed = gameMap.getFlag("room3IntroPlayed");
        boolean dialogueDone = gameMap.getFlag("room3DialogueDone");

        gameMap.loadMap(
                "/images/backgrounds/roomAttacked.png",
                "/maps/roomAttacked.tmj",
                428, 387
        );

        gameMap.addNPC("saberAlter", 429, 262, "/images/enemies/Saber Alter1.png", 80, 80);

        gameMap.startGameLoop();
        gameMap.lockInput();

        if (introPlayed) {
            gameMap.addNPC("saber", 442, 348, "/images/characters/Saber/Saber 1正面 .png", 80, 80);

            if (gameMap.getFlag("saberAlterRemoved")) {
                gameMap.removeNPC("saberAlter");
            }

            if (dialogueDone) {
                gameMap.unlockInput();
            } else {
                showSaberDialogue();
            }
            return;
        }

        PauseTransition wait2s = new PauseTransition(Duration.seconds(2));
        wait2s.setOnFinished(e -> {
            gameMap.showRedFlash(() -> {
                PauseTransition wait1s = new PauseTransition(Duration.seconds(1));
                wait1s.setOnFinished(ev -> {
                    gameMap.addNPC("saber", 442, 348, "/images/characters/Saber/Saber 1背面 .png", 80, 80);

                    PauseTransition wait1_5s = new PauseTransition(Duration.millis(1500));
                    wait1_5s.setOnFinished(ev2 -> {
                        gameMap.updateNPCSprite("saber", "/images/characters/Saber/Saber 1正面 .png");
                        gameMap.setFlag("room3IntroPlayed", true);
                        showSaberDialogue();
                    });
                    wait1_5s.play();
                });
                wait1s.play();
            });
        });
        wait2s.play();
    }

    private void showSaberDialogue() {
        gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "???: 试问，你就是我的御主吗？",
                () -> {
                    gameMap.showDialogWithChoice("/images/ui/dialogbackground.png",
                            "（该说些什么回答她……）",
                            List.of("是啊，你就是我的从者！", "从者… 那是什么？"),
                            choice -> {
                                dialogChoice = choice;
                                if (choice == 0) {
                                    gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                                            "金发少女：嗯，那么请下指令击退敌人吧，御主",
                                            () -> onPreBattleComplete());
                                } else {
                                    gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                                            "金发少女：我是会保护你的存在，情况紧急，请允许我击退敌人后再解释。",
                                            () -> onPreBattleComplete());
                                }
                            });
                });
    }

    private void onPreBattleComplete() {
        logger.info("Pre-battle dialog complete, starting boss battle");
        gameMap.showContractScene(() -> {
            gameMap.setFlag("saberUnlocked", true);

            startBossBattle();
        });
    }

    private void startBossBattle() {
        gameMap.stopGameLoop();

        List<Character> party = new ArrayList<>();
        party.add(new Saber());
        party.add(new Archer());
        party.add(new Caster());

        Enemy boss = new SaberAlter();

        BattleSceneController battleCtrl = new BattleSceneController(stateManager, soundManager);
        battleCtrl.setLockedCharacters(List.of(1, 2));
        battleCtrl.setCustomEndCondition(
                e -> e.getHp() < (int) Math.round(e.getMaxHp() * 0.60),
                () -> {
                    logger.info("Boss HP below 60%, boss flees");
                    BattleView battleView = battleCtrl.getBattleView();
                    root.getChildren().remove(battleView);
                    gameMap.setFlag("saberAlterRemoved", true);
                    gameMap.removeNPC("saberAlter");
                    gameMap.toFront();
                    gameMap.startGameLoop();
                    gameMap.lockInput();
                    showPostBattleDialogue();
                }
        );

        battleCtrl.setOnVictory(() -> {
            BattleView battleView = battleCtrl.getBattleView();
            root.getChildren().remove(battleView);
            gameMap.setFlag("saberAlterRemoved", true);
            gameMap.removeNPC("saberAlter");
            gameMap.toFront();
            gameMap.startGameLoop();
            gameMap.lockInput();
            showPostBattleDialogue();
        });

        battleCtrl.setOnDefeat(() -> {
            BattleView battleView = battleCtrl.getBattleView();
            root.getChildren().remove(battleView);
            MainMenuView mainMenu = new MainMenuView(resourceLoader, new com.game.rpg.controller.menu.MenuController(stateManager));
            mainMenu.setOnLoadGame(() -> {
                com.game.rpg.util.save.SaveManager.SaveData data = com.game.rpg.util.save.SaveManager.loadGame();
                if (data != null) {
                    root.getChildren().remove(mainMenu);

                    gameMap.toFront();
                    gameMap.setPlayerPosition(data.playerX, data.playerY);
                    gameMap.setSkinIndex(data.currentSkinIndex);
                    if (data.gameFlags != null) {
                        for (java.util.Map.Entry<String, Boolean> entry : data.gameFlags.entrySet()) {
                            gameMap.setFlag(entry.getKey(), entry.getValue());
                        }
                    }
                    int room = 1;
                    try { room = Integer.parseInt(data.mapId); } catch (Exception ignored) {}
                    roomManager.startRoom(room);
                    gameMap.unlockInput();
                }
            });
            root.getChildren().add(mainMenu);
        });

        BattleView battleView = battleCtrl.getBattleView();
        root.getChildren().add(battleView);
        battleView.toFront();

        battleCtrl.startBattle(party, boss, true, (Stage) root.getScene().getWindow());
    }

    private void showPostBattleDialogue() {
        gameMap.showSkinUnlockHint("Saber");

        gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "金发少女: …逃走了吗?",
                () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                        "（她望向敌人离开的方向，才在手中放光的剑却慢慢消失了）",
                        () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                                "金发少女: 现在应该安全了，御主。你没受伤吧？",
                                () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                                        "你: 谢谢你，我没事。你到底是…？",
                                        () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                                                "金发少女: 啊，忘了自我介绍，你可以称呼我身为从者时的职介[Saber]，为了得到圣杯，我已经参与了多次圣杯战争。而在召唤现界的时刻，圣杯给予了我参与这场圣杯战争所必须的知识。但这些知识中却充满了难以理解的概念。这里似乎和我熟悉的世界有许多不同。所以在往常需要隐藏的包含的弱点的真名也不需要隐藏了。",
                                                () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                                                        "你: 刚才的敌人和你长得一模一样…",
                                                        () -> showWishChoice()))))));
    }

    private void showWishChoice() {
        gameMap.showDialogWithChoice("/images/ui/dialogbackground.png",
                "Saber: 刚才的那个身影，其实也是我，或者说是我的另一种可能。通常情况下我们不会同时出现，但是如果圣杯又被污染了的话…虽然维持我存续的力量并非从你身体流出，但…我确实能感受到和你之间存在着连结。所以，御主，无需担心，无论对手是谁，我都会保护你的。说起来，御主是为了什么而参加圣杯战争的呢？",
                List.of(
                        "是为了成为正义的伙伴！",
                        "为了弥补遗憾",
                        "为了世界和平！",
                        "为了有更多的财富",
                        "啊？我也要参加吗？"
                ),
                choice -> {
                    wishChoice = choice;
                    String response = switch (choice) {
                        case 0 -> "Saber: （稍微愣神）是吗，也有人说出过一样的话呢。你也一定是一个温柔而坚强的人吧。";
                        case 1 -> "Saber: …过去的事也只有圣杯能有办法改变了，但是真正能够弥补的或许只有现在吧…";
                        case 2 -> "Saber: 是个很宏大的愿望呢。";
                        case 3 -> "Saber: 嗯，很切实的愿望。";
                        case 4 -> "Saber: 对。你手上的令咒已经昭示了你身为御主的资格，就算放任不管也会被其他敌人盯上的。";
                        default -> "Saber: …";
                    };
                    gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                            response,
                            () -> showGrailConclusion());
                });
    }

    private void showGrailConclusion() {
        gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Saber: 不过根据我的推断，现在的圣杯应该无法实现愿望了…那个'我'会出现，就说明圣杯已经遭受了严重的污染。当务之急，应该是找到污染的圣杯并想办法将其破坏。否则，可能又会酿成足以毁灭一座城市的灾祸。",
                () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                        "（说着，Saber又望向窗外，远处的天空不断发出不详的红光）",
                        () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                                "Saber: …看来圣杯应该在那个方向。御主，出发吧。",
                                () -> onRoom3Complete())));
    }

    private void onRoom3Complete() {
        logger.info("Room 3 completed, dialogChoice={}, wishChoice={}", dialogChoice, wishChoice);
        gameMap.setFlag("room3DialogueDone", true);
        gameMap.stopGameLoop();
        gameMap.fadeToBlack(() -> {
            if (onComplete != null) onComplete.run();
        });
    }

    private Runnable onComplete;

    public void setOnComplete(Runnable onComplete) {
        this.onComplete = onComplete;
    }

    public int getDialogChoice() {
        return dialogChoice;
    }

    public int getWishChoice() {
        return wishChoice;
    }
}
