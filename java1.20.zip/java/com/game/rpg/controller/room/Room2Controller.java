package com.game.rpg.controller.room;

import com.game.rpg.util.resource.ResourceLoader;
import com.game.rpg.view.scene.GameMapView;
import javafx.animation.PauseTransition;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Room2Controller {
    private static final Logger logger = LoggerFactory.getLogger(Room2Controller.class);

    private final GameMapView gameMap;
    private final ResourceLoader resourceLoader;

    public Room2Controller(GameMapView gameMap, ResourceLoader resourceLoader) {
        this.gameMap = gameMap;
        this.resourceLoader = resourceLoader;
    }

    public void setup() {
        gameMap.loadMap(
                "/images/backgrounds/roomSummon.png",
                null,
                428, 387
        );

        gameMap.lockInput();
        gameMap.startGameLoop();

        PauseTransition wait3s = new PauseTransition(Duration.seconds(3));
        wait3s.setOnFinished(e -> {
            gameMap.showBlackScreenWithText("什么也没出现吗…?", () -> {
                gameMap.showScreenShake(() -> {
                    gameMap.showBlackScreenTimed(2000, () -> {
                        onRoom2Complete();
                    });
                });
            });
        });
        wait3s.play();
    }

    private void onRoom2Complete() {
        logger.info("Room 2 completed, transitioning to Room 3");
        if (onComplete != null) onComplete.run();
    }

    private Runnable onComplete;

    public void setOnComplete(Runnable onComplete) {
        this.onComplete = onComplete;
    }
}
