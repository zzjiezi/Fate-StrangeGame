package com.game.rpg.controller.room;

import com.game.rpg.util.resource.ResourceLoader;
import com.game.rpg.view.scene.GameMapView;
import javafx.animation.PauseTransition;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Room6Controller {
    private static final Logger logger = LoggerFactory.getLogger(Room6Controller.class);

    private final GameMapView gameMap;
    private final ResourceLoader resourceLoader;

    public Room6Controller(GameMapView gameMap, ResourceLoader resourceLoader) {
        this.gameMap = gameMap;
        this.resourceLoader = resourceLoader;
    }

    public void setup() {
        gameMap.loadMap(
                "/images/backgrounds/classroomBlack.png",
                null,
                573, 417
        );

        gameMap.addNPC("saber", 607, 369, "/images/characters/Saber/Saber 1正面 .png", 90, 90);

        gameMap.startGameLoop();
        gameMap.lockInput();

        phaseOne();
    }

    private void phaseOne() {
        gameMap.addNPC("madoka", 539, 265, "/images/characters/archer/archer1.png", 80, 80);

        PauseTransition wait0_5s = new PauseTransition(Duration.millis(500));
        wait0_5s.setOnFinished(e -> phaseOneDialog());
        wait0_5s.play();
    }

    private void phaseOneDialog() {
        Runnable step6 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：我们应该被拉入了一个被污染的圣杯制造的幻境中，幻境中的所有人都可能会被侵蚀，我知道你现在很混乱，但是情况紧急，我们得离开这儿。",
                () -> {
                    gameMap.hideDialog();
                    phaseTwo();
                });

        Runnable step5 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "小圆：你是谁？……我在哪里？你怎么会知道我的名字？",
                step6);

        Runnable step4 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：小圆？",
                step5);

        Runnable step3 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：嗯（点头）（关切地看向小圆）你……没事吧？",
                step4);

        Runnable step2 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Saber：那些怪物暂时已经被我击退，御主，我们需要尽快转移至安全的地方。",
                step3);

        step2.run();
    }

    private void phaseTwo() {
        gameMap.showScreenShake(() -> {
            gameMap.loadMap(
                    "/images/enemies/WitchSavior.png",
                    null,
                    573, 417
            );
            gameMap.addNPC("saber", 607, 369, "/images/characters/Saber/Saber 1正面 .png", 90, 90);
            gameMap.addNPC("madoka", 539, 265, "/images/characters/archer/archer1.png", 80, 80);
            gameMap.startGameLoop();
            gameMap.lockInput();

            PauseTransition wait1s = new PauseTransition(Duration.seconds(1));
            wait1s.setOnFinished(e -> phaseTwoDialog());
            wait1s.play();
        });
    }

    private void phaseTwoDialog() {
        gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Saber: 御主小心，我们还在幻境中，这个敌人异常强大，应该是被污染的圣杯召唤出的又一个绝望的集合体。",
                () -> phaseThreeDialog());
    }

    private void phaseThreeDialog() {
        Runnable step3 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "小圆：不过，将所有的宇宙，过去和未来的所有魔女亲手消灭，仍是我存在于此的理由，济世魔女就交给我来消灭吧。而所有对此进行妨碍的规则，就算是对因果律本身的反逆，也会由我来破坏，来改变。",
                () -> {
                    gameMap.hideDialog();
                    if (onComplete != null) onComplete.run();
                });

        Runnable step2 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "小圆：绝望…魔女…，我……我想起来了，那个是本应由我消灭的'济世的魔女'，可由于圣杯的污染，导致在这幻境中的'我'和'济世的魔女'一样，只是圆环之理的一部分投影罢了。",
                step3);

        Runnable step1 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "（听到这里，小圆突然停下了脚步）",
                step2);

        step1.run();
    }

    private Runnable onComplete;

    public void setOnComplete(Runnable onComplete) {
        this.onComplete = onComplete;
    }
}