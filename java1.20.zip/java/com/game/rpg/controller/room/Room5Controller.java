package com.game.rpg.controller.room;

import com.game.rpg.controller.battle.BattleSceneController;
import com.game.rpg.model.entities.Archer;
import com.game.rpg.model.entities.Bat;
import com.game.rpg.model.entities.Caster;
import com.game.rpg.model.entities.Character;
import com.game.rpg.model.entities.Enemy;
import com.game.rpg.model.entities.Ghost;
import com.game.rpg.model.entities.Mimic;
import com.game.rpg.model.entities.Saber;
import com.game.rpg.model.state.GameStateManager;
import com.game.rpg.util.resource.ResourceLoader;
import com.game.rpg.util.resource.SoundManager;
import com.game.rpg.view.scene.BattleView;
import com.game.rpg.view.scene.GameMapView;
import javafx.animation.PauseTransition;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class Room5Controller {
    private static final Logger logger = LoggerFactory.getLogger(Room5Controller.class);

    private final GameMapView gameMap;
    private final ResourceLoader resourceLoader;
    private final GameStateManager stateManager;
    private final SoundManager soundManager;
    private final StackPane root;

    private int currentBattleIndex = 0;

    private static final String[] ENEMY_NAMES = {"幽灵鬼", "宝箱怪", "蝙蝠怪"};
    private static final String[] MONSTER_NPC_IDS = {"monster1", "monster2", "monster3"};

    public Room5Controller(GameMapView gameMap, ResourceLoader resourceLoader,
                           GameStateManager stateManager, SoundManager soundManager, StackPane root) {
        this.gameMap = gameMap;
        this.resourceLoader = resourceLoader;
        this.stateManager = stateManager;
        this.soundManager = soundManager;
        this.root = root;
    }

    public void setup() {
        gameMap.loadMap(
                "/images/backgrounds/classroomBlack.png",
                null,
                573, 417
        );

        gameMap.addNPC("saber", 607, 369, "/images/characters/Saber/Saber 1正面 .png", 90, 90);

        gameMap.startGameLoop();
        gameMap.lockInput();

        PauseTransition wait1_5s = new PauseTransition(Duration.millis(1500));
        wait1_5s.setOnFinished(e -> phaseTwo());
        wait1_5s.play();
    }

    private void phaseTwo() {
        gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：难道？这是那个女孩的记忆……？",
                () -> {
                    gameMap.hideDialog();
                    phaseThree();
                });
    }

    private void phaseThree() {
        gameMap.addNPC("monster1", 530, 188, "/images/enemies/monster1.png", 80, 80);
        gameMap.addNPC("monster2", 330, 270, "/images/enemies/monster2.png", 80, 80);
        gameMap.addNPC("monster3", 805, 337, "/images/enemies/monster3.png", 80, 80);

        gameMap.showScreenShake(() -> {
            PauseTransition wait1_5s = new PauseTransition(Duration.millis(1500));
            wait1_5s.setOnFinished(e -> phaseFour());
            wait1_5s.play();
        });
    }

    private void phaseFour() {
        gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Saber: （把剑横在我面前）御主，请待在我身后。",
                () -> {
                    gameMap.hideDialog();
                    currentBattleIndex = 0;
                    startNextBattle();
                });
    }

    private Enemy createEnemy(int index) {
        return switch (index) {
            case 0 -> new Ghost();
            case 1 -> new Mimic();
            case 2 -> new Bat();
            default -> new Ghost();
        };
    }

    private void startNextBattle() {
        if (currentBattleIndex >= 3) {
            onAllBattlesComplete();
            return;
        }

        gameMap.stopGameLoop();

        List<Character> party = new ArrayList<>();
        party.add(new Saber());
        party.add(new Archer());
        party.add(new Caster());

        Enemy enemy = createEnemy(currentBattleIndex);

        BattleSceneController battleCtrl = new BattleSceneController(stateManager, soundManager);
        battleCtrl.setLockedCharacters(List.of(1, 2));

        final int battleIdx = currentBattleIndex;

        battleCtrl.setOnVictory(() -> {
            BattleView battleView = battleCtrl.getBattleView();
            root.getChildren().remove(battleView);
            gameMap.removeNPC(MONSTER_NPC_IDS[battleIdx]);
            gameMap.toFront();
            gameMap.startGameLoop();
            gameMap.lockInput();

            currentBattleIndex++;
            if (currentBattleIndex < 3) {
                gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                        ENEMY_NAMES[battleIdx] + "被击退了！",
                        () -> {
                            gameMap.hideDialog();
                            startNextBattle();
                        });
            } else {
                onAllBattlesComplete();
            }
        });

        battleCtrl.setOnDefeat(() -> {
            BattleView battleView = battleCtrl.getBattleView();
            root.getChildren().remove(battleView);
            gameMap.toFront();
            gameMap.startGameLoop();
            gameMap.unlockInput();
            if (onComplete != null) onComplete.run();
        });

        BattleView battleView = battleCtrl.getBattleView();
        root.getChildren().add(battleView);
        battleView.toFront();

        battleCtrl.startBattle(party, enemy, true, (Stage) root.getScene().getWindow());
    }

    private void onAllBattlesComplete() {
        gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Saber: 所有敌人已被击退。御主，我们继续前进吧。",
                () -> {
                    gameMap.hideDialog();
                    if (onComplete != null) onComplete.run();
                });
    }

    private Runnable onComplete;

    public void setOnComplete(Runnable onComplete) {
        this.onComplete = onComplete;
    }
}
