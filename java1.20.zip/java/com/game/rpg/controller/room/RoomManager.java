package com.game.rpg.controller.room;

import com.game.rpg.model.state.GameStateManager;
import com.game.rpg.util.resource.ResourceLoader;
import com.game.rpg.util.resource.SoundManager;
import com.game.rpg.view.scene.GameMapView;
import javafx.scene.layout.StackPane;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RoomManager {
    private static final Logger logger = LoggerFactory.getLogger(RoomManager.class);

    private final GameMapView gameMap;
    private final ResourceLoader resourceLoader;
    private final GameStateManager stateManager;
    private final SoundManager soundManager;
    private final StackPane root;
    private int currentRoom = 0;

    public RoomManager(GameMapView gameMap, ResourceLoader resourceLoader,
                       GameStateManager stateManager, SoundManager soundManager, StackPane root) {
        this.gameMap = gameMap;
        this.resourceLoader = resourceLoader;
        this.stateManager = stateManager;
        this.soundManager = soundManager;
        this.root = root;
    }

    public void startRoom(int roomNumber) {
        currentRoom = roomNumber;
        gameMap.stopGameLoop();
        gameMap.ensureKeyBindings();
        gameMap.setCurrentMapId(String.valueOf(roomNumber));

        switch (roomNumber) {
            case 1 -> startRoom1();
            case 2 -> startRoom2();
            case 3 -> startRoom3();
            case 4 -> startRoom4();
            case 5 -> startRoom5();
            case 6 -> startRoom6();
            case 7 -> startRoom7();
            default -> logger.warn("Room {} not implemented yet", roomNumber);
        }
    }

    private void startRoom1() {
        Room1Controller controller = new Room1Controller(gameMap, resourceLoader);
        controller.setOnComplete(() -> startRoom(2));
        controller.setup();
    }

    private void startRoom2() {
        Room2Controller controller = new Room2Controller(gameMap, resourceLoader);
        controller.setOnComplete(() -> startRoom(3));
        controller.setup();
    }

    private void startRoom3() {
        Room3Controller controller = new Room3Controller(gameMap, resourceLoader, stateManager, soundManager, root, this);
        controller.setOnComplete(() -> startRoom(4));
        controller.setup();
    }

    private void startRoom4() {
        Room4Controller controller = new Room4Controller(gameMap, resourceLoader);
        controller.setOnComplete(() -> startRoom(5));
        controller.setup();
    }

    private void startRoom5() {
        Room5Controller controller = new Room5Controller(gameMap, resourceLoader, stateManager, soundManager, root);
        controller.setOnComplete(() -> startRoom(6));
        controller.setup();
    }

    private void startRoom6() {
        Room6Controller controller = new Room6Controller(gameMap, resourceLoader);
        controller.setOnComplete(() -> startRoom(7));
        controller.setup();
    }

    private Runnable onGameComplete;

    public void setOnGameComplete(Runnable onGameComplete) {
        this.onGameComplete = onGameComplete;
    }

    private void startRoom7() {
        Room7Controller controller = new Room7Controller(gameMap, resourceLoader, stateManager, soundManager, root);
        controller.setOnComplete(() -> {
            logger.info("All current rooms completed");
            if (onGameComplete != null) onGameComplete.run();
        });
        controller.setup();
    }

    public int getCurrentRoom() {
        return currentRoom;
    }
}
