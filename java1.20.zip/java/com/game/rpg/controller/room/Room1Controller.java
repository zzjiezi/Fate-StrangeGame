package com.game.rpg.controller.room;

import com.game.rpg.util.resource.ResourceLoader;
import com.game.rpg.view.scene.GameMapView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class Room1Controller {
    private static final Logger logger = LoggerFactory.getLogger(Room1Controller.class);

    private final GameMapView gameMap;
    private final ResourceLoader resourceLoader;

    private boolean hasReadBook = false;
    private boolean hasPickedGem = false;
    private boolean hasSeenInitialDialog = false;
    private boolean hasTriggeredSummon = false;

    public Room1Controller(GameMapView gameMap, ResourceLoader resourceLoader) {
        this.gameMap = gameMap;
        this.resourceLoader = resourceLoader;
    }

    public void setup() {
        hasReadBook = gameMap.getFlag("bookRead");
        hasPickedGem = gameMap.getFlag("gemPicked");
        hasSeenInitialDialog = gameMap.getFlag("initialDialogSeen");
        hasTriggeredSummon = gameMap.getFlag("summonTriggered");

        gameMap.loadMap(
                "/images/backgrounds/room.png",
                "/maps/room.tmj",
                428, 387
        );

        gameMap.addInteractionZone("book", 801, 330, 40, 40,
                () -> handleBookInteraction(), true, 821, 373);

        gameMap.addInteractionZone("gem", 656, 489, 40, 40,
                () -> handleGemInteraction(), true);

        gameMap.addInteractionZone("summon", 400, 360, 80, 80,
                () -> handleSummonInteraction(), false);

        if (hasReadBook) gameMap.completeInteractionZone("book");
        if (hasPickedGem) gameMap.completeInteractionZone("gem");

        gameMap.startGameLoop();

        if (hasSeenInitialDialog) {
            gameMap.setOnFirstMove(null);
        } else {
            gameMap.setOnFirstMove(() -> onPlayerFirstStep());
        }
    }

    public void onPlayerFirstStep() {
        if (!hasSeenInitialDialog) {
            hasSeenInitialDialog = true;
            gameMap.setFlag("initialDialogSeen", true);
            gameMap.lockInput();
            gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                    "召唤法阵没有反应，应该需要一些特殊的操作",
                    () -> {
                        gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                                "也许周围的书里有说怎么启动它……",
                                () -> gameMap.unlockInput());
                    });
        }
    }

    private void handleBookInteraction() {
        if (hasReadBook) return;
        gameMap.lockInput();
        gameMap.showDialogWithChoice("/images/ui/dialogbackground.png",
                "你发现了书籍！", List.of("查看"), idx -> {
                    gameMap.showFullScreenOverlay(
                            "（扉页上写了\"远坂\"两个字，应该是笔记本的主人吧…）\n" +
                            "[…圣杯战争是为了得到能够实现持有者心愿的\"圣杯\"展开的残酷争斗。\n" +
                            "…被选中的御主master手背会显现红色的令咒……\n" +
                            "…可以使用触媒或直接在召唤阵念出下列…召唤从者servant…]\n" +
                            "（笔记本中附有一张考究的羊皮纸，召唤所需的咒语经娟秀的字体被记录于其中）",
                            () -> {
                                hasReadBook = true;
                                gameMap.setFlag("bookRead", true);
                                gameMap.completeInteractionZone("book");
                                gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                                        "(这里面的内容…看不太懂…但既然提到召唤阵，应该是要用这个咒语来召唤吧…)",
                                        () -> gameMap.unlockInput());
                            });
                });
    }

    private void handleGemInteraction() {
        if (hasPickedGem) return;
        gameMap.lockInput();
        gameMap.showDialogWithChoice("/images/ui/dialogbackground.png",
                "你发现了宝石！", List.of("拾取"), idx -> {
                    hasPickedGem = true;
                    gameMap.setFlag("gemPicked", true);
                    gameMap.completeInteractionZone("gem");
                    gameMap.unlockInput();
                });
    }

    private void handleSummonInteraction() {
        if (hasTriggeredSummon) return;
        if (!hasSeenInitialDialog) return;

        gameMap.lockInput();

        if (!hasReadBook || !hasPickedGem) {
            gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                    "好像还缺了点什么……",
                    () -> gameMap.unlockInput());
            return;
        }

        hasTriggeredSummon = true;
        gameMap.setFlag("summonTriggered", true);
        gameMap.completeInteractionZone("summon");

        gameMap.showDialogWithChoice("/images/ui/dialogbackgroundBlack.png",
                "", List.of("召唤"), idx -> {
                    gameMap.showDialogWithBackground("/images/ui/dialogbackgroundBlack.png",
                            "你：…汝为身缠三大言灵之七天 于抑止之轮降临此处，天平之守护者！",
                            () -> {
                                gameMap.showDialogWithBackground("/images/ui/dialogbackgroundBlack.png",
                                        "（明明是第一次念出这些咒语，你却觉得莫名的熟悉）",
                                        () -> onRoom1Complete());
                            });
                });
    }

    private void onRoom1Complete() {
        logger.info("Room 1 completed, transitioning to Room 2");
        if (onComplete != null) onComplete.run();
    }

    private Runnable onComplete;

    public void setOnComplete(Runnable onComplete) {
        this.onComplete = onComplete;
    }

    public boolean hasReadBook() { return hasReadBook; }
    public boolean hasPickedGem() { return hasPickedGem; }
}
