package com.game.rpg.controller.room;

import com.game.rpg.controller.battle.BattleSceneController;
import com.game.rpg.model.entities.Archer;
import com.game.rpg.model.entities.ArcherAlter;
import com.game.rpg.model.entities.CasterAlter;
import com.game.rpg.model.entities.Caster;
import com.game.rpg.model.entities.Character;
import com.game.rpg.model.entities.Cyclone;
import com.game.rpg.model.entities.Enemy;
import com.game.rpg.model.entities.Mummy;
import com.game.rpg.model.entities.RoseMonster;
import com.game.rpg.model.entities.RoseWitch;
import com.game.rpg.model.entities.Saber;
import com.game.rpg.model.entities.SaberAlter;
import com.game.rpg.model.state.GameStateManager;
import com.game.rpg.util.resource.ResourceLoader;
import com.game.rpg.util.resource.SoundManager;
import com.game.rpg.view.scene.BattleView;
import com.game.rpg.view.scene.GameMapView;
import javafx.animation.PauseTransition;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class Room7Controller {
    private static final Logger logger = LoggerFactory.getLogger(Room7Controller.class);

    private final GameMapView gameMap;
    private final ResourceLoader resourceLoader;
    private final GameStateManager stateManager;
    private final SoundManager soundManager;
    private final StackPane root;

    public Room7Controller(GameMapView gameMap, ResourceLoader resourceLoader,
                           GameStateManager stateManager, SoundManager soundManager, StackPane root) {
        this.gameMap = gameMap;
        this.resourceLoader = resourceLoader;
        this.stateManager = stateManager;
        this.soundManager = soundManager;
        this.root = root;
    }

    public void setup() {
        boolean battleDone = gameMap.getFlag("room7BattleDone");

        if (battleDone) {
            if (gameMap.getFlag("billDealDone")) {
                if (gameMap.getFlag("swordInteracted")) {
                    if (gameMap.getFlag("lakeInteractionTriggered")) {
                        if (onComplete != null) onComplete.run();
                    } else {
                        loadLakeScene();
                    }
                } else {
                    loadWheatFieldScene();
                }
            } else {
                loadMarketScene(false);
            }
            return;
        }

        gameMap.loadMap(
                "/images/enemies/WitchSavior.png",
                null,
                573, 417
        );

        gameMap.addNPC("saber", 607, 369, "/images/characters/Saber/Saber 1正面 .png", 90, 90);
        gameMap.addNPC("madoka", 539, 265, "/images/characters/archer/archer1.png", 80, 80);

        gameMap.startGameLoop();
        gameMap.lockInput();

        if (gameMap.getFlag("room7IntroPlayed")) {
            startBossBattle();
            return;
        }

        phaseOneDialog();
    }

    private void phaseOneDialog() {
        Runnable step3 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Saber：御主，小心！这个敌人的气息比之前的都要强大，不要掉以轻心！",
                () -> {
                    gameMap.hideDialog();
                    phaseOneContract();
                });

        Runnable step2 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：那个……是黑化的小圆？",
                step3);

        Runnable step1 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "（黑化的气息从那个身影中散发出来，原本温柔的面容被绝望扭曲）",
                step2);

        step1.run();
    }

    private void phaseOneContract() {
        gameMap.setFlag("room7IntroPlayed", true);
        gameMap.showContractScene(() -> {
            gameMap.setFlag("archerUnlocked", true);
            startBossBattle();
        });
    }

    private void startBossBattle() {
        gameMap.stopGameLoop();

        List<Character> party = new ArrayList<>();
        party.add(new Saber());
        party.add(new Archer());
        party.add(new Caster());

        Enemy boss = new ArcherAlter();

        BattleSceneController battleCtrl = new BattleSceneController(stateManager, soundManager);
        battleCtrl.setLockedCharacters(List.of(2));

        battleCtrl.setOnVictory(() -> {
            BattleView battleView = battleCtrl.getBattleView();
            root.getChildren().remove(battleView);
            gameMap.toFront();
            gameMap.startGameLoop();
            gameMap.lockInput();
            onBattleVictory();
        });

        battleCtrl.setOnDefeat(() -> {
            BattleView battleView = battleCtrl.getBattleView();
            root.getChildren().remove(battleView);
            gameMap.toFront();
            gameMap.startGameLoop();
            gameMap.unlockInput();
            if (onComplete != null) onComplete.run();
        });

        BattleView battleView = battleCtrl.getBattleView();
        root.getChildren().add(battleView);
        battleView.toFront();

        battleCtrl.startBattle(party, boss, true, (Stage) root.getScene().getWindow());
    }

    private void onBattleVictory() {
        gameMap.setFlag("room7BattleDone", true);

        gameMap.loadMap(
                "/images/backgrounds/classroomWhite(2).png",
                null,
                573, 417
        );
        gameMap.addNPC("saber", 607, 369, "/images/characters/Saber/Saber 1正面 .png", 90, 90);
        gameMap.addNPC("madoka", 539, 265, "/images/characters/archer/archer1.png", 80, 80);
        gameMap.startGameLoop();
        gameMap.lockInput();

        gameMap.showSkinUnlockHint("Archer");

        PauseTransition wait1s = new PauseTransition(Duration.seconds(1));
        wait1s.setOnFinished(e -> stageOneDialog());
        wait1s.play();
    }

    private void stageOneDialog() {
        Runnable step2 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：那么，我们继续出发吧。",
                () -> {
                    gameMap.hideDialog();
                    transitionToMarket();
                });

        Runnable step1 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "小圆：我不想再让魔法少女哭泣了。所以，请让我和你们一起销毁在这里散布绝望的源头——被污染的圣杯吧。",
                step2);

        step1.run();
    }

    private void transitionToMarket() {
        gameMap.stopGameLoop();
        gameMap.fadeToBlack(() -> {
            loadMarketScene();
            gameMap.fadeInFromBlack(() -> {
                PauseTransition wait0_5s = new PauseTransition(Duration.millis(500));
                wait0_5s.setOnFinished(e -> stageTwoDialog());
                wait0_5s.play();
            });
        });
    }

    private void loadMarketScene() {
        loadMarketScene(true);
    }

    private void loadMarketScene(boolean lockInput) {
        gameMap.loadMap(
                "/images/backgrounds/market.jpg",
                "/maps/market.tmj",
                200, 400
        );
        gameMap.addNPC("saber", 250, 420, "/images/characters/Saber/Saber 1正面 .png", 90, 90);
        gameMap.addNPC("madoka", 300, 420, "/images/characters/archer/archer1.png", 80, 80);
        gameMap.startGameLoop();

        if (!gameMap.getFlag("cornChipInteracted")) {
            gameMap.addInteractionZone("cornChip", 422, 462, 60, 60,
                    () -> onCornChipInteract(), true, 422 + 30, 462);
        }

        if (lockInput) {
            gameMap.lockInput();
        } else {
            gameMap.unlockInput();
        }
    }

    private void loadWheatFieldScene() {
        gameMap.loadMap(
                "/images/backgrounds/wheatFiled2.png",
                "/maps/wheatFilled2.tmj",
                494, 487
        );
        gameMap.addNPC("saber", 245, 492, "/images/characters/Saber/Saber 1正面 .png", 120, 120);
        gameMap.addNPC("madoka", 136, 436, "/images/characters/archer/archer1.png", 120, 120);
        gameMap.addNPC("bill", 362, 451, "/images/characters/Caster/Bill正面2.png", 120, 120);

        if (!gameMap.getFlag("swordInteracted")) {
            gameMap.addInteractionZone("sword", 1087, 494, 60, 60,
                    () -> onSwordInteract(), true, 1087, 534, "/images/ui/starTipBlue.png");
        }

        gameMap.startGameLoop();
        gameMap.unlockInput();
    }

    private void loadLakeScene() {
        gameMap.loadMap(
                "/images/backgrounds/lake.png",
                "/maps/lake.tmj",
                741, 606
        );
        gameMap.addNPC("saber", 886, 506, "/images/characters/Saber/Saber 1正面 .png", 100, 100);
        gameMap.addNPC("madoka", 326, 529, "/images/characters/archer/archer1.png", 100, 100);
        gameMap.addNPC("bill", 484, 613, "/images/characters/Caster/Bill正面1.png", 100, 100);

        if (!gameMap.getFlag("lakeInteractionTriggered")) {
            gameMap.addInteractionZone("lakeGrail", 625, 386, 60, 60,
                    () -> onLakeInteract(), true, 625, 386);
        }

        gameMap.startGameLoop();
        gameMap.unlockInput();
    }

    private void stageTwoDialog() {
        Runnable step5 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "（寻找汽水，好多商品都蒙着一层灰，应该很久很久都没有人来过了）",
                () -> {
                    gameMap.hideDialog();
                    gameMap.unlockInput();
                });

        Runnable step4 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：…………",
                step5);

        Runnable step3 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "（无人回应）",
                step4);

        Runnable step2 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：正好有点渴了，看看能不能买一罐汽水。你好里面有人吗？",
                step3);

        Runnable step1 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你（内心OS）：好突然，但是经历了这么多事，出现一个超市也不用大惊小怪了……",
                step2);

        step1.run();
    }

    private void onCornChipInteract() {
        gameMap.setFlag("cornChipInteracted", true);
        gameMap.lockInput();

        Runnable step2 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：打开看看有没有坏。",
                () -> {
                    gameMap.hideDialog();
                    gameMap.showScreenShake(() -> {
                        gameMap.loadMap(
                                "/images/characters/Caster/Billcg.png",
                                null,
                                gameMap.getPlayerX(), gameMap.getPlayerY()
                        );

                        gameMap.startGameLoop();
                        gameMap.lockInput();
                        stageThreeBangDialog();
                    });
                });

        Runnable step1 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "（一个角落，莫名有一包比较新的玉米片）",
                step2);

        step1.run();
    }

    private void stageThreeBangDialog() {
        gameMap.setPlayerVisible(false);
        gameMap.waitForClick(() -> {
            gameMap.setPlayerVisible(true);
            stageThreeReturnToMarket();
        });
    }

    private void stageThreeReturnToMarket() {
        double savedPlayerX = gameMap.getPlayerX();
        double savedPlayerY = gameMap.getPlayerY();

        gameMap.loadMap(
                "/images/backgrounds/market.jpg",
                "/maps/market.tmj",
                savedPlayerX, savedPlayerY
        );
        gameMap.addNPC("saber", 250, 420, "/images/characters/Saber/Saber 1正面 .png", 90, 90);
        gameMap.addNPC("madoka", 300, 420, "/images/characters/archer/archer1.png", 80, 80);
        gameMap.startGameLoop();
        gameMap.lockInput();

        PauseTransition wait1s = new PauseTransition(Duration.seconds(1));
        wait1s.setOnFinished(e -> {
            gameMap.addNPC("bill", 422, 462, "/images/characters/Caster/Bill正面1.png", 80, 80);
            stageFourDialog();
        });
        wait1s.play();
    }

    private void stageFourDialog() {
        Runnable step4 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "???：这里是什么地方？还有不准叫我玉米片！",
                () -> {
                    gameMap.hideDialog();
                    stageFourBlackScreen();
                });

        Runnable step3 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：…………见鬼了，还是个玉米片鬼。",
                step4);

        Runnable step2 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "???：终于从那该死的医院跑出来了。感谢那个爱吃玉米片的蠢货，让我能解离精神体藏在玉米片里，一旦我统治宇宙我要毁掉每个时空每个领域每个维度甚至平行宇宙的玉米片！",
                step3);

        step2.run();
    }

    private void stageFourBlackScreen() {
        gameMap.showBlackScreenWithText(
                "（三角形生物尝试攻击，发现自己没了力量来源，而你体内充盈着一股强大的力量，并且有一股最容易被利用的黑暗污染）",
                () -> {
                    gameMap.loadMap(
                            "/images/backgrounds/market.jpg",
                            "/maps/market.tmj",
                            gameMap.getPlayerX(), gameMap.getPlayerY()
                    );
                    gameMap.addNPC("saber", 250, 420, "/images/characters/Saber/Saber 1正面 .png", 90, 90);
                    gameMap.addNPC("madoka", 300, 420, "/images/characters/archer/archer1.png", 80, 80);
                    gameMap.addNPC("bill", 422, 462, "/images/characters/Caster/Bill正面1.png", 80, 80);
                    gameMap.startGameLoop();
                    gameMap.lockInput();
                    stageFourReturnDialog();
                });
    }

    private void stageFourReturnDialog() {
        Runnable step6 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "???：我现在没有能量供给，对任何东西都产生不了实质性的伤害，而你对我就像一个核能发电厂，而我可以将你的能量，转化为你们难以想象，甚至不可名状的力量。",
                () -> {
                    gameMap.hideDialog();
                    transitionToMarketSummon();
                });

        Runnable step5 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "???：well well well，刚刚恕我冒昧，我来自一个很远很远的地方，我叫Bill Cipher，刚刚和你对视时，浅浅参观了一下你的精神世界，了解到我应该是被那个叫圣杯的东西当作Caster召唤来的。那我或许能在你们寻找圣杯的途中尽一份'绵薄之力'，要不要和我做个交易呢？",
                step6);

        Runnable step4 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Saber：御主最好不要靠近，这个东西充满着危险的气息。",
                step5);

        Runnable step3 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：你在说什么？",
                step4);

        Runnable step2 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "???（小声低语）：……有趣，或许可以成为我翻盘的皇家同花顺。",
                step3);

        step2.run();
    }

    private void transitionToMarketSummon() {
        gameMap.stopGameLoop();
        gameMap.fadeToBlack(() -> {
            gameMap.loadMap(
                    "/images/backgrounds/marketSummon.png",
                    "/maps/marketSommom.tmj",
                    gameMap.getPlayerX(), gameMap.getPlayerY()
            );
            gameMap.addNPC("saber", 250, 420, "/images/characters/Saber/Saber 1正面 .png", 90, 90);
            gameMap.addNPC("madoka", 300, 420, "/images/characters/archer/archer1.png", 80, 80);
            gameMap.addNPC("bill", 422, 462, "/images/characters/Caster/Bill正面1.png", 80, 80);
            gameMap.startGameLoop();
            gameMap.lockInput();

            gameMap.fadeInFromBlack(() -> {
                PauseTransition wait0_5s = new PauseTransition(Duration.millis(500));
                wait0_5s.setOnFinished(e -> stageFiveDialog());
                wait0_5s.play();
            });
        });
    }

    private void stageFiveDialog() {
        Runnable step3 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：凭什么相信你？你刚刚还偷窥我的精神世界。",
                () -> {
                    gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                            "（远处的货架传来一阵骚动，一眨眼一个有好几条触手舌头冒着蓝火红色的巨大三角形已经在眼前）",
                            () -> {
                                gameMap.hideDialog();
                                stageFiveNewcg();
                            });
                });

        Runnable step2 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "（Bill伸出手等待你的回应）",
                step3);

        step2.run();
    }

    private void stageFiveNewcg() {
        gameMap.showScreenShake(() -> {
            gameMap.loadMap(
                    "/images/characters/Caster/newcg.png",
                    null,
                    gameMap.getPlayerX(), gameMap.getPlayerY()
            );
            gameMap.addNPC("saber", 250, 420, "/images/characters/Saber/Saber 1正面 .png", 90, 90);
            gameMap.addNPC("madoka", 300, 420, "/images/characters/archer/archer1.png", 80, 80);
            gameMap.startGameLoop();
            gameMap.lockInput();

            stageFiveNewcgDialog();
        });
    }

    private void stageFiveNewcgDialog() {
        Runnable step5 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Bill：deal~",
                () -> {
                    gameMap.hideDialog();
                    gameMap.showContractScene(() -> startCasterAlterBattle());
                });

        Runnable step4 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "（眼前的红色怪物发出低吼，一个踉跄你握住了那只伸出的手）",
                step5);

        Runnable step3 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Bill：亲爱的没时间考虑了，快和我握手。",
                step4);

        Runnable step2 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：什么鬼！！！",
                step3);

        step2.run();
    }

    private void startCasterAlterBattle() {
        gameMap.stopGameLoop();

        List<Character> party = new ArrayList<>();
        party.add(new Saber());
        party.add(new Archer());
        party.add(new Caster());

        Enemy boss = new CasterAlter();

        BattleSceneController battleCtrl = new BattleSceneController(stateManager, soundManager);

        battleCtrl.setOnVictory(() -> {
            BattleView battleView = battleCtrl.getBattleView();
            root.getChildren().remove(battleView);
            gameMap.toFront();
            gameMap.startGameLoop();
            gameMap.lockInput();
            onCasterAlterVictory();
        });

        battleCtrl.setOnDefeat(() -> {
            BattleView battleView = battleCtrl.getBattleView();
            root.getChildren().remove(battleView);
            gameMap.toFront();
            gameMap.startGameLoop();
            gameMap.unlockInput();
            if (onComplete != null) onComplete.run();
        });

        BattleView battleView = battleCtrl.getBattleView();
        root.getChildren().add(battleView);
        battleView.toFront();

        battleCtrl.startBattle(party, boss, true, (Stage) root.getScene().getWindow());
    }

    private void onCasterAlterVictory() {
        gameMap.setFlag("billDealDone", true);
        gameMap.setFlag("casterUnlocked", true);

        gameMap.loadMap(
                "/images/backgrounds/marketSummon.png",
                "/maps/marketSommom.tmj",
                gameMap.getPlayerX(), gameMap.getPlayerY()
        );
        gameMap.addNPC("saber", 250, 420, "/images/characters/Saber/Saber 1正面 .png", 90, 90);
        gameMap.addNPC("madoka", 300, 420, "/images/characters/archer/archer1.png", 80, 80);
        gameMap.addNPC("bill", 422, 462, "/images/characters/Caster/Bill正面1.png", 80, 80);
        gameMap.startGameLoop();
        gameMap.lockInput();

        gameMap.showSkinUnlockHint("Caster");

        PauseTransition wait1s = new PauseTransition(Duration.seconds(1));
        wait1s.setOnFinished(e -> postBattleDialog());
        wait1s.play();
    }

    private void postBattleDialog() {
        Runnable step2 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Bill：你们这个时空还真是混乱呢，不过倒也有趣。合作愉快~",
                () -> {
                    gameMap.hideDialog();
                    transitionToWheatField();
                });

        Runnable step1 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：那个东西也是你…对吧。",
                step2);

        step1.run();
    }

    private void transitionToWheatField() {
        gameMap.stopGameLoop();
        gameMap.fadeToBlack(() -> {
            gameMap.loadMap(
                    "/images/backgrounds/wheatFiled2.png",
                    "/maps/wheatFilled2.tmj",
                    494, 487
            );
            gameMap.addNPC("saber", 245, 492, "/images/characters/Saber/Saber 1正面 .png", 120, 120);
            gameMap.addNPC("madoka", 136, 436, "/images/characters/archer/archer1.png", 120, 120);
            gameMap.addNPC("bill", 362, 451, "/images/characters/Caster/Bill正面2.png", 120, 120);

            if (!gameMap.getFlag("swordInteracted")) {
                gameMap.addInteractionZone("sword", 1087, 494, 60, 60,
                        () -> onSwordInteract(), true, 1087, 534, "/images/ui/starTipBlue.png");
            }

            gameMap.startGameLoop();
            gameMap.lockInput();

            gameMap.fadeInFromBlack(() -> {
                PauseTransition wait0_5s = new PauseTransition(Duration.millis(500));
                wait0_5s.setOnFinished(e -> wheatFieldDialog());
                wait0_5s.play();
            });
        });
    }

    private void wheatFieldDialog() {
        Runnable step5 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Saber：我多希望我真的又回到了故乡……",
                () -> gameMap.hideDialog());

        Runnable step4 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "（沿着小路向前，麦香的风徐徐吹拂）",
                step5);

        Runnable step3 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Saber：圣杯还在读取我们的记忆，御主，我们得加快速度了。",
                step4);

        Runnable step2 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Bill：…噢～又是一个幻境，瞧瞧这美味的混乱！",
                step3);

        Runnable step1 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "（你们一行人继续向着圣杯靠近）",
                step2);

        step1.run();
    }

    private void onSwordInteract() {
        gameMap.setFlag("swordInteracted", true);
        gameMap.lockInput();

        gameMap.showBlackScreenWithText(
                "（它正等待着不列颠注定的君王……）",
                () -> {
                    gameMap.loadMap(
                            "/images/backgrounds/wheatFiled2.png",
                            "/maps/wheatFilled2.tmj",
                            gameMap.getPlayerX(), gameMap.getPlayerY()
                    );
                    gameMap.startGameLoop();
                    gameMap.lockInput();
                    swordDialog();
                });
    }

    private void swordDialog() {
        Runnable step4 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "（Saber的手握住了剑柄）",
                () -> {
                    gameMap.hideDialog();
                    showStoneSwordCG();
                });

        Runnable step3 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Saber：那么……",
                step4);

        Runnable step2 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "小圆：这一个幻境的力量都汇集在这把剑上，拔出它后我们就会面圣杯了。",
                step3);

        Runnable step1 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Saber：不过，这里也终究只是梦境罢了……那个愿望也不会在这里实现……",
                step2);

        step1.run();
    }

    private void showStoneSwordCG() {
        gameMap.showCGWithFadeIn("/images/characters/Saber/stoneSword.png", () -> {
            transitionToLake();
        });
    }

    private void transitionToLake() {
        gameMap.stopGameLoop();
        gameMap.fadeToBlack(() -> {
            gameMap.loadMap(
                    "/images/backgrounds/lake.png",
                    "/maps/lake.tmj",
                    741, 606
            );
            gameMap.addNPC("saber", 886, 506, "/images/characters/Saber/Saber 1正面 .png", 100, 100);
            gameMap.addNPC("madoka", 326, 529, "/images/characters/archer/archer1.png", 100, 100);
            gameMap.addNPC("bill", 484, 613, "/images/characters/Caster/Bill正面1.png", 100, 100);

            if (!gameMap.getFlag("lakeInteractionTriggered")) {
                gameMap.addInteractionZone("lakeGrail", 625, 386, 60, 60,
                        () -> onLakeInteract(), true, 625, 386);
            }

            gameMap.startGameLoop();
            gameMap.lockInput();

            gameMap.fadeInFromBlack(() -> {
                PauseTransition wait1_5s = new PauseTransition(Duration.millis(1500));
                wait1_5s.setOnFinished(e -> lakeDialog());
                wait1_5s.play();
            });
        });
    }

    private void lakeDialog() {
        Runnable step5 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "小圆：还能感觉到圣杯的存在，它就在不远的地方，我们找一找吧。",
                () -> gameMap.hideDialog());

        Runnable step4 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Bill：（压低声音，神秘兮兮地）底下全是秘密、怪物，还有我留下的烂摊子。（又是一阵怪笑）",
                step5);

        Runnable step3 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Bill：（夸张地捂住胸口，做出呕吐状）这让我想起那个小镇，表面上也是一副人畜无害的乖模样，结果呢？",
                step4);

        Runnable step2 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Bill：（悬浮在湖面上方，发出咯咯的笑声）噢——这地方甜得让我牙疼！",
                step3);

        Runnable step1 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：咦？圣杯不在这里？",
                step2);

        step1.run();
    }

    private void onLakeInteract() {
        gameMap.setFlag("lakeInteractionTriggered", true);
        gameMap.lockInput();

        gameMap.showScreenShake(() -> {
            gameMap.addNPC("roseMonster", 485, 479, "/images/enemies/RoseMonster.png", 100, 100);
            gameMap.addNPC("roseWitch", 759, 479, "/images/enemies/RoseWitch.png", 100, 100);
            gameMap.addNPC("monster4", 396, 288, "/images/enemies/monster4.png", 100, 100);
            gameMap.addNPC("monster5", 860, 280, "/images/enemies/monster5.png", 100, 100);

            PauseTransition wait2s = new PauseTransition(Duration.seconds(2));
            wait2s.setOnFinished(e -> startLakeBattleSequence(0));
            wait2s.play();
        });
    }

    private void startLakeBattleSequence(int battleIndex) {
        gameMap.stopGameLoop();

        List<Character> party = new ArrayList<>();
        party.add(new Saber());
        party.add(new Archer());
        party.add(new Caster());

        Enemy enemy = switch (battleIndex) {
            case 0 -> new Mummy();
            case 1 -> new Cyclone();
            case 2 -> new RoseMonster();
            case 3 -> new RoseWitch();
            case 4 -> new SaberAlter();
            default -> throw new IllegalArgumentException("Invalid battle index: " + battleIndex);
        };

        BattleSceneController battleCtrl = new BattleSceneController(stateManager, soundManager);

        final int idx = battleIndex;
        battleCtrl.setOnVictory(() -> {
            BattleView battleView = battleCtrl.getBattleView();
            root.getChildren().remove(battleView);
            gameMap.toFront();
            gameMap.startGameLoop();
            gameMap.lockInput();

            if (idx < 4) {
                startLakeBattleSequence(idx + 1);
            } else {
                onRoom7Complete();
            }
        });

        battleCtrl.setOnDefeat(() -> {
            BattleView battleView = battleCtrl.getBattleView();
            root.getChildren().remove(battleView);
            gameMap.toFront();
            gameMap.startGameLoop();
            gameMap.unlockInput();
            if (onComplete != null) onComplete.run();
        });

        battleCtrl.setOnBattleEnd(() -> {
            BattleView battleView = battleCtrl.getBattleView();
            root.getChildren().remove(battleView);
            gameMap.toFront();
            gameMap.startGameLoop();
            gameMap.unlockInput();

            String npcId = switch (idx) {
                case 0 -> "monster4";
                case 1 -> "monster5";
                case 2 -> "roseMonster";
                case 3 -> "roseWitch";
                default -> null;
            };
            if (npcId != null) gameMap.removeNPC(npcId);

            if (idx < 4) {
                startLakeBattleSequence(idx + 1);
            }
        });

        BattleView battleView = battleCtrl.getBattleView();
        root.getChildren().add(battleView);
        battleView.toFront();

        battleCtrl.startBattle(party, enemy, battleIndex == 4, (Stage) root.getScene().getWindow());
    }

    private void onRoom7Complete() {
        logger.info("Room 7 completed");


        gameMap.removeNPC("roseMonster");
        gameMap.removeNPC("roseWitch");
        gameMap.removeNPC("monster4");
        gameMap.removeNPC("monster5");

        gameMap.stopGameLoop();
        gameMap.fadeToBlack(() -> {
            gameMap.loadMap(
                    "/images/backgrounds/HolyGrail.jpg",
                    null,
                    741, 606
            );
            gameMap.startGameLoop();
            gameMap.lockInput();

            gameMap.fadeInFromBlack(() -> endingDialog());
        });
    }

    private void endingDialog() {
        gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "你：破坏掉圣杯吧！",
                () -> {
                    gameMap.hideDialog();
                    showEndingChoice();
                });
    }

    private void showEndingChoice() {
        gameMap.showDialogWithChoice("/images/ui/dialogbackground.png",
                "", List.of("--Saber!", "--Archer!", "--Caster!"), idx -> {
                    String response = switch (idx) {
                        case 0 -> "Saber：集结的星之吐息…Excalibur";
                        case 1 -> "小圆：嗯，交给我吧！";
                        case 2 -> "Bill：#$&+*￥";
                        default -> "";
                    };
                    gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                            response,
                            () -> {
                                gameMap.hideDialog();
                                destroyGrailSequence();
                            });
                });
    }

    private void destroyGrailSequence() {
        gameMap.showWhiteFlash(() -> {
            gameMap.loadMap(
                    "/images/backgrounds/lake.png",
                    "/maps/lake.tmj",
                    741, 606
            );
            gameMap.addNPC("saber", 886, 506, "/images/characters/Saber/Saber 1正面 .png", 100, 100);
            gameMap.addNPC("madoka", 326, 529, "/images/characters/archer/archer1.png", 100, 100);
            gameMap.addNPC("bill", 484, 613, "/images/characters/Caster/Bill正面1.png", 100, 100);
            gameMap.startGameLoop();
            gameMap.lockInput();

            PauseTransition wait1_5s = new PauseTransition(Duration.millis(1500));
            wait1_5s.setOnFinished(e -> showAchievement());
            wait1_5s.play();
        });
    }

    private void showAchievement() {
        com.game.rpg.view.component.AchievementPopup.unlockGrailWarVictor();
        gameMap.showBlackScreenWithText(
                "[获得成就：圣杯战争最终胜利者]",
                javafx.scene.paint.Color.GOLD, 32,
                () -> {
                    gameMap.showEndingScreen(
                            "/images/ui/背景保留.png",
                            "参与人员：\n张誉霆 郑宇煊 黄君格 刘启芮\n\n感谢各位协力完成本次游戏开发！\n特别感谢华为云码道！\n\n音乐:\n\"梶浦由記 - Gradus prohibitus\"\n\"梶浦由記 - Desiderium\"\n\"HOYO-MiX - 振翅 Wingflap\"\n\"HOYO-MiX - 唯有胜利 Victory Above All\"\n\"Kalafina - Magia\"\n\"Nox Arcana - Magic and Moonlight\"\n\"HOYO-MiX - 圣杯之夜 Night of the Holy Grail\"\n\"HOYO-MiX - 理想乡 Utopia\"",
                            () -> {
                                if (onComplete != null) onComplete.run();
                            }
                    );
                });
    }

    private Runnable onComplete;

    public void setOnComplete(Runnable onComplete) {
        this.onComplete = onComplete;
    }
}
