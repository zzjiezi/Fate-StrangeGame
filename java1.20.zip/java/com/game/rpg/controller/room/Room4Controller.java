package com.game.rpg.controller.room;

import com.game.rpg.util.resource.ResourceLoader;
import com.game.rpg.view.scene.GameMapView;
import javafx.animation.PauseTransition;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Room4Controller {
    private static final Logger logger = LoggerFactory.getLogger(Room4Controller.class);

    private final GameMapView gameMap;
    private final ResourceLoader resourceLoader;

    public Room4Controller(GameMapView gameMap, ResourceLoader resourceLoader) {
        this.gameMap = gameMap;
        this.resourceLoader = resourceLoader;
    }

    public void setup() {
        gameMap.loadMap(
                "/images/backgrounds/classroomWhite.png",
                "/maps/classroomWhite.tmj",
                573, 417
        );

        gameMap.addNPC("saber", 607, 369, "/images/characters/Saber/Saber 1正面 .png", 90, 90);
        gameMap.startGameLoop();
        gameMap.lockInput();

        gameMap.fadeInFromBlack(() -> {
            PauseTransition wait1_5s = new PauseTransition(Duration.millis(1500));
            wait1_5s.setOnFinished(e -> showDialogue());
            wait1_5s.play();
        });
    }

    private void showDialogue() {
        Runnable step13 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "小圆: （恍惚）不对……",
                () -> onDialogueComplete(),
                false);

        Runnable step12 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "蓝发女孩: （转身）小圆，你怎么了？",
                step13);

        Runnable step11 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "粉发女孩: 嗯？！不会吧，难道说……",
                step12);

        Runnable step10 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "（门外走进来一位长相乖巧的黑发女孩。）",
                step11);

        Runnable step9 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "老师: 那么，晓美同学，欢迎。",
                step10);

        Runnable step8 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "老师: 好了，接下来，今天向大家介绍一位转学生。",
                step9);

        Runnable step7 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "粉发女孩: （笑）看来是呢。",
                step8);

        Runnable step6 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "蓝发女孩: 看来老师的恋爱又吹了呀。",
                step7);

        Runnable step5 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "老师: 如果认为煎鸡蛋的程度能决定女人的魅力就大错特错了！！！女生们，你们千万不要跟只吃半熟鸡蛋的男人交往！！",
                step6);

        Runnable step4 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "老师: 同学们，煎鸡蛋，应该全熟还是半熟？",
                step5);

        Runnable step3 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "（奇怪的是，他们好像看不见你和Saber，没有人表现出任何异常。）",
                step4);

        Runnable step2 = () -> gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "Saber: （小声）御主，这恐怕是一个幻境，我暂时无法分辨出敌人在哪里，请务必小心。",
                step3);

        gameMap.showDialogWithBackground("/images/ui/dialogbackground.png",
                "（教室里坐着许多学生，看样子，他们正在上课）",
                step2);
    }

    private void onDialogueComplete() {
        gameMap.showWhiteFlash(() -> {
            gameMap.hideDialog();

            gameMap.playVideo("/video/Memory.mp4", () -> {
                logger.info("Room 4 video finished");
                if (onComplete != null) onComplete.run();
            });
        });
    }

    private Runnable onComplete;

    public void setOnComplete(Runnable onComplete) {
        this.onComplete = onComplete;
    }
}