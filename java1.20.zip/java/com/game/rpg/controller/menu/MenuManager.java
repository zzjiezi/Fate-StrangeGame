package com.game.rpg.controller.menu;

import com.game.rpg.util.save.SaveManager;
import com.game.rpg.util.toast.ToastUtil;
import com.game.rpg.view.scene.GameMapView;
import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.Tooltip;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class MenuManager {
    private static final Logger logger = LoggerFactory.getLogger(MenuManager.class);

    private final Stage primaryStage;
    private final StackPane root;
    private final Image[] characterImages;
    private final String[] characterNames = {"默认玩家", "Saber", "Archer", "Caster"};
    private final boolean[] unlocked = {true, false, false, false};
    private int currentSkinIndex = 0;
    private Runnable onSkinChanged;
    private Runnable onReturnToMainMenu;
    private Runnable onPauseGame;
    private Runnable onResumeGame;
    private GameMapView gameMapView;
    private String currentMapId = "room1";

    private Pane menuButton;
    private StackPane menuOverlay;
    private boolean menuOpen = false;

    public MenuManager(Stage primaryStage, StackPane root, Image[] characterImages, GameMapView gameMapView) {
        this.primaryStage = primaryStage;
        this.root = root;
        this.characterImages = characterImages;
        this.gameMapView = gameMapView;
    }

    public Pane createMenuButton() {
        StackPane btn = new StackPane();
        btn.setPrefSize(44, 44);

        Circle circle = new Circle(22, Color.rgb(50, 50, 50, 0.8));
        circle.setStroke(Color.WHITE);
        circle.setStrokeWidth(1.5);

        VBox lines = new VBox(4);
        lines.setAlignment(javafx.geometry.Pos.CENTER);
        for (int i = 0; i < 3; i++) {
            Rectangle line = new Rectangle(18, 2.5, Color.WHITE);
            lines.getChildren().add(line);
        }

        btn.getChildren().addAll(circle, lines);
        btn.setLayoutX(1280 - 60);
        btn.setLayoutY(16);
        btn.setStyle("-fx-cursor: hand;");

        btn.setOnMouseEntered(e -> btn.setScaleX(1.1));
        btn.setOnMouseEntered(e -> btn.setScaleY(1.1));
        btn.setOnMouseExited(e -> btn.setScaleX(1.0));
        btn.setOnMouseExited(e -> btn.setScaleY(1.0));
        btn.setOnMouseClicked(e -> {
            btn.setScaleX(1.0);
            btn.setScaleY(1.0);
            toggleMenu();
        });

        this.menuButton = btn;
        return btn;
    }

    private void toggleMenu() {
        if (menuOpen) {
            closeMenu();
        } else {
            openMenu();
        }
    }

    private void openMenu() {
        menuOpen = true;
        if (onPauseGame != null) onPauseGame.run();
        menuOverlay = new StackPane();
        menuOverlay.setPrefSize(1280, 720);

        Rectangle dimBg = new Rectangle(1280, 720, Color.rgb(0, 0, 0, 0.5));
        dimBg.setOnMouseClicked(e -> closeMenu());

        VBox menuBox = new VBox(20);
        menuBox.setAlignment(javafx.geometry.Pos.CENTER);
        menuBox.setPrefWidth(280);
        menuBox.setStyle("-fx-background-color: rgba(20, 20, 30, 0.95); " +
                "-fx-background-radius: 16; -fx-padding: 30 40;");

        String[] options = {"角色外观", "自动保存", "退出游戏", "返回游戏"};
        for (String opt : options) {
            Text label = new Text(opt);
            label.setFont(Font.font("STSong", 24));
            label.setFill(Color.WHITE);
            label.setStyle("-fx-cursor: hand;");
            label.setOnMouseEntered(e -> label.setFill(Color.valueOf("#FFD700")));
            label.setOnMouseExited(e -> label.setFill(Color.WHITE));
            label.setOnMouseClicked(e -> handleOption(opt));
            menuBox.getChildren().add(label);
        }

        menuOverlay.getChildren().addAll(dimBg, menuBox);
        menuOverlay.setOpacity(0);

        Pane hintLayer = null;
        ObservableList<Node> children = root.getChildren();
        for (Node node : children) {
            if (node instanceof Pane && "hintLayer".equals(node.getId())) {
                hintLayer = (Pane) node;
                break;
            }
        }
        if (hintLayer != null) {
            children.add(children.indexOf(hintLayer), menuOverlay);
        } else {
            children.add(menuOverlay);
        }

        FadeTransition fadeIn = new FadeTransition(Duration.millis(300), menuOverlay);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        fadeIn.play();
    }

    private void closeMenu() {
        if (menuOverlay == null) return;
        menuOpen = false;
        if (onResumeGame != null) onResumeGame.run();
        FadeTransition fadeOut = new FadeTransition(Duration.millis(200), menuOverlay);
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);
        fadeOut.setOnFinished(e -> root.getChildren().remove(menuOverlay));
        fadeOut.play();
    }

    private void handleOption(String option) {
        switch (option) {
            case "角色外观" -> showSkinSelector();
            case "自动保存" -> doSave();
            case "退出游戏" -> showExitConfirm();
            case "返回游戏" -> closeMenu();
        }
    }

    private void showSkinSelector() {
        syncUnlockedFromFlags();

        StackPane skinOverlay = new StackPane();
        skinOverlay.setPrefSize(1280, 720);

        Rectangle dimBg = new Rectangle(1280, 720, Color.rgb(0, 0, 0, 0.4));
        dimBg.setOnMouseClicked(e -> root.getChildren().remove(skinOverlay));

        StackPane skinBox = new StackPane();
        skinBox.setPrefSize(520, 220);
        skinBox.setMaxSize(520, 220);
        skinBox.setStyle("-fx-background-color: rgba(20, 20, 30, 0.95); " +
                "-fx-background-radius: 16;");

        HBox hbox = new HBox(20);
        hbox.setAlignment(javafx.geometry.Pos.CENTER);

        for (int i = 0; i < characterNames.length; i++) {
            final int idx = i;
            VBox charBox = new VBox(8);
            charBox.setAlignment(javafx.geometry.Pos.CENTER);

            StackPane imgContainer = new StackPane();
            imgContainer.setPrefSize(80, 80);
            imgContainer.setMaxSize(80, 80);

            ImageView iv = new ImageView();
            iv.setFitWidth(80);
            iv.setFitHeight(80);
            iv.setPreserveRatio(true);
            iv.setSmooth(false);

            if (characterImages != null && i < characterImages.length && characterImages[i] != null) {
                iv.setImage(characterImages[i]);
            }

            Circle clip = new Circle(40);
            clip.setCenterX(40);
            clip.setCenterY(40);
            iv.setClip(clip);

            imgContainer.getChildren().add(iv);

            if (!unlocked[i]) {
                ColorAdjust gray = new ColorAdjust();
                gray.setBrightness(-0.6);
                iv.setEffect(gray);
                Tooltip tooltip = new Tooltip("未解锁");
                Tooltip.install(imgContainer, tooltip);
            } else {
                imgContainer.setStyle("-fx-cursor: hand;");
                imgContainer.setOnMouseClicked(e -> {
                    currentSkinIndex = idx;
                    if (onSkinChanged != null) onSkinChanged.run();
                    root.getChildren().remove(skinOverlay);
                    ToastUtil.showToast(root, "已切换到" + characterNames[idx], Color.WHITE);
                });
            }

            Text name = new Text(characterNames[i]);
            name.setFont(Font.font("STSong", 14));
            name.setFill(unlocked[i] ? Color.WHITE : Color.GRAY);

            charBox.getChildren().addAll(imgContainer, name);
            hbox.getChildren().add(charBox);
        }

        skinBox.getChildren().add(hbox);
        skinOverlay.getChildren().addAll(dimBg, skinBox);
        root.getChildren().add(skinOverlay);
    }

    private Map<String, Boolean> gameFlags;

    private void doSave() {
        Rectangle overlay = new Rectangle(1280, 720, Color.rgb(0, 0, 0, 0.3));
        overlay.setMouseTransparent(false);
        root.getChildren().add(overlay);

        new Thread(() -> {
            double px = gameMapView != null ? gameMapView.getPlayerX() : 428;
            double py = gameMapView != null ? gameMapView.getPlayerY() : 387;
            String mapId = gameMapView != null ? gameMapView.getCurrentMapId() : currentMapId;
            int skinIdx = gameMapView != null ? gameMapView.getSkinIndex() : currentSkinIndex;
            Map<String, Boolean> flags = gameMapView != null ? gameMapView.getGameFlags() : gameFlags;
            boolean success = SaveManager.saveGame(px, py, unlocked, skinIdx, mapId, flags);
            Platform.runLater(() -> {
                root.getChildren().remove(overlay);
                if (success) {
                    ToastUtil.showToast(root, "✅ 游戏已保存", Color.LIGHTGREEN);
                } else {
                    ToastUtil.showToast(root, "❌ 保存失败，请检查磁盘空间", Color.RED);
                }
            });
        }).start();
    }

    private void showExitConfirm() {
        StackPane confirmOverlay = new StackPane();
        confirmOverlay.setPrefSize(1280, 720);

        Rectangle dimBg = new Rectangle(1280, 720, Color.rgb(0, 0, 0, 0.6));
        dimBg.setOnMouseClicked(e -> {});

        VBox dialog = new VBox(16);
        dialog.setAlignment(javafx.geometry.Pos.CENTER);
        dialog.setPrefWidth(360);
        dialog.setStyle("-fx-background-color: rgba(20, 20, 30, 0.95); " +
                "-fx-background-radius: 16; -fx-padding: 24 32;");

        Text title = new Text("确认退出");
        title.setFont(Font.font("STSong", 22));
        title.setFill(Color.WHITE);

        Text content = new Text("确定要退出游戏吗？\n未保存的进度将丢失！");
        content.setFont(Font.font("STSong", 16));
        content.setFill(Color.LIGHTGRAY);

        HBox buttons = new HBox(12);
        buttons.setAlignment(javafx.geometry.Pos.CENTER);

        String[] btnTexts = {"💾 保存并退出", "返回主菜单", "取消"};
        for (String btnText : btnTexts) {
            Text btn = new Text(btnText);
            btn.setFont(Font.font("STSong", 14));
            btn.setFill(Color.WHITE);
            btn.setStyle("-fx-cursor: hand;");
            btn.setOnMouseEntered(e -> btn.setFill(Color.valueOf("#FFD700")));
            btn.setOnMouseExited(e -> btn.setFill(Color.WHITE));
            btn.setOnMouseClicked(e -> {
                root.getChildren().remove(confirmOverlay);
                if (btnText.equals("💾 保存并退出")) {
                    double px = gameMapView != null ? gameMapView.getPlayerX() : 428;
                    double py = gameMapView != null ? gameMapView.getPlayerY() : 387;
                    String mapId = gameMapView != null ? gameMapView.getCurrentMapId() : currentMapId;
                    int skinIdx = gameMapView != null ? gameMapView.getSkinIndex() : currentSkinIndex;
                    Map<String, Boolean> flags = gameMapView != null ? gameMapView.getGameFlags() : gameFlags;
                    SaveManager.saveGame(px, py, unlocked, skinIdx, mapId, flags);
                    returnToMainMenu();
                } else if (btnText.equals("返回主菜单")) {
                    returnToMainMenu();
                }
            });
            buttons.getChildren().add(btn);
        }

        dialog.getChildren().addAll(title, content, buttons);
        confirmOverlay.getChildren().addAll(dimBg, dialog);
        root.getChildren().add(confirmOverlay);
    }


    public void setCurrentMapId(String mapId) {
        this.currentMapId = mapId;
    }

    public void setGameFlags(Map<String, Boolean> gameFlags) {
        this.gameFlags = gameFlags;
    }

    public void setUnlocked(boolean[] unlocked) {
        System.arraycopy(unlocked, 0, this.unlocked, 0, Math.min(unlocked.length, this.unlocked.length));
    }

    public void syncUnlockedFromFlags() {
        if (gameMapView == null) return;
        unlocked[0] = true;
        unlocked[1] = gameMapView.getFlag("saberUnlocked");
        unlocked[2] = gameMapView.getFlag("archerUnlocked");
        unlocked[3] = gameMapView.getFlag("casterUnlocked");
    }

    public int getCurrentSkinIndex() {
        return currentSkinIndex;
    }

    public void setCurrentSkinIndex(int index) {
        this.currentSkinIndex = index;
    }

    public void setOnSkinChanged(Runnable onSkinChanged) {
        this.onSkinChanged = onSkinChanged;
    }

    public void setOnReturnToMainMenu(Runnable onReturnToMainMenu) {
        this.onReturnToMainMenu = onReturnToMainMenu;
    }

    public void setOnPauseGame(Runnable onPauseGame) {
        this.onPauseGame = onPauseGame;
    }

    public void setOnResumeGame(Runnable onResumeGame) {
        this.onResumeGame = onResumeGame;
    }

    private void returnToMainMenu() {
        menuOpen = false;
        if (menuOverlay != null) {
            root.getChildren().remove(menuOverlay);
        }
        if (onReturnToMainMenu != null) onReturnToMainMenu.run();
    }

    public boolean isMenuOpen() {
        return menuOpen;
    }
}