package com.game.rpg.util.save;

import com.game.rpg.util.json.JsonUtil;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.Map;

public class SaveManager {
    private static final Logger logger = LoggerFactory.getLogger(SaveManager.class);
    private static final String SAVE_DIR = System.getProperty("user.home") + "/.rpg_save";
    private static final String SAVE_FILE = SAVE_DIR + "/save.dat";

    public static class SaveData {
        @JsonProperty("playerX")
        public double playerX;
        @JsonProperty("playerY")
        public double playerY;
        @JsonProperty("unlocked")
        public boolean[] unlocked;
        @JsonProperty("currentSkinIndex")
        public int currentSkinIndex;
        @JsonProperty("mapId")
        public String mapId;
        @JsonProperty("gameFlags")
        public Map<String, Boolean> gameFlags;
        @JsonProperty("timestamp")
        public long timestamp;

        public SaveData() {}

        public SaveData(double playerX, double playerY, boolean[] unlocked,
                        int currentSkinIndex, String mapId, Map<String, Boolean> gameFlags) {
            this.playerX = playerX;
            this.playerY = playerY;
            this.unlocked = unlocked;
            this.currentSkinIndex = currentSkinIndex;
            this.mapId = mapId;
            this.gameFlags = gameFlags;
            this.timestamp = System.currentTimeMillis();
        }
    }

    public static boolean saveGame(double playerX, double playerY, boolean[] unlocked,
                                   int currentSkinIndex, String mapId, Map<String, Boolean> gameFlags) {
        try {
            File dir = new File(SAVE_DIR);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            SaveData data = new SaveData(playerX, playerY, unlocked, currentSkinIndex, mapId, gameFlags);
            JsonUtil.writeToFile(new File(SAVE_FILE), data);
            logger.info("Game saved to {}", SAVE_FILE);
            return true;
        } catch (Exception e) {
            logger.error("Failed to save game", e);
            return false;
        }
    }

    public static SaveData loadGame() {
        try {
            File file = new File(SAVE_FILE);
            if (!file.exists()) {
                logger.warn("Save file not found: {}", SAVE_FILE);
                return null;
            }
            SaveData data = JsonUtil.readFromFile(file, SaveData.class);
            logger.info("Game loaded from {}", SAVE_FILE);
            return data;
        } catch (Exception e) {
            logger.error("Failed to load game", e);
            return null;
        }
    }

    public static boolean hasSave() {
        return new File(SAVE_FILE).exists();
    }
}
