package com.game.rpg.util.map;

import com.game.rpg.util.resource.ResourceLoader;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class SpriteManager {
    private static final Logger logger = LoggerFactory.getLogger(SpriteManager.class);

    private final ResourceLoader resourceLoader;
    private final Map<String, Image> cache = new HashMap<>();

    public SpriteManager(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
    }

    public Image getSprite(String path) {
        return cache.computeIfAbsent(path, p -> {
            try {
                Image raw = resourceLoader.loadImage(p);
                return cropTransparent(raw, p);
            } catch (Exception e) {
                logger.warn("Failed to load sprite: {}", p, e);
                return null;
            }
        });
    }

    public ImageView createSpriteView(String path, double fitWidth, double fitHeight) {
        Image img = getSprite(path);
        ImageView view = new ImageView(img);
        view.setFitWidth(fitWidth);
        view.setFitHeight(fitHeight);
        view.setPreserveRatio(true);
        view.setSmooth(false);
        return view;
    }

    public static Image cropTransparent(Image source, String path) {
        if (source == null) return null;
        int w = (int) source.getWidth();
        int h = (int) source.getHeight();
        PixelReader reader = source.getPixelReader();

        int minX = w, minY = h, maxX = 0, maxY = 0;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                if (reader.getColor(x, y).getOpacity() > 0.01) {
                    if (x < minX) minX = x;
                    if (y < minY) minY = y;
                    if (x > maxX) maxX = x;
                    if (y > maxY) maxY = y;
                }
            }
        }

        if (maxX < minX || maxY < minY) {
            logger.warn("Sprite is fully transparent: {}", path);
            return source;
        }

        int cropW = maxX - minX + 1;
        int cropH = maxY - minY + 1;

        if (minX == 0 && minY == 0 && cropW == w && cropH == h) {
            return source;
        }

        logger.info("Cropped sprite {}: {}x{} -> {}x{} (offset {},{})",
                path, w, h, cropW, cropH, minX, minY);
        return new WritableImage(reader, minX, minY, cropW, cropH);
    }
}