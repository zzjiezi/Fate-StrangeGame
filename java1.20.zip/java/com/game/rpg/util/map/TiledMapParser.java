package com.game.rpg.util.map;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class TiledMapParser {
    private static final Logger logger = LoggerFactory.getLogger(TiledMapParser.class);
    private static final ObjectMapper mapper = new ObjectMapper();

    public static TiledMapData parse(String tmjPath) {
        try (InputStream is = TiledMapParser.class.getResourceAsStream(tmjPath)) {
            if (is == null) {
                logger.error("TMJ file not found: {}", tmjPath);
                return new TiledMapData(0, 0, List.of());
            }
            JsonNode root = mapper.readTree(is);
            int width = root.path("width").asInt();
            int height = root.path("height").asInt();

            List<CollisionRect> colliders = new ArrayList<>();
            JsonNode layers = root.path("layers");
            for (JsonNode layer : layers) {
                String type = layer.path("type").asText();
                if (!"objectgroup".equals(type)) continue;

                boolean visible = layer.path("visible").asBoolean(true);
                if (!visible) continue;

                boolean layerIsCollider = true;
                JsonNode layerProps = layer.path("properties");
                if (layerProps.isArray()) {
                    for (JsonNode prop : layerProps) {
                        if ("isCollider".equals(prop.path("name").asText())) {
                            layerIsCollider = "true".equalsIgnoreCase(prop.path("value").asText());
                            break;
                        }
                    }
                }

                JsonNode objects = layer.path("objects");
                for (JsonNode obj : objects) {
                    boolean objIsCollider = layerIsCollider;
                    JsonNode objProps = obj.path("properties");
                    if (objProps.isArray()) {
                        for (JsonNode prop : objProps) {
                            if ("isCollider".equals(prop.path("name").asText())) {
                                objIsCollider = "true".equalsIgnoreCase(prop.path("value").asText());
                                break;
                            }
                        }
                    }

                    if (objIsCollider) {
                        double ox = obj.path("x").asDouble();
                        double oy = obj.path("y").asDouble();
                        double ow = obj.path("width").asDouble();
                        double oh = obj.path("height").asDouble();
                        colliders.add(new CollisionRect(ox, oy, ow, oh));
                    }
                }
            }

            logger.info("Parsed TMJ: {}x{}, {} colliders from {}", width, height, colliders.size(), tmjPath);
            return new TiledMapData(width, height, colliders);
        } catch (Exception e) {
            logger.error("Failed to parse TMJ: {}", tmjPath, e);
            return new TiledMapData(0, 0, List.of());
        }
    }

    public record CollisionRect(double x, double y, double width, double height) {
        public boolean contains(double px, double py) {
            return px >= x && px <= x + width && py >= y && py <= y + height;
        }

        public boolean intersects(double rx, double ry, double rw, double rh) {
            return rx < x + width && rx + rw > x && ry < y + height && ry + rh > y;
        }
    }

    public record TiledMapData(int mapWidth, int mapHeight, List<CollisionRect> colliders) {
        public boolean isColliding(double px, double py) {
            for (CollisionRect c : colliders) {
                if (c.contains(px, py)) return true;
            }
            return false;
        }

        public boolean isRectColliding(double rx, double ry, double rw, double rh) {
            for (CollisionRect c : colliders) {
                if (c.intersects(rx, ry, rw, rh)) return true;
            }
            return false;
        }
    }
}
