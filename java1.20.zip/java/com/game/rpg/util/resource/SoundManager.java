package com.game.rpg.util.resource;

import javafx.scene.media.AudioClip;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.net.URL;

public class SoundManager {
    private static final Logger logger = LoggerFactory.getLogger(SoundManager.class);

    private static final String IMAGE_PATH = "/images/";
    private static final String SOUND_PATH = "/sounds/";
    public static final String BACKGROUND_PATH = "/backgrounds/";
    public static final String BGM_PATH = "/bgm/";

    public static final String COLLISION_TRIGGER_SFX = SOUND_PATH + "collision_trigger.wav";
    public static final String ENEMY_ALERT_SFX = SOUND_PATH + "enemy_alert.wav";
    public static final String CHARACTER_ATTACK_SFX = SOUND_PATH + "character_attack.wav";
    public static final String ENEMY_ATTACK_SFX = SOUND_PATH + "enemy_attack.wav";
    public static final String BATTLE_BGM = BGM_PATH + "battle_bgm.mp3";
    public static final String BATTLE_BACKGROUND = BACKGROUND_PATH + "battle_background.png";

    private MediaPlayer bgmPlayer;
    private MediaPlayer noblePhantasmPlayer;
    private double bgmVolume = 0.5;
    private double sfxVolume = 0.7;

    public void playBgm(String path) {
        stopBgm();
        try {
            Media media = loadMedia(path);
            if (media == null) return;
            bgmPlayer = new MediaPlayer(media);
            bgmPlayer.setVolume(bgmVolume);
            bgmPlayer.setCycleCount(MediaPlayer.INDEFINITE);
            bgmPlayer.play();
            logger.info("Playing BGM: {}", path);
        } catch (Exception e) {
            logger.error("Failed to play BGM: {}", path, e);
        }
    }

    public void stopBgm() {
        if (bgmPlayer != null) {
            bgmPlayer.stop();
            bgmPlayer = null;
            logger.debug("BGM stopped");
        }
    }

    public void pauseBgm() {
        if (bgmPlayer != null && bgmPlayer.getStatus() == MediaPlayer.Status.PLAYING) {
            bgmPlayer.pause();
            logger.debug("BGM paused");
        }
    }

    public void resumeBgm() {
        if (bgmPlayer != null && bgmPlayer.getStatus() == MediaPlayer.Status.PAUSED) {
            bgmPlayer.play();
            logger.debug("BGM resumed");
        }
    }

    public void playSfx(String path) {
        try {
            AudioClip clip = loadAudioClip(path);
            if (clip == null) return;
            clip.setVolume(sfxVolume);
            clip.play();
            logger.debug("Playing SFX: {}", path);
        } catch (Exception e) {
            logger.error("Failed to play SFX: {}", path, e);
        }
    }

    public void playNoblePhantasmAudio(String path, Runnable onEnd) {
        stopNoblePhantasmAudio();
        try {
            Media media = loadMedia(path);
            if (media == null) {
                if (onEnd != null) onEnd.run();
                return;
            }
            noblePhantasmPlayer = new MediaPlayer(media);
            noblePhantasmPlayer.setVolume(bgmVolume);
            noblePhantasmPlayer.setOnEndOfMedia(() -> {
                logger.debug("Noble Phantasm audio ended");
                if (onEnd != null) onEnd.run();
            });
            noblePhantasmPlayer.play();
            logger.info("Playing Noble Phantasm audio: {}", path);
        } catch (Exception e) {
            logger.error("Failed to play Noble Phantasm audio: {}", path, e);
            if (onEnd != null) onEnd.run();
        }
    }

    public void stopNoblePhantasmAudio() {
        if (noblePhantasmPlayer != null) {
            noblePhantasmPlayer.stop();
            noblePhantasmPlayer = null;
        }
    }

    public void setBgmVolume(double volume) {
        this.bgmVolume = Math.max(0.0, Math.min(1.0, volume));
        if (bgmPlayer != null) bgmPlayer.setVolume(bgmVolume);
    }

    public void setSfxVolume(double volume) {
        this.sfxVolume = Math.max(0.0, Math.min(1.0, volume));
    }

    public boolean isBgmPlaying() {
        return bgmPlayer != null && bgmPlayer.getStatus() == MediaPlayer.Status.PLAYING;
    }

    private Media loadMedia(String path) {
        try {
            File file = new File(path);
            if (file.exists()) {
                return new Media(file.toURI().toString());
            }
            URL resource = getClass().getResource(path);
            if (resource != null) {
                return new Media(resource.toExternalForm());
            }
            logger.warn("Media resource not found: {}", path);
            return null;
        } catch (Exception e) {
            logger.error("Failed to load media: {}", path, e);
            return null;
        }
    }

    private AudioClip loadAudioClip(String path) {
        try {
            File file = new File(path);
            if (file.exists()) {
                return new AudioClip(file.toURI().toString());
            }
            URL resource = getClass().getResource(path);
            if (resource != null) {
                return new AudioClip(resource.toExternalForm());
            }
            logger.warn("AudioClip resource not found: {}", path);
            return null;
        } catch (Exception e) {
            logger.error("Failed to load AudioClip: {}", path, e);
            return null;
        }
    }
}