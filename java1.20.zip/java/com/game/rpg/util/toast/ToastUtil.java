package com.game.rpg.util.toast;

import javafx.animation.FadeTransition;
import javafx.application.Platform;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class ToastUtil {

    public static void showToast(StackPane root, String message, Color color) {
        Platform.runLater(() -> {
            StackPane toastPane = new StackPane();
            toastPane.setMaxWidth(400);

            Rectangle bg = new Rectangle(400, 50);
            bg.setFill(Color.rgb(0, 0, 0, 0.7));
            bg.setArcWidth(16);
            bg.setArcHeight(16);

            Text text = new Text(message);
            text.setFont(Font.font("STSong", 16));
            text.setFill(color);

            toastPane.getChildren().addAll(bg, text);

            double centerX = root.getWidth() / 2 - 200;
            double bottomY = root.getHeight() - 100;
            toastPane.setLayoutX(centerX);
            toastPane.setLayoutY(bottomY);
            toastPane.setMouseTransparent(true);

            root.getChildren().add(toastPane);

            FadeTransition fadeIn = new FadeTransition(Duration.millis(300), toastPane);
            fadeIn.setFromValue(0.0);
            fadeIn.setToValue(1.0);

            FadeTransition fadeOut = new FadeTransition(Duration.millis(500), toastPane);
            fadeOut.setFromValue(1.0);
            fadeOut.setToValue(0.0);
            fadeOut.setDelay(Duration.seconds(1.5));
            fadeOut.setOnFinished(e -> root.getChildren().remove(toastPane));

            javafx.animation.SequentialTransition seq = new javafx.animation.SequentialTransition(
                    fadeIn, new javafx.animation.PauseTransition(Duration.seconds(1.5)), fadeOut
            );
            seq.play();
        });
    }
}