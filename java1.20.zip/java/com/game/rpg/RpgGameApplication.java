package com.game.rpg;

import com.game.rpg.controller.menu.MenuController;
import com.game.rpg.controller.menu.MenuManager;
import com.game.rpg.controller.room.RoomManager;
import com.game.rpg.controller.save.SaveController;
import com.game.rpg.controller.achievement.AchievementController;
import com.game.rpg.controller.story.StoryController;
import com.game.rpg.model.state.GameStateManager;
import com.game.rpg.util.config.GameConfig;
import com.game.rpg.util.config.ResourceConfig;
import com.game.rpg.util.resource.ResourceLoader;
import com.game.rpg.util.resource.SoundManager;
import com.game.rpg.view.scene.DisclaimerView;
import com.game.rpg.view.scene.GameMapView;
import com.game.rpg.view.scene.MainMenuView;
import com.game.rpg.view.scene.PrologueView;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;

public class RpgGameApplication extends Application {
    private static final Logger logger = LoggerFactory.getLogger(RpgGameApplication.class);
    
    private static final String TITLE = "RPG Game - 圣杯战争";
    private static final int WINDOW_WIDTH = 1280;
    private static final int WINDOW_HEIGHT = 720;
    
    private GameConfig gameConfig;
    private ResourceConfig resourceConfig;
    private ResourceLoader resourceLoader;
    private GameStateManager stateManager;
    private SoundManager soundManager;
    
    private MenuController menuController;
    private SaveController saveController;
    private AchievementController achievementController;
    private StoryController storyController;
    
    private GameMapView gameMapView;
    private RoomManager roomManager;
    private MenuManager menuManager;
    
    private StackPane root;
    private MainMenuView mainMenuView;

    @Override
    public void start(Stage primaryStage) {
        try {
            logger.info("Starting RPG Game Application...");
            
            initializeComponents();
            

            Scene scene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);
            
            scene.getStylesheets().add(getClass().getResource("/css/global.css").toExternalForm());
            
            DisclaimerView disclaimerView = new DisclaimerView();
            root.getChildren().add(disclaimerView);
            
            primaryStage.setTitle(TITLE);
            primaryStage.setScene(scene);
            primaryStage.setResizable(false);
            primaryStage.centerOnScreen();
            
            primaryStage.show();

            disclaimerView.start(() -> {
                logger.info("Disclaimer dismissed, showing main menu...");
                root.getChildren().remove(disclaimerView);
                mainMenuView = new MainMenuView(resourceLoader, menuController);
                mainMenuView.setOnLoadGame(() -> loadSaveAndStart());
                root.getChildren().add(mainMenuView);
            });
            
            logger.info("Application started successfully");
        } catch (Exception e) {
            logger.error("Failed to start application", e);
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    private void initializeComponents() {
        gameConfig = new GameConfig();
        resourceConfig = new ResourceConfig();
        resourceLoader = new ResourceLoader(resourceConfig);
        stateManager = new GameStateManager();
        soundManager = new SoundManager();
        
        menuController = new MenuController(stateManager);
        saveController = new SaveController(stateManager);
        achievementController = new AchievementController(stateManager);
        storyController = new StoryController(stateManager, resourceLoader);
        
        gameMapView = new GameMapView(resourceLoader);
        root = new StackPane();
        roomManager = new RoomManager(gameMapView, resourceLoader, stateManager, soundManager, root);
        roomManager.setOnGameComplete(() -> {
            gameMapView.stopGameLoop();
            root.getChildren().remove(gameMapView);
            mainMenuView = new MainMenuView(resourceLoader, menuController);
            mainMenuView.setOnLoadGame(() -> loadSaveAndStart());
            root.getChildren().add(mainMenuView);
        });
        
        menuController.setOnNewGame(v -> {
            logger.info("Starting new game...");
            startPrologue();
        });
        
        logger.info("Components initialized");
    }

    private void startPrologue() {
        gameMapView.resetState();

        PrologueView prologueView = new PrologueView(stateManager, soundManager);
        root.getChildren().add(prologueView);
        prologueView.toFront();

        prologueView.start(() -> {
            logger.info("Prologue complete, starting Act 1...");
            root.getChildren().remove(prologueView);
            root.getChildren().add(gameMapView);
            gameMapView.toFront();
            roomManager.startRoom(1);
            setupMenuButton();
        });
    }

    private void setupMenuButton() {
        Stage primaryStage = (Stage) root.getScene().getWindow();
        javafx.scene.image.Image[] charImages = new javafx.scene.image.Image[4];
        String[] paths = {
                "/images/characters/player/player 1正面 .png",
                "/images/characters/Saber/Saber 1正面 .png",
                "/images/characters/archer/archer1.png",
                "/images/characters/Caster/Bill正面3.png"
        };
        for (int i = 0; i < paths.length; i++) {
            try {
                charImages[i] = gameMapView.getSpriteManager().getSprite(paths[i]);
            } catch (Exception e) {
                charImages[i] = null;
            }
        }

        menuManager = new MenuManager(primaryStage, root, charImages, gameMapView);
        menuManager.setOnReturnToMainMenu(() -> {
            gameMapView.stopGameLoop();
            root.getChildren().remove(gameMapView);
            mainMenuView = new MainMenuView(resourceLoader, menuController);
            mainMenuView.setOnLoadGame(() -> loadSaveAndStart());
            root.getChildren().add(mainMenuView);
        });
        menuManager.setOnPauseGame(() -> gameMapView.lockInput());
        menuManager.setOnResumeGame(() -> gameMapView.unlockInput());
        menuManager.setOnSkinChanged(() -> gameMapView.setSkinIndex(menuManager.getCurrentSkinIndex()));
        

        javafx.scene.layout.Pane menuBtn = menuManager.createMenuButton();
        javafx.scene.layout.Pane menuLayer = gameMapView.getMenuButtonLayer();
        if (menuLayer != null) {
            menuLayer.getChildren().add(menuBtn);
        }
    }

    private void loadSaveAndStart() {
        com.game.rpg.util.save.SaveManager.SaveData data = com.game.rpg.util.save.SaveManager.loadGame();
        if (data == null) {
            logger.warn("No save data found");
            return;
        }
        root.getChildren().remove(mainMenuView);
        root.getChildren().add(gameMapView);
        gameMapView.toFront();
        gameMapView.setPlayerPosition(data.playerX, data.playerY);
        if (data.gameFlags != null) {
            for (Map.Entry<String, Boolean> entry : data.gameFlags.entrySet()) {
                gameMapView.setFlag(entry.getKey(), entry.getValue());
            }
        }
        int skinIdx = data.currentSkinIndex;
        if (skinIdx > 0 && gameMapView.getFlag("skinIndexChanged")) {
            skinIdx += 1;
        }
        gameMapView.setSkinIndex(skinIdx);
        int room = 1;
        try {
            room = Integer.parseInt(data.mapId);
        } catch (Exception ignored) {}
        roomManager.startRoom(room);
        gameMapView.unlockInput();
        if (menuManager == null) {
            setupMenuButton();
        }
        menuManager.setCurrentSkinIndex(data.currentSkinIndex);
        menuManager.syncUnlockedFromFlags();

    }

    @Override
    public void stop() {
        logger.info("Application shutting down...");
        if (soundManager != null) {
            soundManager.stopBgm();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
