package com.game.rpg.model.enums;

public enum CommandSpellEffect {
    REVIVE_SERVANT("复活从者"),
    DAMAGE_BOOST("伤害提升50%"),
    HEAL_HP("回复能量50MP");
    
    private final String displayName;
    
    CommandSpellEffect(String displayName) {
        this.displayName = displayName;
    }
    
    public String getDisplayName() {
        return displayName;
    }
}