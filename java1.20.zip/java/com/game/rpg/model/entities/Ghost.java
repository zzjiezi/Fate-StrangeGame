package com.game.rpg.model.entities;

import com.game.rpg.core.battle.HitSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

public class Ghost extends Enemy {
    private static final Logger logger = LoggerFactory.getLogger(Ghost.class);

    private static final int MAX_HP = 250;
    private static final int MAX_MP = 30;
    private static final int INITIAL_MP = 15;
    private static final int ATTACK_POWER = 60;
    private static final double HIT_RATE = 0.85;
    private static final double DODGE_RATE = 0.45;

    private final HitSystem hitSystem;

    public Ghost() {
        super("ghost", "幽灵鬼", MAX_HP, MAX_MP, INITIAL_MP, ATTACK_POWER,
                HIT_RATE, DODGE_RATE, false, 0.0);
        this.hitSystem = new HitSystem();
    }

    public AttackResult normalAttack(Character target, Consumer<String> battleLog) {
        HitSystem.HitResult hitResult = hitSystem.resolveHit(this, target);

        if (hitResult.isMissed()) {
            String msg = String.format("「幽灵之触」被 %s 闪避了！", target.getName());
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
            return AttackResult.missed("幽灵之触", 0);
        }

        int damage = getAttackPower();
        target.takeDamage(damage);

        String msg = String.format("「幽灵之触」命中！对 %s 造成 %d 点伤害！", target.getName(), damage);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("幽灵之触", damage);
    }
}
