package com.game.rpg.model.entities;

import com.game.rpg.core.battle.HitSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

public class Mimic extends Enemy {
    private static final Logger logger = LoggerFactory.getLogger(Mimic.class);

    private static final int MAX_HP = 280;
    private static final int MAX_MP = 40;
    private static final int INITIAL_MP = 20;
    private static final int ATTACK_POWER = 70;
    private static final double HIT_RATE = 0.90;
    private static final double DODGE_RATE = 0.0;

    private final HitSystem hitSystem;
    private boolean firstStrikeUsed;

    public Mimic() {
        super("mimic", "宝箱怪", MAX_HP, MAX_MP, INITIAL_MP, ATTACK_POWER,
                HIT_RATE, DODGE_RATE, false, 0.0);
        this.hitSystem = new HitSystem();
        this.firstStrikeUsed = false;
    }

    public boolean isFirstStrike() {
        return !firstStrikeUsed;
    }

    public void consumeFirstStrike() {
        firstStrikeUsed = true;
    }

    public AttackResult normalAttack(Character target, Consumer<String> battleLog) {
        HitSystem.HitResult hitResult = hitSystem.resolveHit(this, target);

        if (hitResult.isMissed()) {
            String msg = String.format("「咬噬」被 %s 闪避了！", target.getName());
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
            return AttackResult.missed("咬噬", 0);
        }

        int damage = getAttackPower();
        target.takeDamage(damage);

        String msg = String.format("「咬噬」命中！对 %s 造成 %d 点伤害！", target.getName(), damage);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("咬噬", damage);
    }
}
