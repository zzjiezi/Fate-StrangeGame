package com.game.rpg.model.entities;

import com.game.rpg.core.battle.HitSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

public class RoseWitch extends Enemy {
    private static final Logger logger = LoggerFactory.getLogger(RoseWitch.class);

    private static final int MAX_HP = 300;
    private static final int MAX_MP = 50;
    private static final int INITIAL_MP = 25;
    private static final int ATTACK_POWER = 40;
    private static final double HIT_RATE = 0.85;
    private static final double DODGE_RATE = 0.15;
    private static final double THORN_CHANCE = 0.30;
    private static final double THORN_HIT_RATE_REDUCTION = 0.15;
    private static final int THORN_DURATION = 1;

    private final HitSystem hitSystem;

    public RoseWitch() {
        super("rose_witch", "蔷薇魔女", MAX_HP, MAX_MP, INITIAL_MP, ATTACK_POWER,
                HIT_RATE, DODGE_RATE, false, 0.0);
        this.hitSystem = new HitSystem();
    }

    public AttackResult normalAttack(Character target, Consumer<String> battleLog) {
        HitSystem.HitResult hitResult = hitSystem.resolveHit(this, target);

        if (hitResult.isMissed()) {
            String msg = String.format("「荆棘鞭挞」被 %s 闪避了！", target.getName());
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
            return AttackResult.missed("荆棘鞭挞", 0);
        }

        int damage = getAttackPower();
        target.takeDamage(damage);

        String msg = String.format("「荆棘鞭挞」命中！对 %s 造成 %d 点伤害！", target.getName(), damage);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("荆棘鞭挞", damage);
    }

    public void checkThornPassive(Character attacker, Consumer<String> battleLog) {
        if (random.nextDouble() < THORN_CHANCE) {
            attacker.applyHitRateReduction(THORN_HIT_RATE_REDUCTION, THORN_DURATION);
            String msg = String.format("蔷薇花园触发！荆棘缠住 %s，下回合命中率降低15%%！", attacker.getName());
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
        }
    }
}