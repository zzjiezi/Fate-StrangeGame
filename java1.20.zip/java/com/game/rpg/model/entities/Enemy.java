package com.game.rpg.model.entities;

import com.game.rpg.util.ValidationUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Enemy {
    private final String id;
    private final String name;
    private int hp;
    private int maxHp;
    private int mp;
    private int maxMp;
    private int attackPower;
    private final List<Skill> skills;
    protected final Random random;
    private final double hitRate;
    private final double dodgeRate;
    private final boolean alwaysHit;
    private final double phaseShiftChance;
    private double damageReduction;

    public Enemy(String id, String name, int maxHp, int attackPower) {
        this(id, name, maxHp, 0, attackPower, 0.85, 0.05, false, 0.0);
    }

    public Enemy(String id, String name, int maxHp, int maxMp, int attackPower,
                 double hitRate, double dodgeRate, boolean alwaysHit, double phaseShiftChance) {
        this(id, name, maxHp, maxMp, maxMp, attackPower, hitRate, dodgeRate, alwaysHit, phaseShiftChance);
    }

    public Enemy(String id, String name, int maxHp, int maxMp, int initialMp, int attackPower,
                 double hitRate, double dodgeRate, boolean alwaysHit, double phaseShiftChance) {
        ValidationUtils.requireNonNull(id, "Enemy ID cannot be null");
        ValidationUtils.requireNonNull(name, "Enemy name cannot be null");
        ValidationUtils.requirePositive(maxHp, "Max HP must be positive");
        ValidationUtils.requireNonNegative(attackPower, "Attack power must be non-negative");
        ValidationUtils.requireInRange(hitRate, 0.0, 1.0, "Hit rate must be between 0.0 and 1.0");
        ValidationUtils.requireInRange(dodgeRate, 0.0, 1.0, "Dodge rate must be between 0.0 and 1.0");
        ValidationUtils.requireInRange(phaseShiftChance, 0.0, 1.0, "Phase shift chance must be between 0.0 and 1.0");

        this.id = id;
        this.name = name;
        this.maxHp = maxHp;
        this.hp = maxHp;
        this.maxMp = maxMp;
        this.mp = initialMp;
        this.attackPower = attackPower;
        this.skills = new ArrayList<>();
        this.random = new Random();
        this.hitRate = hitRate;
        this.dodgeRate = dodgeRate;
        this.alwaysHit = alwaysHit;
        this.phaseShiftChance = phaseShiftChance;
        this.damageReduction = 0.0;
    }

    public boolean isAlive() {
        return hp > 0;
    }

    public void takeDamage(int damage) {
        takeDamage(damage, false);
    }

    public void takeDamage(int damage, boolean ignoreReduction) {
        ValidationUtils.requireNonNegative(damage, "Damage must be non-negative");
        int actualDamage = damage;
        if (!ignoreReduction && damageReduction > 0) {
            actualDamage = (int) Math.round(damage * (1.0 - damageReduction));
        }
        hp = Math.max(0, hp - actualDamage);
    }

    public void heal(int amount) {
        ValidationUtils.requireNonNegative(amount, "Heal amount must be non-negative");
        hp = Math.min(maxHp, hp + amount);
    }

    public void consumeMP(int amount) {
        ValidationUtils.requireNonNegative(amount, "MP amount must be non-negative");
        mp = Math.max(0, mp - amount);
    }

    public void restoreMP(int amount) {
        ValidationUtils.requireNonNegative(amount, "MP amount must be non-negative");
        mp = Math.min(maxMp, mp + amount);
    }

    public boolean canCastSkill(int mpCost) {
        return mp >= mpCost;
    }

    public void onTurnStart() {
    }

    public void onTurnEnd() {
    }

    public Skill decideAction() {
        if (skills.isEmpty()) {
            return null;
        }

        if (random.nextDouble() < 0.7) {
            return null;
        }

        return skills.get(random.nextInt(skills.size()));
    }

    public void addSkill(Skill skill) {
        ValidationUtils.requireNonNull(skill, "Skill cannot be null");
        skills.add(skill);
    }

    public List<Skill> getSkills() {
        return Collections.unmodifiableList(skills);
    }

    public String getId() {
        return id;
    }

    public String getSpritePath() {
        return switch (id) {
            case "ghost" -> "/images/enemies/monster1.png";
            case "mimic" -> "/images/enemies/monster2.png";
            case "bat" -> "/images/enemies/monster3.png";
            case "mummy" -> "/images/enemies/monster4.png";
            case "cyclone" -> "/images/enemies/monster5.png";
            case "saber_alter" -> "/images/enemies/Saber Alter1.png";
            case "archer_alter" -> "/images/enemies/WitchSavior(2).png";
            case "caster_alter" -> "/images/characters/Caster/battlecg.png";
            case "rose_witch" -> "/images/enemies/RoseWitch.png";
            case "rose_monster" -> "/images/enemies/RoseMonster.png";
            default -> "/images/enemies/monster1.png";
        };
    }

    public String getName() {
        return name;
    }

    public int getHp() {
        return hp;
    }

    public int getMaxHp() {
        return maxHp;
    }

    public int getMp() {
        return mp;
    }

    public int getMaxMp() {
        return maxMp;
    }

    public int getAttackPower() {
        return attackPower;
    }

    public double getHitRate() {
        return hitRate;
    }

    public double getDodgeRate() {
        return dodgeRate;
    }

    public double getEffectiveDodgeRate() {
        return dodgeRate;
    }

    public boolean isAlwaysHit() {
        return alwaysHit;
    }

    public double getPhaseShiftChance() {
        return phaseShiftChance;
    }

    public double getDamageReduction() {
        return damageReduction;
    }

    public void setDamageReduction(double reduction) {
        this.damageReduction = Math.max(0.0, Math.min(1.0, reduction));
    }

    @Override
    public String toString() {
        return String.format("Enemy{id='%s', name='%s', hp=%d/%d, mp=%d/%d, hitRate=%.0f%%, dodgeRate=%.0f%%, dmgRed=%.0f%%}",
                id, name, hp, maxHp, mp, maxMp, hitRate * 100, dodgeRate * 100, damageReduction * 100);
    }
}
