package com.game.rpg.model.entities;

import com.game.rpg.core.battle.HitSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

public class RoseMonster extends Enemy {
    private static final Logger logger = LoggerFactory.getLogger(RoseMonster.class);

    private static final int MAX_HP = 250;
    private static final int MAX_MP = 30;
    private static final int INITIAL_MP = 15;
    private static final int ATTACK_POWER = 35;
    private static final double HIT_RATE = 0.90;
    private static final double DODGE_RATE = 0.10;
    private static final int BLEED_DAMAGE = 3;
    private static final int BLEED_DURATION = 3;

    private final HitSystem hitSystem;

    public RoseMonster() {
        super("rose_monster", "蔷薇使魔", MAX_HP, MAX_MP, INITIAL_MP, ATTACK_POWER,
                HIT_RATE, DODGE_RATE, false, 0.0);
        this.hitSystem = new HitSystem();
    }

    public AttackResult normalAttack(Character target, Consumer<String> battleLog) {
        HitSystem.HitResult hitResult = hitSystem.resolveHit(this, target);

        if (hitResult.isMissed()) {
            String msg = String.format("「噬咬撕扯」被 %s 闪避了！", target.getName());
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
            return AttackResult.missed("噬咬撕扯", 0);
        }

        int damage = getAttackPower();
        target.takeDamage(damage);

        target.applyBleed(BLEED_DAMAGE, BLEED_DURATION);

        String msg = String.format("「噬咬撕扯」命中！对 %s 造成 %d 点伤害！撕裂伤口，每回合额外掉%d血，持续%d回合！",
                target.getName(), damage, BLEED_DAMAGE, BLEED_DURATION);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("噬咬撕扯", damage);
    }
}