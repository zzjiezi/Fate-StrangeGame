package com.game.rpg.model.entity;

import com.game.rpg.model.enums.CommandSpellBranch;
import com.game.rpg.model.enums.CommandSpellEffect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

public class Archer extends Character {
    private static final Logger logger = LoggerFactory.getLogger(Archer.class);

    private static final int MAX_HP = 350;
    private static final int MAX_MP = 130;
    private static final int INITIAL_MP = 65;
    private static final int ATTACK_POWER = 90;
    private static final double HIT_RATE = 0.85;
    private static final double DODGE_RATE = 0.10;
    private static final int MP_REGEN_PER_TURN = 8;
    private static final int MP_REGEN_UNDAMAGED_BONUS = 5;

    private static final int NORMAL_ATTACK_DAMAGE = 90;
    private static final int NORMAL_ATTACK_MP_RESTORE = 10;
    private static final int NOBLE_PHANTASM_MP_COST = 60;
    private static final int NOBLE_PHANTASM_FIXED_DAMAGE = 250;
    private static final int NOBLE_PHANTASM_HEAL_AMOUNT = 50;

    private static final int COMMAND_SPELL_MP_RESTORE = 50;

    private final HitSystem hitSystem;

    public Archer() {
        super("archer", "鹿目圆", MAX_HP, MAX_MP, INITIAL_MP, ATTACK_POWER,
                CommandSpellBranch.ARCHER, HIT_RATE, DODGE_RATE,
                false, 0.0, 0.0, MP_REGEN_PER_TURN);
        this.hitSystem = new HitSystem();
    }

    @Override
    public void onTurnEnd() {
        super.onTurnEnd();
        if (!wasDamagedThisTurn()) {
            restoreMP(MP_REGEN_UNDAMAGED_BONUS);
            String msg = String.format("希望之光：本回合未受伤，额外回复 %d MP", MP_REGEN_UNDAMAGED_BONUS);
            logger.debug(msg);
        }
    }

    public AttackResult normalAttack(Enemy target, Consumer<String> battleLog) {
        HitSystem.HitResult hitResult = hitSystem.resolveHit(this, target);

        if (hitResult.isMissed()) {
            String msg = String.format("「希望之矢」被 %s 闪避了！", target.getName());
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
            return AttackResult.missed("希望之矢", 0);
        }

        int damage = NORMAL_ATTACK_DAMAGE;
        if (isDamageBoostActive()) {
            damage = (int) Math.round(damage * 1.5);
            setDamageBoostActive(false);
        }
        target.takeDamage(damage);

        restoreMP(NORMAL_ATTACK_MP_RESTORE);

        String msg = String.format("「希望之矢」命中！粉红光箭对 %s 造成 %d 点伤害！回复 %d MP",
                target.getName(), damage, NORMAL_ATTACK_MP_RESTORE);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("希望之矢", damage);
    }

    public AttackResult noblePhantasm(Enemy target, Consumer<String> battleLog) {
        if (isSkillSealed()) {
            String msg = "大招被封印！无法释放「圆环之理」！";
            logger.warn(msg);
            if (battleLog != null) battleLog.accept(msg);
            return AttackResult.missed("圆环之理", 0);
        }
        if (!canCastNoblePhantasm()) {
            String msg = "蓝量不足，无法释放「圆环之理」！";
            logger.warn(msg);
            if (battleLog != null) battleLog.accept(msg);
            return AttackResult.missed("圆环之理", 0);
        }

        consumeMP(NOBLE_PHANTASM_MP_COST);

        int damage = NOBLE_PHANTASM_FIXED_DAMAGE;
        if (isDamageBoostActive()) {
            damage = (int) Math.round(damage * 1.5);
            setDamageBoostActive(false);
        }
        target.takeDamage(damage, true);

        int oldHp = getHp();
        heal(NOBLE_PHANTASM_HEAL_AMOUNT);
        int actualHeal = getHp() - oldHp;

        String msg = String.format("「圆环之理」命中！宇宙奇迹对 %s 造成 %d 点固定伤害！（无视防御/减伤/闪避）回复 %d 点HP！",
                target.getName(), damage, actualHeal);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("圆环之理", damage);
    }

    public boolean useCommandSpell(CommandSpellEffect effect, Character servant,
                                   Consumer<String> battleLog) {
        if (!canUseCommandSpell(effect)) {
            String msg = String.format("令咒「%s」无法使用！已使用或令咒次数不足。", effect.getDisplayName());
            logger.warn(msg);
            if (battleLog != null) battleLog.accept(msg);
            return false;
        }

        useCommandSpell(effect);

        switch (effect) {
            case REVIVE_SERVANT:
                return reviveServant(servant, battleLog);
            case DAMAGE_BOOST:
                return activateDamageBoost(battleLog);
            case HEAL_HP:
                return restoreMPByCommandSpell(battleLog);
            default:
                return false;
        }
    }

    private boolean reviveServant(Character servant, Consumer<String> battleLog) {
        if (servant == null || servant.isAlive()) {
            String msg = "没有需要复活的从者！";
            logger.warn(msg);
            if (battleLog != null) battleLog.accept(msg);
            return false;
        }
        servant.heal(servant.getMaxHp());
        String msg = String.format("令咒「复活从者」！%s 以满血复活！（%d HP）", servant.getName(), servant.getHp());
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return true;
    }

    private boolean activateDamageBoost(Consumer<String> battleLog) {
        setDamageBoostActive(true);
        String msg = "令咒「伤害提升50%」！下一次攻击伤害提升！";
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return true;
    }

    private boolean restoreMPByCommandSpell(Consumer<String> battleLog) {
        int oldMp = getMp();
        restoreMP(COMMAND_SPELL_MP_RESTORE);
        int actualRestore = getMp() - oldMp;
        String msg = String.format("令咒「回复能量」！回复 %d 点MP！", actualRestore);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return true;
    }

    public boolean canCastNoblePhantasm() {
        return getMp() >= NOBLE_PHANTASM_MP_COST;
    }

    public int getNoblePhantasmMpCost() {
        return NOBLE_PHANTASM_MP_COST;
    }

    public int getNoblePhantasmFixedDamage() {
        return NOBLE_PHANTASM_FIXED_DAMAGE;
    }

    public int getNoblePhantasmHealAmount() {
        return NOBLE_PHANTASM_HEAL_AMOUNT;
    }
}
