package com.game.rpg.model.entity;

public class AttackResult {
    private final String skillName;
    private final int damage;
    private final boolean hit;

    private AttackResult(String skillName, int damage, boolean hit) {
        this.skillName = skillName;
        this.damage = damage;
        this.hit = hit;
    }

    public static AttackResult hit(String skillName, int damage) {
        return new AttackResult(skillName, damage, true);
    }

    public static AttackResult missed(String skillName, int damage) {
        return new AttackResult(skillName, damage, false);
    }

    public String getSkillName() {
        return skillName;
    }

    public int getDamage() {
        return damage;
    }

    public boolean isHit() {
        return hit;
    }

    public boolean isMissed() {
        return !hit;
    }
}