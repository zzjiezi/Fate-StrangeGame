package com.game.rpg.model.entity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

public class CasterAlter extends Enemy {
    private static final Logger logger = LoggerFactory.getLogger(CasterAlter.class);

    private static final int MAX_HP = 500;
    private static final int MAX_MP = 160;
    private static final int INITIAL_MP = 60;
    private static final int ATTACK_POWER = 100;
    private static final double HIT_RATE = 0.80;
    private static final double DODGE_RATE = 0.05;
    private static final double DAMAGE_REDUCTION_HIGH_HP = 0.10;
    private static final double DAMAGE_REDUCTION_LOW_HP = 0.20;
    private static final double HP_THRESHOLD = 0.50;
    private static final double BURN_HP_RATIO = 0.08;
    private static final int BURN_MP_GAIN = 15;

    private static final int NORMAL_ATTACK_DAMAGE = 80;
    private static final double DODGE_RATE_DEBUFF = 0.20;
    private static final int DODGE_DEBUFF_DURATION = 1;

    private static final int NOBLE_PHANTASM_MP_COST = 45;
    private static final int NOBLE_PHANTASM_TOTAL_DAMAGE = 180;
    private static final int NOBLE_PHANTASM_HITS = 3;
    private static final int NOBLE_PHANTASM_DAMAGE_PER_HIT = NOBLE_PHANTASM_TOTAL_DAMAGE / NOBLE_PHANTASM_HITS;
    private static final int BUFF_SUPPRESSION_DURATION = 2;

    private static final double HIDDEN_SKILL_HP_THRESHOLD = 0.30;
    private static final int HIDDEN_SKILL_DAMAGE = 120;

    private final HitSystem hitSystem;
    private boolean hiddenSkillTriggered;

    public CasterAlter() {
        super("caster_alter", "黑化比尔·赛弗", MAX_HP, MAX_MP, INITIAL_MP, ATTACK_POWER,
                HIT_RATE, DODGE_RATE, false, 0.0);
        setDamageReduction(DAMAGE_REDUCTION_HIGH_HP);
        this.hitSystem = new HitSystem();
        this.hiddenSkillTriggered = false;
    }

    public boolean isHiddenSkillTriggered() {
        return hiddenSkillTriggered;
    }

    @Override
    public void onTurnStart() {
        if (getHp() > (int) Math.round(getMaxHp() * HP_THRESHOLD)) {
            int burnHp = (int) Math.round(getHp() * BURN_HP_RATIO);
            takeDamage(burnHp, true);
            restoreMP(BURN_MP_GAIN);
            logger.debug("混沌契约：消耗 {} HP，回复 {} MP", burnHp, BURN_MP_GAIN);
        }

        if (getHp() <= (int) Math.round(getMaxHp() * HP_THRESHOLD)) {
            setDamageReduction(DAMAGE_REDUCTION_LOW_HP);
        } else {
            setDamageReduction(DAMAGE_REDUCTION_HIGH_HP);
        }
    }

    @Override
    public void onTurnEnd() {
        checkHiddenSkill(null);
    }

    public AttackResult normalAttack(Character target, Consumer<String> battleLog) {
        HitSystem.HitResult hitResult = hitSystem.resolveHit(this, target);

        if (hitResult.isMissed()) {
            String msg = String.format("「崩坏之眼」被 %s 闪避了！", target.getName());
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
            return AttackResult.missed("崩坏之眼", 0);
        }

        int damage = NORMAL_ATTACK_DAMAGE;
        target.takeDamage(damage);
        target.applyDodgeRateReduction(DODGE_RATE_DEBUFF, DODGE_DEBUFF_DURATION);

        String msg = String.format("「崩坏之眼」命中！对 %s 造成 %d 点伤害！目标下回合闪避率降低20%%！",
                target.getName(), damage);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("崩坏之眼", damage);
    }

    public MultiHitResult noblePhantasm(Character target, Consumer<String> battleLog) {
        if (!canCastSkill(NOBLE_PHANTASM_MP_COST)) {
            String msg = "蓝量不足，无法释放「维度吞噬」！";
            logger.warn(msg);
            if (battleLog != null) battleLog.accept(msg);
            return new MultiHitResult("维度吞噬", 0, 0, 0);
        }

        consumeMP(NOBLE_PHANTASM_MP_COST);

        if (battleLog != null) battleLog.accept("黑化比尔·赛弗发动「维度吞噬」！撕裂现实空间...");

        int totalDamage = 0;
        int hitCount = 0;
        boolean allHit = true;

        for (int i = 1; i <= NOBLE_PHANTASM_HITS; i++) {
            if (!target.isAlive()) {
                String msg = String.format("第 %d 段攻击取消——目标已死亡！", i);
                logger.info(msg);
                if (battleLog != null) battleLog.accept(msg);
                break;
            }

            HitSystem.HitResult hitResult = hitSystem.resolveHit(this, target);

            if (hitResult.isMissed()) {
                allHit = false;
                String msg = String.format("第 %d 段攻击被闪避！", i);
                logger.info(msg);
                if (battleLog != null) battleLog.accept(msg);
                continue;
            }

            int damage = NOBLE_PHANTASM_DAMAGE_PER_HIT;
            target.takeDamage(damage, true);
            totalDamage += damage;
            hitCount++;

            String msg = String.format("第 %d 段攻击命中！对 %s 造成 %d 点伤害！", i, target.getName(), damage);
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
        }

        if (allHit && hitCount == NOBLE_PHANTASM_HITS) {
            target.applyBuffSuppression(BUFF_SUPPRESSION_DURATION);
            String msg = String.format("三次全部命中！%s 所有增益效果被清除（%d回合后恢复）！", target.getName(), BUFF_SUPPRESSION_DURATION);
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
        }

        String summary = String.format("「维度吞噬」结束！共命中 %d 次，总计造成 %d 点伤害！", hitCount, totalDamage);
        logger.info(summary);
        if (battleLog != null) battleLog.accept(summary);

        return new MultiHitResult("维度吞噬", totalDamage, hitCount, NOBLE_PHANTASM_HITS - hitCount);
    }

    public void checkHiddenSkill(Consumer<String> battleLog) {
        if (hiddenSkillTriggered || !isAlive()) {
            return;
        }
        if (getHp() <= (int) Math.round(getMaxHp() * HIDDEN_SKILL_HP_THRESHOLD)) {
            hiddenSkillTriggered = true;
            logger.info("虚无归零触发条件达成！HP降至30%以下！");
        }
    }

    public AttackResult executeHiddenSkill(Character target, Consumer<String> battleLog) {
        if (!hiddenSkillTriggered) {
            return null;
        }

        target.takeDamage(HIDDEN_SKILL_DAMAGE, true);

        String msg = String.format("「虚无归零」！对 %s 造成 %d 点真实伤害！",
                target.getName(), HIDDEN_SKILL_DAMAGE);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("虚无归零", HIDDEN_SKILL_DAMAGE);
    }

    public static class MultiHitResult {
        private final String skillName;
        private final int totalDamage;
        private final int hitCount;
        private final int missCount;

        public MultiHitResult(String skillName, int totalDamage, int hitCount, int missCount) {
            this.skillName = skillName;
            this.totalDamage = totalDamage;
            this.hitCount = hitCount;
            this.missCount = missCount;
        }

        public String getSkillName() { return skillName; }
        public int getTotalDamage() { return totalDamage; }
        public int getHitCount() { return hitCount; }
        public int getMissCount() { return missCount; }
        public boolean hasAnyHit() { return hitCount > 0; }
    }
}