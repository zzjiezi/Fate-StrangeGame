package com.game.rpg.model.entity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

public class Cyclone extends Enemy {
    private static final Logger logger = LoggerFactory.getLogger(Cyclone.class);

    private static final int MAX_HP = 170;
    private static final int MAX_MP = 50;
    private static final int INITIAL_MP = 25;
    private static final int ATTACK_POWER = 50;
    private static final double HIT_RATE = 0.90;
    private static final double DODGE_RATE = 0.20;
    private static final double REFLECT_CHANCE = 0.30;
    private static final double REFLECT_RATIO = 0.20;

    private final HitSystem hitSystem;

    public Cyclone() {
        super("cyclone", "飓风怪", MAX_HP, MAX_MP, INITIAL_MP, ATTACK_POWER,
                HIT_RATE, DODGE_RATE, false, 0.0);
        this.hitSystem = new HitSystem();
    }

    public AttackResult normalAttack(Character target, Consumer<String> battleLog) {
        HitSystem.HitResult hitResult = hitSystem.resolveHit(this, target);

        if (hitResult.isMissed()) {
            String msg = String.format("「风刃」被 %s 闪避了！", target.getName());
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
            return AttackResult.missed("风刃", 0);
        }

        int damage = getAttackPower();
        target.takeDamage(damage);

        String msg = String.format("「风刃」命中！对 %s 造成 %d 点伤害！", target.getName(), damage);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("风刃", damage);
    }

    public int checkReflect(int incomingDamage, Character attacker, Consumer<String> battleLog) {
        if (random.nextDouble() < REFLECT_CHANCE) {
            int reflectDamage = (int) Math.round(incomingDamage * REFLECT_RATIO);
            attacker.takeDamage(reflectDamage);
            String msg = String.format("风之障壁触发！反弹 %d 点伤害给 %s！", reflectDamage, attacker.getName());
            logger.info(msg);
            if (battleLog != null) battleLog.accept(msg);
            return reflectDamage;
        }
        return 0;
    }
}
