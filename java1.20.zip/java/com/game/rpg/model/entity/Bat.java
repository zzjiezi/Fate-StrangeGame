package com.game.rpg.model.entity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

public class Bat extends Enemy {
    private static final Logger logger = LoggerFactory.getLogger(Bat.class);

    private static final int MAX_HP = 160;
    private static final int MAX_MP = 35;
    private static final int INITIAL_MP = 18;
    private static final int ATTACK_POWER = 45;
    private static final double HIT_RATE = 1.0;
    private static final double DODGE_RATE = 0.15;

    public Bat() {
        super("bat", "蝙蝠怪", MAX_HP, MAX_MP, INITIAL_MP, ATTACK_POWER,
                HIT_RATE, DODGE_RATE, true, 0.0);
    }

    public AttackResult normalAttack(Character target, Consumer<String> battleLog) {
        int damage = getAttackPower();
        target.takeDamage(damage);

        String msg = String.format("「爪击」强制命中！对 %s 造成 %d 点伤害！", target.getName(), damage);
        logger.info(msg);
        if (battleLog != null) battleLog.accept(msg);
        return AttackResult.hit("爪击", damage);
    }
}
