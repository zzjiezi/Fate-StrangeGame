package com.game.rpg.model.entity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Random;

public class HitSystem {
    private static final Logger logger = LoggerFactory.getLogger(HitSystem.class);

    private final Random random;

    public HitSystem() {
        this.random = new Random();
    }

    public HitResult resolveHit(Character attacker, Enemy target) {
        if (attacker.isAlwaysHit()) {
            logger.debug("{} has always-hit passive, skipping hit check", attacker.getName());
            return checkPhaseShift(target);
        }

        double actualHitRate = attacker.getHitRate() - target.getEffectiveDodgeRate();
        actualHitRate = Math.max(0.0, actualHitRate);

        boolean hit = random.nextDouble() < actualHitRate;
        logger.debug("Hit check: {} hitRate={}% - {} dodgeRate={}% = {}%, result={}",
                attacker.getName(), attacker.getHitRate() * 100, target.getName(),
                target.getEffectiveDodgeRate() * 100, actualHitRate * 100, hit ? "HIT" : "MISS");

        if (!hit) {
            return HitResult.missed();
        }

        return checkPhaseShift(target);
    }

    public HitResult resolveHit(Enemy attacker, Character target) {
        if (attacker.isAlwaysHit()) {
            logger.debug("{} has always-hit passive, skipping hit check", attacker.getName());
            return HitResult.hit();
        }

        double actualHitRate = attacker.getHitRate() - target.getEffectiveDodgeRate();
        actualHitRate = Math.max(0.0, actualHitRate);

        boolean hit = random.nextDouble() < actualHitRate;
        logger.debug("Hit check: {} hitRate={}% - {} dodgeRate={}% = {}%, result={}",
                attacker.getName(), attacker.getHitRate() * 100, target.getName(),
                target.getEffectiveDodgeRate() * 100, actualHitRate * 100, hit ? "HIT" : "MISS");

        if (!hit) {
            return HitResult.missed();
        }

        return checkPhaseShift(target);
    }

    private HitResult checkPhaseShift(Enemy target) {
        if (target.getPhaseShiftChance() > 0.0 && random.nextDouble() < target.getPhaseShiftChance()) {
            logger.debug("{} phase-shifted and dodged!", target.getName());
            return HitResult.phaseShifted();
        }
        return HitResult.hit();
    }

    private HitResult checkPhaseShift(Character target) {
        if (target.getPhaseShiftChance() > 0.0 && random.nextDouble() < target.getPhaseShiftChance()) {
            logger.debug("{} phase-shifted and dodged!", target.getName());
            return HitResult.phaseShifted();
        }
        return HitResult.hit();
    }

    public static class HitResult {
        private final boolean hit;
        private final boolean phaseShifted;

        private HitResult(boolean hit, boolean phaseShifted) {
            this.hit = hit;
            this.phaseShifted = phaseShifted;
        }

        public static HitResult hit() {
            return new HitResult(true, false);
        }

        public static HitResult missed() {
            return new HitResult(false, false);
        }

        public static HitResult phaseShifted() {
            return new HitResult(false, true);
        }

        public boolean isHit() {
            return hit;
        }

        public boolean isPhaseShifted() {
            return phaseShifted;
        }

        public boolean isMissed() {
            return !hit;
        }
    }
}