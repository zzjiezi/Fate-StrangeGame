package com.game.rpg.view.scene;

import com.game.rpg.model.entities.AttackResult;
import com.game.rpg.model.entities.Character;
import com.game.rpg.model.entities.Enemy;
import com.game.rpg.model.enums.CommandSpellEffect;
import com.game.rpg.util.map.SpriteManager;
import com.game.rpg.util.resource.SoundManager;
import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.animation.Timeline;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.WritableImage;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class BattleView extends StackPane {
    private static final Logger logger = LoggerFactory.getLogger(BattleView.class);
    private static final double WINDOW_WIDTH = 1280;
    private static final double WINDOW_HEIGHT = 720;

    private static final String ENEMY_IMAGE_PLACEHOLDER = "/images/enemies/enemy_placeholder.png";

    private ImageView backgroundImage;

    private Pane layoutPane;

    private ImageView enemyImageView;
    private ProgressBar enemyHpBar;
    private Label enemyHpLabel;
    private ProgressBar enemyMpBar;
    private Label enemyMpLabel;
    private VBox enemyHpMpBox;

    private HBox charactersBox;
    private final List<VBox> charBoxList = new ArrayList<>();
    private final List<ImageView> characterImageViews = new ArrayList<>();
    private final List<Label> characterNameLabels = new ArrayList<>();
    private int selectedCharacterIndex = -1;

    private VBox selectedCharInfoBox;
    private ProgressBar selectedCharHpBar;
    private Label selectedCharHpLabel;
    private ProgressBar selectedCharMpBar;
    private Label selectedCharMpLabel;

    private VBox battleTextBox;
    private final List<Label> battleTextLabels = new ArrayList<>();

    private HBox actionButtonsBox;
    private Button attackButton;
    private Button noblePhantasmButton;
    private Button commandSpellButton;
    private Button fleeButton;
    private Label fleeDisabledLabel;

    private VBox commandSpellBox;
    private final List<Label> commandSpellLabels = new ArrayList<>();
    private Label noCommandSpellLabel;

    private ImageView fullScreenOverlay;
    private Rectangle flashOverlay;

    private Consumer<Integer> onCharacterSelected;
    private Consumer<String> onAttack;
    private Consumer<String> onNoblePhantasm;
    private Consumer<CommandSpellEffect> onCommandSpell;
    private Runnable onFlee;
    private Runnable onContinueClicked;

    private boolean isBossBattle = false;

    public BattleView() {
        initializeUI();
    }

    private void initializeUI() {
        setPrefSize(WINDOW_WIDTH, WINDOW_HEIGHT);

        backgroundImage = new ImageView();
        backgroundImage.setFitWidth(WINDOW_WIDTH);
        backgroundImage.setFitHeight(WINDOW_HEIGHT);
        backgroundImage.setPreserveRatio(false);
        try {
            Image bg = new Image(getClass().getResource(SoundManager.BATTLE_BACKGROUND).toExternalForm());
            backgroundImage.setImage(bg);
        } catch (Exception e) {
            Rectangle fallback = new Rectangle(WINDOW_WIDTH, WINDOW_HEIGHT, Color.rgb(13, 13, 26));
            getChildren().add(fallback);
        }

        layoutPane = new Pane();
        layoutPane.setPrefSize(WINDOW_WIDTH, WINDOW_HEIGHT);

        createEnemyImageSection();
        createEnemyHpMpSection();
        createCharacterSelectionSection();
        createSelectedCharInfoSection();
        createBattleTextSection();
        createActionButtonsSection();
        createCommandSpellSection();

        layoutPane.getChildren().addAll(
                enemyImageView, enemyHpMpBox,
                charactersBox,
                selectedCharInfoBox,
                battleTextBox,
                attackButton, noblePhantasmButton, commandSpellButton, fleeButton, fleeDisabledLabel,
                commandSpellBox
        );

        fullScreenOverlay = new ImageView();
        fullScreenOverlay.setFitWidth(WINDOW_WIDTH);
        fullScreenOverlay.setFitHeight(WINDOW_HEIGHT);
        fullScreenOverlay.setPreserveRatio(false);
        fullScreenOverlay.setVisible(false);
        fullScreenOverlay.setMouseTransparent(false);

        flashOverlay = new Rectangle(WINDOW_WIDTH, WINDOW_HEIGHT);
        flashOverlay.setFill(Color.rgb(255, 0, 0, 0.35));
        flashOverlay.setVisible(false);
        flashOverlay.setMouseTransparent(true);

        if (backgroundImage.getImage() != null) {
            getChildren().addAll(backgroundImage, layoutPane, flashOverlay, fullScreenOverlay);
        } else {
            getChildren().addAll(layoutPane, flashOverlay, fullScreenOverlay);
        }
    }

    private void createEnemyImageSection() {
        enemyImageView = new ImageView();
        enemyImageView.setFitWidth(160);
        enemyImageView.setFitHeight(160);
        enemyImageView.setPreserveRatio(true);
        enemyImageView.setSmooth(false);
        enemyImageView.setLayoutX(WINDOW_WIDTH / 2 - 80);
        enemyImageView.setLayoutY(WINDOW_HEIGHT * 0.15);

        try {
            Image placeholder = new Image(getClass().getResource(ENEMY_IMAGE_PLACEHOLDER).toExternalForm());
            enemyImageView.setImage(placeholder);
        } catch (Exception e) {
            WritableImage fallback = new WritableImage(160, 160);
            var writer = fallback.getPixelWriter();
            for (int py = 0; py < 160; py++) {
                for (int px = 0; px < 160; px++) {
                    writer.setColor(px, py, Color.rgb(40, 40, 60));
                }
            }
            enemyImageView.setImage(fallback);
        }
    }

    private void createEnemyHpMpSection() {
        enemyHpMpBox = new VBox(8);
        enemyHpMpBox.setAlignment(Pos.CENTER);

        HBox hpBox = new HBox(5);
        hpBox.setAlignment(Pos.CENTER_LEFT);
        Label hpTitle = new Label("HP：");
        hpTitle.setTextFill(Color.WHITE);
        hpTitle.setFont(Font.font(14));
        enemyHpBar = new ProgressBar(1.0);
        enemyHpBar.setPrefWidth(200);
        enemyHpBar.setStyle("-fx-accent: red;");
        enemyHpLabel = new Label("0/0");
        enemyHpLabel.setTextFill(Color.WHITE);
        enemyHpLabel.setFont(Font.font(14));
        hpBox.getChildren().addAll(hpTitle, enemyHpBar, enemyHpLabel);

        HBox mpBox = new HBox(5);
        mpBox.setAlignment(Pos.CENTER_LEFT);
        Label mpTitle = new Label("MP：");
        mpTitle.setTextFill(Color.WHITE);
        mpTitle.setFont(Font.font(14));
        enemyMpBar = new ProgressBar(1.0);
        enemyMpBar.setPrefWidth(200);
        enemyMpBar.setStyle("-fx-accent: dodgerblue;");
        enemyMpLabel = new Label("0/0");
        enemyMpLabel.setTextFill(Color.WHITE);
        enemyMpLabel.setFont(Font.font(14));
        mpBox.getChildren().addAll(mpTitle, enemyMpBar, enemyMpLabel);

        enemyHpMpBox.getChildren().addAll(hpBox, mpBox);
        enemyHpMpBox.setLayoutX(WINDOW_WIDTH / 2 - 130);
        enemyHpMpBox.setLayoutY(WINDOW_HEIGHT * 0.15 + 170);
    }

    private void createCharacterSelectionSection() {
        charactersBox = new HBox(30);
        charactersBox.setAlignment(Pos.CENTER);
        charactersBox.setLayoutX(WINDOW_WIDTH / 2 - 200);
        charactersBox.setLayoutY(WINDOW_HEIGHT * 2 / 3 - 55);
        charactersBox.setPrefWidth(400);
    }

    private void createSelectedCharInfoSection() {
        selectedCharInfoBox = new VBox(5);
        selectedCharInfoBox.setAlignment(Pos.CENTER);
        selectedCharInfoBox.setVisible(false);

        HBox hpBox = new HBox(5);
        hpBox.setAlignment(Pos.CENTER_LEFT);
        Label hpTitle = new Label("HP：");
        hpTitle.setTextFill(Color.WHITE);
        hpTitle.setFont(Font.font(13));
        selectedCharHpBar = new ProgressBar(1.0);
        selectedCharHpBar.setPrefWidth(180);
        selectedCharHpBar.setStyle("-fx-accent: red;");
        selectedCharHpLabel = new Label("0/0");
        selectedCharHpLabel.setTextFill(Color.WHITE);
        selectedCharHpLabel.setFont(Font.font(13));
        hpBox.getChildren().addAll(hpTitle, selectedCharHpBar, selectedCharHpLabel);

        HBox mpBox = new HBox(5);
        mpBox.setAlignment(Pos.CENTER_LEFT);
        Label mpTitle = new Label("MP：");
        mpTitle.setTextFill(Color.WHITE);
        mpTitle.setFont(Font.font(13));
        selectedCharMpBar = new ProgressBar(1.0);
        selectedCharMpBar.setPrefWidth(180);
        selectedCharMpBar.setStyle("-fx-accent: dodgerblue;");
        selectedCharMpLabel = new Label("0/0");
        selectedCharMpLabel.setTextFill(Color.WHITE);
        selectedCharMpLabel.setFont(Font.font(13));
        mpBox.getChildren().addAll(mpTitle, selectedCharMpBar, selectedCharMpLabel);

        selectedCharInfoBox.getChildren().addAll(hpBox, mpBox);
        selectedCharInfoBox.setLayoutX(WINDOW_WIDTH / 2 - 110);
        selectedCharInfoBox.setLayoutY(WINDOW_HEIGHT * 2 / 3 + 90);
    }

    private void createBattleTextSection() {
        battleTextBox = new VBox(5);
        battleTextBox.setAlignment(Pos.CENTER);
        battleTextBox.setPadding(new Insets(10));
        battleTextBox.setVisible(false);
        battleTextBox.setStyle("-fx-background-color: rgba(0, 0, 0, 0.6);");
        battleTextBox.setOnMouseClicked(e -> {
            if (onContinueClicked != null) onContinueClicked.run();
        });
        battleTextBox.setLayoutX(WINDOW_WIDTH / 2 - 300);
        battleTextBox.setLayoutY(WINDOW_HEIGHT * 0.5 + 30);
        battleTextBox.setPrefWidth(600);
    }

    private void createActionButtonsSection() {
        double btnW = 110;
        double btnH = 40;
        double gap = 30;
        double totalW = btnW * 4 + gap * 3;
        double startX = (WINDOW_WIDTH - totalW) / 2;

        attackButton = new Button("攻击");
        attackButton.setPrefSize(btnW, btnH);
        attackButton.setLayoutX(startX);
        attackButton.setLayoutY(WINDOW_HEIGHT - 65);
        attackButton.setOnAction(e -> {
            if (onAttack != null) onAttack.accept("attack");
        });

        noblePhantasmButton = new Button("宝具");
        noblePhantasmButton.setPrefSize(btnW, btnH);
        noblePhantasmButton.setLayoutX(startX + btnW + gap);
        noblePhantasmButton.setLayoutY(WINDOW_HEIGHT - 65);
        noblePhantasmButton.setOnAction(e -> {
            if (onNoblePhantasm != null) onNoblePhantasm.accept("noble_phantasm");
        });

        commandSpellButton = new Button("令咒");
        commandSpellButton.setPrefSize(btnW, btnH);
        commandSpellButton.setLayoutX(startX + (btnW + gap) * 2);
        commandSpellButton.setLayoutY(WINDOW_HEIGHT - 65);
        commandSpellButton.setOnAction(e -> showCommandSpellSelection());

        fleeButton = new Button("逃跑");
        fleeButton.setPrefSize(btnW, btnH);
        fleeButton.setLayoutX(startX + (btnW + gap) * 3);
        fleeButton.setLayoutY(WINDOW_HEIGHT - 65);
        fleeButton.setOnAction(e -> {
            if (onFlee != null) onFlee.run();
        });

        fleeDisabledLabel = new Label("（你被注视着，无法离开）");
        fleeDisabledLabel.setTextFill(Color.GRAY);
        fleeDisabledLabel.setFont(Font.font(12));
        fleeDisabledLabel.setVisible(false);
        fleeDisabledLabel.setLayoutX(startX + (btnW + gap) * 3 - 10);
        fleeDisabledLabel.setLayoutY(WINDOW_HEIGHT - 25);

        actionButtonsBox = null;
    }

    private void createCommandSpellSection() {
        commandSpellBox = new VBox(8);
        commandSpellBox.setAlignment(Pos.CENTER);
        commandSpellBox.setPadding(new Insets(10));
        commandSpellBox.setStyle("-fx-background-color: rgba(20, 20, 40, 0.9); -fx-border-color: #8b0000; -fx-border-width: 2;");
        commandSpellBox.setVisible(false);

        for (CommandSpellEffect effect : CommandSpellEffect.values()) {
            Label label = new Label(effect.getDisplayName());
            label.setTextFill(Color.WHITE);
            label.setFont(Font.font(16));
            label.setStyle("-fx-cursor: hand;");
            label.setOnMouseClicked(e -> {
                if (!label.isDisabled() && onCommandSpell != null) {
                    onCommandSpell.accept(effect);
                }
            });
            commandSpellLabels.add(label);
            commandSpellBox.getChildren().add(label);
        }

        noCommandSpellLabel = new Label("无令咒效果可选");
        noCommandSpellLabel.setTextFill(Color.GRAY);
        noCommandSpellLabel.setFont(Font.font(14));
        noCommandSpellLabel.setVisible(false);
        commandSpellBox.getChildren().add(noCommandSpellLabel);

        commandSpellBox.setLayoutX(WINDOW_WIDTH / 2 - 100);
        commandSpellBox.setLayoutY(WINDOW_HEIGHT - 200);
    }

    public void setupCharacters(List<Character> characters) {
        charactersBox.getChildren().clear();
        characterImageViews.clear();
        characterNameLabels.clear();
        charBoxList.clear();

        for (int i = 0; i < characters.size(); i++) {
            Character ch = characters.get(i);
            VBox charBox = new VBox(5);
            charBox.setAlignment(Pos.CENTER);
            charBox.setPadding(new Insets(8));
            charBox.setStyle("-fx-border-color: transparent; -fx-border-width: 3; -fx-border-radius: 5; -fx-background-color: rgba(30,30,50,0.7); -fx-background-radius: 5;");

            ImageView iv = new ImageView();
            iv.setFitWidth(80);
            iv.setFitHeight(80);
            iv.setPreserveRatio(true);
            iv.setSmooth(false);

            String spritePath = ch.getSpritePath();
            if (spritePath != null) {
                try {
                    Image raw = new Image(getClass().getResourceAsStream(spritePath));
                    iv.setImage(SpriteManager.cropTransparent(raw, spritePath));
                } catch (Exception e) {
                    logger.warn("Failed to load character sprite: {}", spritePath);
                }
            }

            Label nameLabel = new Label(ch.getClass().getSimpleName());
            nameLabel.setTextFill(Color.WHITE);
            nameLabel.setFont(Font.font(12));

            charBox.getChildren().addAll(iv, nameLabel);

            int index = i;
            charBox.setOnMouseClicked(e -> selectCharacter(index));
            charBox.setStyle("-fx-cursor: hand; -fx-border-color: transparent; -fx-border-width: 3; -fx-border-radius: 5; -fx-background-color: rgba(30,30,50,0.7); -fx-background-radius: 5;");

            charactersBox.getChildren().add(charBox);
            characterImageViews.add(iv);
            characterNameLabels.add(nameLabel);
            charBoxList.add(charBox);
        }
    }

    public void selectCharacter(int index) {
        selectedCharacterIndex = index;
        for (int i = 0; i < charBoxList.size(); i++) {
            VBox box = charBoxList.get(i);
            if (i == index) {
                box.setStyle("-fx-cursor: hand; -fx-border-color: #e6b800; -fx-border-width: 3; -fx-border-radius: 5; -fx-background-color: rgba(50,50,80,0.9); -fx-background-radius: 5;");
            } else {
                box.setStyle("-fx-cursor: hand; -fx-border-color: transparent; -fx-border-width: 3; -fx-border-radius: 5; -fx-background-color: rgba(30,30,50,0.7); -fx-background-radius: 5;");
            }
        }
        if (onCharacterSelected != null) onCharacterSelected.accept(index);
    }

    public void updateEnemyInfo(Enemy enemy) {
        if (enemy == null) return;
        enemyHpBar.setProgress((double) enemy.getHp() / enemy.getMaxHp());
        enemyHpLabel.setText(enemy.getHp() + "/" + enemy.getMaxHp());
        enemyMpBar.setProgress(enemy.getMaxMp() > 0 ? (double) enemy.getMp() / enemy.getMaxMp() : 0);
        enemyMpLabel.setText(enemy.getMp() + "/" + enemy.getMaxMp());
    }

    public void updateSelectedCharInfo(Character ch) {
        if (ch == null) {
            selectedCharInfoBox.setVisible(false);
            return;
        }
        selectedCharInfoBox.setVisible(true);
        selectedCharHpBar.setProgress((double) ch.getHp() / ch.getMaxHp());
        selectedCharHpLabel.setText(ch.getHp() + "/" + ch.getMaxHp());
        selectedCharMpBar.setProgress(ch.getMaxMp() > 0 ? (double) ch.getMp() / ch.getMaxMp() : 0);
        selectedCharMpLabel.setText(ch.getMp() + "/" + ch.getMaxMp());
    }

    public void setCharacterDead(int index, boolean hasReviveSpell) {
        if (index < 0 || index >= charBoxList.size()) return;
        VBox box = charBoxList.get(index);
        box.setOpacity(0.3);
        box.setStyle("-fx-border-color: transparent; -fx-border-width: 3; -fx-border-radius: 5; -fx-background-color: rgba(30,30,50,0.3); -fx-background-radius: 5;");
        if (hasReviveSpell) {
            box.setOnMouseClicked(e -> showBattleText(List.of("该角色已阵亡，是否使用复活令咒？")));
        } else {
            box.setOnMouseClicked(e -> showBattleText(List.of("该角色已阵亡，无可用复活令咒")));
        }
    }

    public void setCharacterRevived(int index) {
        if (index < 0 || index >= charBoxList.size()) return;
        VBox box = charBoxList.get(index);
        box.setOpacity(1.0);
        int idx = index;
        box.setOnMouseClicked(e -> selectCharacter(idx));
        box.setStyle("-fx-cursor: hand; -fx-border-color: transparent; -fx-border-width: 3; -fx-border-radius: 5; -fx-background-color: rgba(30,30,50,0.7); -fx-background-radius: 5;");
    }

    public void showBattleText(List<String> lines) {
        showBattleText(lines, false);
    }

    public void showBattleText(List<String> lines, boolean redText) {
        battleTextBox.getChildren().clear();
        battleTextLabels.clear();
        for (String line : lines) {
            Label label = new Label(line);
            if (redText) {
                label.setStyle("-fx-text-fill: red;");
            }
            label.setFont(Font.font("Microsoft YaHei", 18));
            battleTextLabels.add(label);
            battleTextBox.getChildren().add(label);
        }
        battleTextBox.setStyle(redText
                ? "-fx-background-color: rgba(40, 0, 0, 0.75);"
                : "-fx-background-color: rgba(0, 0, 0, 0.6);");
        battleTextBox.setVisible(true);
        charactersBox.setVisible(false);
    }

    public void shakeCharacter(int index) {
        if (index < 0 || index >= charBoxList.size()) return;
        VBox box = charBoxList.get(index);
        javafx.animation.Timeline shake = new javafx.animation.Timeline();
        int[] offsets = {-8, 8, -6, 6, -4, 4, -2, 2, 0};
        for (int i = 0; i < offsets.length; i++) {
            javafx.animation.KeyFrame kf = new javafx.animation.KeyFrame(
                    Duration.millis(50 * (i + 1)),
                    new javafx.animation.KeyValue(box.translateXProperty(), offsets[i])
            );
            shake.getKeyFrames().add(kf);
        }
        shake.setOnFinished(e -> box.setTranslateX(0));
        shake.play();
    }

    public void shakeEnemy() {
        javafx.animation.Timeline shake = new javafx.animation.Timeline();
        double[] offsets = {-10, 10, -8, 8, -6, 6, -3, 3, 0};
        for (int i = 0; i < offsets.length; i++) {
            javafx.animation.KeyFrame kfX = new javafx.animation.KeyFrame(
                    Duration.millis(40 * (i + 1)),
                    new javafx.animation.KeyValue(enemyImageView.translateXProperty(), offsets[i])
            );
            javafx.animation.KeyFrame kfY = new javafx.animation.KeyFrame(
                    Duration.millis(40 * (i + 1)),
                    new javafx.animation.KeyValue(enemyImageView.translateYProperty(), i % 2 == 0 ? offsets[i] * 0.5 : -offsets[i] * 0.5)
            );
            shake.getKeyFrames().addAll(kfX, kfY);
        }
        shake.setOnFinished(e -> {
            enemyImageView.setTranslateX(0);
            enemyImageView.setTranslateY(0);
        });
        shake.play();
    }

    public void hideBattleText() {
        battleTextBox.setVisible(false);
        charactersBox.setVisible(true);
    }

    public void showCommandSpellSelection() {
        commandSpellBox.setVisible(true);
        attackButton.setDisable(true);
        noblePhantasmButton.setDisable(true);
        commandSpellButton.setDisable(true);
        fleeButton.setDisable(true);
    }

    public void hideCommandSpellSelection() {
        commandSpellBox.setVisible(false);
        attackButton.setDisable(false);
        noblePhantasmButton.setDisable(false);
        commandSpellButton.setDisable(false);
        if (!isBossBattle) {
            fleeButton.setDisable(false);
        }
    }

    public void updateCommandSpellStates(Character character) {
        boolean allUsed = true;
        CommandSpellEffect[] effects = CommandSpellEffect.values();
        for (int i = 0; i < effects.length; i++) {
            boolean used = character.isCommandSpellUsed(effects[i]);
            commandSpellLabels.get(i).setDisable(used);
            commandSpellLabels.get(i).setOpacity(used ? 0.5 : 1.0);
            if (!used) allUsed = false;
        }
        noCommandSpellLabel.setVisible(allUsed);
    }

    public void flashRed() {
        flashOverlay.setVisible(true);
        FadeTransition fade = new FadeTransition(Duration.millis(300), flashOverlay);
        fade.setFromValue(1.0);
        fade.setToValue(0.0);
        fade.setOnFinished(e -> flashOverlay.setVisible(false));
        fade.play();
    }

    public void showNoblePhantasmOverlay(Image image) {
        fullScreenOverlay.setImage(image);
        fullScreenOverlay.setVisible(true);
        fullScreenOverlay.toFront();
    }

    public void hideNoblePhantasmOverlay() {
        fullScreenOverlay.setVisible(false);
    }

    public void setBossBattle(boolean isBoss) {
        this.isBossBattle = isBoss;
        fleeButton.setDisable(isBoss);
        fleeDisabledLabel.setVisible(isBoss);
    }

    public void setActionButtonsEnabled(boolean enabled) {
        attackButton.setDisable(!enabled);
        noblePhantasmButton.setDisable(!enabled);
        commandSpellButton.setDisable(!enabled);
        if (!isBossBattle) {
            fleeButton.setDisable(!enabled);
        }
    }

    public void setCharacterLocked(int index) {
        if (index < 0 || index >= charBoxList.size()) return;
        VBox box = charBoxList.get(index);
        box.setOpacity(0.4);
        box.setOnMouseClicked(null);
        box.setStyle("-fx-border-color: transparent; -fx-border-width: 3; -fx-border-radius: 5; -fx-background-color: rgba(30,30,50,0.3); -fx-background-radius: 5;");

        ImageView iv = characterImageViews.get(index);
        WritableImage lockImg = new WritableImage(80, 80);
        var writer = lockImg.getPixelWriter();
        for (int py = 0; py < 80; py++) {
            for (int px = 0; px < 80; px++) {
                writer.setColor(px, py, Color.TRANSPARENT);
            }
        }
        javafx.scene.text.Text questionMark = new javafx.scene.text.Text("?");
        questionMark.setFont(Font.font("Arial", FontWeight.BOLD, 50));
        questionMark.setFill(Color.RED);
        var snapshotParams = new javafx.scene.SnapshotParameters();
        snapshotParams.setFill(Color.TRANSPARENT);
        questionMark.snapshot(snapshotParams, lockImg);
        iv.setImage(lockImg);

        if (index < characterNameLabels.size()) {
            characterNameLabels.get(index).setTextFill(Color.GRAY);
        }
    }

    public void setOnCharacterSelected(Consumer<Integer> handler) { this.onCharacterSelected = handler; }
    public void setOnAttack(Consumer<String> handler) { this.onAttack = handler; }
    public void setOnNoblePhantasm(Consumer<String> handler) { this.onNoblePhantasm = handler; }
    public void setOnCommandSpell(Consumer<CommandSpellEffect> handler) { this.onCommandSpell = handler; }
    public void setOnFlee(Runnable handler) { this.onFlee = handler; }
    public void setOnContinueClicked(Runnable handler) { this.onContinueClicked = handler; }

    public int getSelectedCharacterIndex() { return selectedCharacterIndex; }
    public Button getAttackButton() { return attackButton; }
    public Button getNoblePhantasmButton() { return noblePhantasmButton; }
    public Button getCommandSpellButton() { return commandSpellButton; }
    public Button getFleeButton() { return fleeButton; }
    public ImageView getFullScreenOverlay() { return fullScreenOverlay; }

    public void setEnemyImage(Image image) {
        if (image != null) {
            enemyImageView.setImage(image);
        }
    }

    public void showBattleResult(String title, Runnable onFinished) {
        StackPane resultPane = new StackPane();
        resultPane.setPrefSize(WINDOW_WIDTH, WINDOW_HEIGHT);

        Rectangle blackBg = new Rectangle(WINDOW_WIDTH, WINDOW_HEIGHT);
        blackBg.setFill(Color.BLACK);
        blackBg.setOpacity(0);

        Text titleText = new Text(title);
        titleText.setFont(Font.font("STSong", 26));
        titleText.setFill(Color.WHITE);
        titleText.setOpacity(0);

        Text continueHint = new Text("点击任意处继续");
        continueHint.setFont(Font.font("STSong", 26));
        continueHint.setFill(Color.WHITE);
        continueHint.setOpacity(0);

        resultPane.getChildren().addAll(blackBg, titleText, continueHint);
        StackPane.setAlignment(titleText, javafx.geometry.Pos.CENTER);
        StackPane.setAlignment(continueHint, javafx.geometry.Pos.BOTTOM_CENTER);
        StackPane.setMargin(continueHint, new javafx.geometry.Insets(0, 0, 30, 0));
        getChildren().add(resultPane);

        FadeTransition fadeInBg = new FadeTransition(Duration.millis(800), blackBg);
        fadeInBg.setFromValue(0.0);
        fadeInBg.setToValue(1.0);

        FadeTransition fadeInText = new FadeTransition(Duration.millis(600), titleText);
        fadeInText.setFromValue(0.0);
        fadeInText.setToValue(1.0);

        FadeTransition fadeInHint = new FadeTransition(Duration.millis(400), continueHint);
        fadeInHint.setFromValue(0.0);
        fadeInHint.setToValue(1.0);

        javafx.animation.SequentialTransition seq = new javafx.animation.SequentialTransition(
                fadeInBg,
                fadeInText,
                new javafx.animation.PauseTransition(Duration.millis(500)),
                fadeInHint
        );
        seq.setOnFinished(e -> {
            resultPane.setOnMouseClicked(ev -> {
                getChildren().remove(resultPane);
                if (onFinished != null) onFinished.run();
            });
        });
        seq.play();
    }
}
