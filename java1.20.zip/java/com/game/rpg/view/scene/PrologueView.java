package com.game.rpg.view.scene;

import com.game.rpg.model.state.GameStateManager;
import com.game.rpg.util.resource.SoundManager;
import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.Consumer;

public class PrologueView extends StackPane {
    private static final Logger logger = LoggerFactory.getLogger(PrologueView.class);

    private static final String BLACK_BG_PATH = "/images/backgrounds/black_background.jpg";
    private static final String ACHIEVEMENT_SFX = "/sounds/achievement_unlock.wav";

    private final GameStateManager stateManager;
    private final SoundManager soundManager;

    private ImageView menuBackgroundView;
    private ImageView blackBackgroundView;
    private Text centerText;
    private VBox choiceBox;

    private int sleepCount = 0;
    private Runnable onPrologueComplete;
    private Runnable clickHandler;

    public PrologueView(GameStateManager stateManager, SoundManager soundManager) {
        this.stateManager = stateManager;
        this.soundManager = soundManager;
        initializeUI();
    }

    private void initializeUI() {
        setPrefSize(1280, 720);
        setStyle("-fx-background-color: black;");

        menuBackgroundView = new ImageView();
        menuBackgroundView.setFitWidth(1280);
        menuBackgroundView.setFitHeight(720);
        menuBackgroundView.setPreserveRatio(false);
        try {
            Image bg = new Image(getClass().getResource("/images/ui/背景.png").toExternalForm());
            menuBackgroundView.setImage(bg);
        } catch (Exception e) {
            logger.warn("Menu background not found");
        }

        blackBackgroundView = new ImageView();
        blackBackgroundView.setFitWidth(1280);
        blackBackgroundView.setFitHeight(720);
        blackBackgroundView.setPreserveRatio(false);
        try {
            Image bg = new Image(getClass().getResource(BLACK_BG_PATH).toExternalForm());
            blackBackgroundView.setImage(bg);
        } catch (Exception e) {
            logger.warn("Black background not found, using solid black");
        }
        blackBackgroundView.setOpacity(0.0);

        centerText = new Text();
        centerText.setFont(Font.font("SimSun", 20));
        centerText.setFill(Color.WHITE);
        centerText.setOpacity(0.0);

        choiceBox = new VBox(15);
        choiceBox.setAlignment(Pos.CENTER);
        choiceBox.setOpacity(0.0);

        VBox textBox = new VBox(centerText);
        textBox.setAlignment(Pos.CENTER);

        setOnMouseClicked(e -> {
            if (clickHandler != null) {
                clickHandler.run();
            }
        });

        getChildren().addAll(menuBackgroundView, blackBackgroundView, textBox, choiceBox);
    }

    public void start(Runnable onPrologueComplete) {
        this.onPrologueComplete = onPrologueComplete;
        transitionToBlack();
    }

    private void transitionToBlack() {
        FadeTransition menuFade = new FadeTransition(Duration.seconds(3.0), menuBackgroundView);
        menuFade.setFromValue(1.0);
        menuFade.setToValue(0.0);

        FadeTransition blackFade = new FadeTransition(Duration.seconds(3.0), blackBackgroundView);
        blackFade.setFromValue(0.0);
        blackFade.setToValue(1.0);

        menuFade.play();
        blackFade.play();

        blackFade.setOnFinished(e -> {
            getChildren().remove(menuBackgroundView);
            flashWhite();
        });
    }

    private void flashWhite() {
        Rectangle whiteOverlay = new Rectangle(1280, 720, Color.WHITE);
        whiteOverlay.setOpacity(0.0);
        getChildren().add(whiteOverlay);
        whiteOverlay.toFront();

        FadeTransition flashIn = new FadeTransition(Duration.millis(300), whiteOverlay);
        flashIn.setFromValue(0.0);
        flashIn.setToValue(1.0);

        FadeTransition flashOut = new FadeTransition(Duration.millis(500), whiteOverlay);
        flashOut.setFromValue(1.0);
        flashOut.setToValue(0.0);

        flashIn.setOnFinished(e -> flashOut.play());
        flashOut.setOnFinished(e -> {
            getChildren().remove(whiteOverlay);
            showTextAndWait("这是......", this::fadeOutTextThenChoice1);
        });
        flashIn.play();
    }

    private void fadeOutTextThenChoice1() {
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(0.5), centerText);
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);
        fadeOut.setOnFinished(e -> {
            centerText.setOpacity(0.0);
            showChoice1();
        });
        fadeOut.play();
    }

    private void showChoice1() {
        hideText();
        showChoices(new String[]{"管他呢，继续睡觉", "起床"}, choice -> {
            if (choice == 0) {
                sleepCount++;
                incrementSleepCount();
                showTextAndWait("你从未觉得眼皮如此沉重, 还好这里没有在早上八点半开始的什么课需要你,继续睡会儿吧……", this::showChoice2);
            } else {
                showWakeUp();
            }
        });
    }

    private void showChoice2() {
        hideText();
        showChoices(new String[]{"管他呢，继续睡觉", "起床"}, choice -> {
            if (choice == 0) {
                sleepCount++;
                incrementSleepCount();
                showTextAndWait("还是好困,昨晚是多久睡的来着……算了,不重要,我只想继续拥抱我的床……", this::showChoice3);
            } else {
                showWakeUp();
            }
        });
    }

    private void showChoice3() {
        hideText();
        showChoices(new String[]{"继续睡觉", "起床"}, choice -> {
            if (choice == 0) {
                sleepCount++;
                incrementSleepCount();
                showTextAndWait("你是如此疲惫, 于是一直睡到宇宙大道都磨灭了……", this::showAchievement);
            } else {
                showWakeUp();
            }
        });
    }

    private void showAchievement() {
        hideText();

        com.game.rpg.view.component.AchievementPopup.unlockSleepWar();

        centerText.setText("[获得成就:昏睡战争](获得条件:选择继续睡觉3次)");
        centerText.setFont(Font.font("SimSun", FontWeight.BOLD, 24));
        centerText.setFill(Color.GOLD);
        centerText.setOpacity(0.0);

        soundManager.playSfx(ACHIEVEMENT_SFX);

        FadeTransition fadeIn = new FadeTransition(Duration.seconds(0.5), centerText);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        fadeIn.setOnFinished(e -> {
            clickHandler = () -> {
                clickHandler = null;
                FadeTransition fadeOut = new FadeTransition(Duration.seconds(0.5), centerText);
                fadeOut.setFromValue(1.0);
                fadeOut.setToValue(0.0);
                fadeOut.setOnFinished(ev -> showChoice4());
                fadeOut.play();
            };
        });
        fadeIn.play();
    }

    private void showChoice4() {
        centerText.setFont(Font.font("SimSun", 20));
        centerText.setFill(Color.WHITE);
        showChoices(new String[]{"起床"}, choice -> showWakeUp());
    }

    private void showWakeUp() {
        hideChoices();
        centerText.setText("该起床了,睁开眼");
        centerText.setFont(Font.font("SimSun", 20));
        centerText.setFill(Color.WHITE);
        centerText.setOpacity(0.0);

        FadeTransition fadeIn = new FadeTransition(Duration.seconds(1.0), centerText);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        fadeIn.setOnFinished(e -> {
            clickHandler = () -> {
                clickHandler = null;
                if (onPrologueComplete != null) onPrologueComplete.run();
            };
        });
        fadeIn.play();
    }

    private void showTextAndWait(String text, Runnable onNext) {
        centerText.setText(text);
        centerText.setFont(Font.font("SimSun", 20));
        centerText.setFill(Color.WHITE);
        centerText.setOpacity(0.0);

        FadeTransition fadeIn = new FadeTransition(Duration.seconds(0.8), centerText);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        fadeIn.setOnFinished(e -> {
            clickHandler = () -> {
                clickHandler = null;
                if (onNext != null) onNext.run();
            };
        });
        fadeIn.play();
    }

    private void hideText() {
        centerText.setOpacity(0.0);
        clickHandler = null;
    }

    private void showChoices(String[] options, Consumer<Integer> onChoice) {
        choiceBox.getChildren().clear();
        double btnWidth = 280;
        double btnHeight = 45;
        for (int i = 0; i < options.length; i++) {
            Button btn = new Button(options[i]);
            btn.setFont(Font.font("SimSun", 18));
            btn.setPrefWidth(btnWidth);
            btn.setPrefHeight(btnHeight);
            btn.setAlignment(Pos.CENTER);
            btn.setStyle(
                "-fx-background-color: transparent; " +
                "-fx-text-fill: white; " +
                "-fx-border-color: rgba(255,255,255,0.5); " +
                "-fx-border-width: 1; " +
                "-fx-border-radius: 5; " +
                "-fx-cursor: hand;"
            );
            btn.setOnMouseEntered(e -> btn.setStyle(
                "-fx-background-color: rgba(255,255,255,0.15); " +
                "-fx-text-fill: white; " +
                "-fx-border-color: rgba(255,255,255,0.8); " +
                "-fx-border-width: 1; " +
                "-fx-border-radius: 5; " +
                "-fx-cursor: hand;"
            ));
            btn.setOnMouseExited(e -> btn.setStyle(
                "-fx-background-color: transparent; " +
                "-fx-text-fill: white; " +
                "-fx-border-color: rgba(255,255,255,0.5); " +
                "-fx-border-width: 1; " +
                "-fx-border-radius: 5; " +
                "-fx-cursor: hand;"
            ));
            int choiceIndex = i;
            btn.setOnAction(e -> {
                hideChoices();
                onChoice.accept(choiceIndex);
            });
            choiceBox.getChildren().add(btn);
        }
        choiceBox.setOpacity(1.0);
    }

    private void hideChoices() {
        choiceBox.setOpacity(0.0);
        choiceBox.getChildren().clear();
    }

    private void incrementSleepCount() {
        if (stateManager != null && stateManager.getCurrentState() != null) {
            Integer count = (Integer) stateManager.getCurrentState().getCustomData("sleepCount").orElse(0);
            stateManager.getCurrentState().setCustomData("sleepCount", count + 1);
        }
        logger.info("Sleep count: {}", sleepCount);
    }
}
