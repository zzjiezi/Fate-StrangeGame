package com.game.rpg.view.scene;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.geometry.Pos;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DisclaimerView extends StackPane {
    private static final Logger logger = LoggerFactory.getLogger(DisclaimerView.class);

    private static final String LOADING_BG_PATH = "/images/ui/loading.jpg";
    private static final double TOTAL_DURATION_MS = 6000;

    private final String fullText = """
            提示:本作为一款RPG类游戏，融合了多个不同游戏和动漫的梗与要素，包括但不限于：Fate系列、魔法少女小圆、怪诞小镇、崩坏：星穹铁道、传说之下等。所有的画面由于时间和精力的限制，部分画面可能略显粗糙，敬请谅解。如果你能接受—夹带众多私货,且有不同作品的大乱斗,对原作的一些浅薄的解构,幼稚的文笔以及多变的画风的话.就请开始游戏吧!希望你能在这一场冒险中获得些许愉悦~

            免责声明:
            本游戏为非商业性质的同人作品，所有角色和情节均基于原作进行二次创作，不用于任何商业用途。
            本游戏中的所有内容均为原创绘制和编写，如涉及版权问题，请联系作者进行处理。
            本游戏仅供娱乐使用，不构成对原作的任何侵权行为。如有任何疑问或建议，请随时联系我们。

            祝你游戏愉快！""";

    private Text displayText;
    private Timeline typewriterTimeline;
    private boolean allTextShown = false;
    private Runnable onFinished;

    public DisclaimerView() {
        initializeUI();
    }

    private void initializeUI() {
        setPrefSize(1280, 720);
        setStyle("-fx-background-color: black;");

        ImageView bgView = new ImageView();
        bgView.setFitWidth(1280);
        bgView.setFitHeight(720);
        bgView.setPreserveRatio(false);
        try {
            Image bg = new Image(getClass().getResource(LOADING_BG_PATH).toExternalForm());
            bgView.setImage(bg);
        } catch (Exception e) {
            logger.warn("Loading background not found");
        }

        displayText = new Text();
        displayText.setFont(Font.font("SimSun", 18));
        displayText.setFill(javafx.scene.paint.Color.WHITE);
        displayText.setTextAlignment(TextAlignment.LEFT);
        displayText.setWrappingWidth(900);

        VBox textBox = new VBox(displayText);
        textBox.setAlignment(Pos.CENTER);
        textBox.setMaxWidth(960);

        getChildren().addAll(bgView, textBox);

        setOnMouseClicked(e -> handleClick());
    }

    private void handleClick() {
        if (!allTextShown) {
            showAllText();
        } else {
            if (onFinished != null) onFinished.run();
        }
    }

    public void start(Runnable onFinished) {
        this.onFinished = onFinished;
        startTypewriter();
    }

    private void startTypewriter() {
        String text = fullText;
        int totalChars = text.length();
        int charDelay = (int) (TOTAL_DURATION_MS / totalChars);
        if (charDelay < 10) charDelay = 10;

        StringBuilder sb = new StringBuilder();
        final int[] index = {0};

        typewriterTimeline = new Timeline(new KeyFrame(Duration.millis(charDelay), e -> {
            if (index[0] < totalChars) {
                sb.append(text.charAt(index[0]));
                displayText.setText(sb.toString());
                index[0]++;
            } else {
                typewriterTimeline.stop();
                allTextShown = true;
            }
        }));
        typewriterTimeline.setCycleCount(totalChars);
        typewriterTimeline.play();
    }

    private void showAllText() {
        if (typewriterTimeline != null) {
            typewriterTimeline.stop();
        }
        displayText.setText(fullText);
        allTextShown = true;
    }
}