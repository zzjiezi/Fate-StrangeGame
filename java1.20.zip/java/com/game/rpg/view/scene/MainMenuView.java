package com.game.rpg.view.scene;

import com.game.rpg.controller.menu.MenuController;
import com.game.rpg.util.resource.ResourceLoader;
import com.game.rpg.view.component.AchievementPopup;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MainMenuView extends Pane {
    private static final Logger logger = LoggerFactory.getLogger(MainMenuView.class);
    
    private final ResourceLoader resourceLoader;
    private final MenuController menuController;
    private Runnable onLoadGame;
    private Runnable onShowAchievements;
    
    public MainMenuView(ResourceLoader resourceLoader, MenuController menuController) {
        this.resourceLoader = resourceLoader;
        this.menuController = menuController;
        
        initializeUI();
    }
    
    private void initializeUI() {
        setPrefSize(1280, 720);
        
        ImageView backgroundView = loadBackground();
        if (backgroundView != null) {
            getChildren().add(backgroundView);
        }
        
        createTransparentButtons();
        
        logger.info("Main menu view initialized");
    }
    
    private ImageView loadBackground() {
        try {
            String backgroundPath = "/images/ui/背景.png";
            Image backgroundImage = resourceLoader.loadImage(backgroundPath);
            
            ImageView imageView = new ImageView(backgroundImage);
            imageView.setFitWidth(1280);
            imageView.setFitHeight(720);
            imageView.setPreserveRatio(false);
            
            return imageView;
        } catch (Exception e) {
            logger.warn("Failed to load background image, using fallback", e);
            return createFallbackBackground();
        }
    }
    
    private ImageView createFallbackBackground() {
        ImageView imageView = new ImageView();//
        imageView.setFitWidth(1280);
        imageView.setFitHeight(720);
        imageView.setStyle("-fx-background-color: #1a1a2e;");
        return imageView;
    }
    
    private void createTransparentButtons() {
        Button newGameButton = createMenuButton(
            540, 400, 150, 50,
            "New game button clicked",
            () -> menuController.startNewGame()
        );
        
        Button loadGameButton = createMenuButton(
            540, 480, 180, 50,
            "Load game button clicked",
            this::showSaveList
        );
        
        Button achievementsButton = createMenuButton(
            540, 549, 180, 50,
            "Achievements button clicked",
            this::showAchievements
        );
        
        getChildren().addAll(newGameButton, loadGameButton, achievementsButton);
    }
    
    private Button createMenuButton(double x, double y, double width, double height,
                                     String logMessage, Runnable action) {
        Button button = new Button();
        
        button.setLayoutX(x);
        button.setLayoutY(y);
        button.setPrefWidth(width);
        button.setPrefHeight(height);

        String normalStyle =
            "-fx-background-color: transparent; " +
            "-fx-border-color: transparent; " +
            "-fx-cursor: hand;";

        String hoverStyle =
            "-fx-background-color: rgba(255, 255, 255, 0.1); " +
            "-fx-border-color: transparent; " +
            "-fx-cursor: hand;";

        button.setStyle(normalStyle);
        
        button.setOnMouseEntered(e -> button.setStyle(hoverStyle));
        button.setOnMouseExited(e -> button.setStyle(normalStyle));
        
        button.setOnAction(e -> {
            logger.info(logMessage);
            action.run();
        });
        
        return button;
    }
    
    private void showSaveList() {
        logger.info("Showing save list");
        if (onLoadGame != null) onLoadGame.run();
    }
    
    private void showAchievements() {
        logger.info("Showing achievements");

        VBox overlay = new VBox(20);
        overlay.setAlignment(javafx.geometry.Pos.CENTER);
        overlay.setPrefSize(1280, 720);
        overlay.setStyle("-fx-background-color: rgba(0, 0, 0, 0.85);");

        Text titleLabel = new Text("已获得成就");
        titleLabel.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 36));
        titleLabel.setFill(Color.WHITE);
        titleLabel.setTextAlignment(TextAlignment.CENTER);

        java.util.List<String> names = AchievementPopup.getUnlockedAchievementNames();

        VBox achievementList = new VBox(20);
        achievementList.setAlignment(javafx.geometry.Pos.CENTER);

        if (names.isEmpty()) {
            Text emptyText = new Text("暂无成就");
            emptyText.setFont(Font.font("Microsoft YaHei", 28));
            emptyText.setFill(Color.GRAY);
            emptyText.setTextAlignment(TextAlignment.CENTER);
            achievementList.getChildren().add(emptyText);
        } else {
            for (String name : names) {
                Text achText = new Text("【" + name + "】");
                achText.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 36));
                achText.setFill(Color.GOLD);
                achText.setTextAlignment(TextAlignment.CENTER);
                achievementList.getChildren().add(achText);
            }
        }

        Text hintText = new Text("点击任意处返回");
        hintText.setFont(Font.font("Microsoft YaHei", 16));
        hintText.setFill(Color.WHITE);
        hintText.setTextAlignment(TextAlignment.CENTER);

        overlay.getChildren().addAll(titleLabel, achievementList, hintText);
        getChildren().add(overlay);

        overlay.setOnMouseClicked(e -> getChildren().remove(overlay));
    }

    public void setOnLoadGame(Runnable onLoadGame) {
        this.onLoadGame = onLoadGame;
    }

    public void setOnShowAchievements(Runnable onShowAchievements) {
        this.onShowAchievements = onShowAchievements;
    }
}