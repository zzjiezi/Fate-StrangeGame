package com.game.rpg.view.scene;

import com.game.rpg.util.map.SpriteManager;
import com.game.rpg.util.map.TiledMapParser;
import com.game.rpg.util.resource.ResourceLoader;
import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.function.Consumer;

public class GameMapView extends StackPane {
    private static final Logger logger = LoggerFactory.getLogger(GameMapView.class);

    public static final int GAME_WIDTH = 1280;
    public static final int GAME_HEIGHT = 720;
    private static final double PLAYER_SPEED = 2.0;
    private static final double PLAYER_SIZE = 80;

    private final ResourceLoader resourceLoader;
    private final SpriteManager spriteManager;

    private Pane mapPane;
    private ImageView mapBackground;
    private ImageView playerSprite;
    private Pane interactionLayer;
    private Pane npcLayer;

    private StackPane dialogOverlay;
    private ImageView dialogBackgroundImg;
    private Text dialogText;
    private Text dialogContinueHint;
    private VBox dialogChoiceBox;

    private double playerX;
    private double playerY;
    private TiledMapParser.TiledMapData currentMapData;
    private double mapWidth = GAME_WIDTH;
    private double mapHeight = GAME_HEIGHT;

    private double cameraOffsetX = 0;
    private double cameraOffsetY = 0;

    private final Set<KeyCode> pressedKeys = new HashSet<>();
    private javafx.animation.AnimationTimer gameLoop;

    private boolean inputLocked = false;
    private Runnable onClickCallback;
    private boolean waitingForClick = false;
    private boolean fKeyConsumed = true;

    private final List<InteractionZone> interactionZones = new ArrayList<>();
    private final List<NPCSprite> npcSprites = new ArrayList<>();
    private final Map<String, Boolean> gameFlags = new HashMap<>();

    private Text interactionHint;

    private String playerDirection = "down";
    private Runnable onFirstMoveCallback;
    private boolean hasMovedOnce = false;

    private static final String[][] SKIN_PATHS = {
            {
                    "/images/characters/player/player 1正面 .png",
                    "/images/characters/player/player 1背面 .png",
                    "/images/characters/player/player 1左视图.png",
                    "/images/characters/player/player 1右视图.png"
            },
            {
                    "/images/characters/Saber/Saber 1正面 .png",
                    "/images/characters/Saber/Saber 1背面 .png",
                    "/images/characters/Saber/Saber 左视图.png",
                    "/images/characters/Saber/Saber 右视图.png"
            },
            {
                    "/images/characters/archer/archer1.png",
                    "/images/characters/archer/archer2.png",
                    "/images/characters/archer/archer 右视图2.png",
                    "/images/characters/archer/archer 左视图2.png"
            },
            {
                    "/images/characters/Caster/Bill正面3.png",
                    "/images/characters/Caster/Bill背面.png",
                    "/images/characters/Caster/Bill侧面1.png",
                    "/images/characters/Caster/侧面2.png"
            }
    };

    private int currentSkinIndex = 0;
    private String currentMapId = "1";

    public GameMapView(ResourceLoader resourceLoader) {
        this.resourceLoader = resourceLoader;
        this.spriteManager = new SpriteManager(resourceLoader);

        setPrefSize(GAME_WIDTH, GAME_HEIGHT);
        setMaxSize(GAME_WIDTH, GAME_HEIGHT);
        setMinSize(GAME_WIDTH, GAME_HEIGHT);
        initializeUI();
        setupInput();
    }

    private void initializeUI() {
        mapPane = new Pane();
        mapPane.setPrefSize(GAME_WIDTH, GAME_HEIGHT);
        mapPane.setClip(new Rectangle(GAME_WIDTH, GAME_HEIGHT));

        mapBackground = new ImageView();
        mapBackground.setPreserveRatio(false);

        interactionLayer = new Pane();
        npcLayer = new Pane();

        playerSprite = new ImageView();
        playerSprite.setFitWidth(PLAYER_SIZE);
        playerSprite.setFitHeight(PLAYER_SIZE);
        playerSprite.setPreserveRatio(true);
        playerSprite.setSmooth(false);

        mapPane.getChildren().addAll(mapBackground, interactionLayer, npcLayer, playerSprite);

        dialogOverlay = new StackPane();
        dialogOverlay.setPrefSize(GAME_WIDTH, GAME_HEIGHT);
        dialogOverlay.setMaxSize(GAME_WIDTH, GAME_HEIGHT);
        dialogOverlay.setMinSize(GAME_WIDTH, GAME_HEIGHT);
        dialogOverlay.setVisible(false);
        dialogOverlay.setMouseTransparent(true);

        dialogBackgroundImg = new ImageView();
        dialogBackgroundImg.setPreserveRatio(false);

        dialogText = new Text();
        dialogText.setFont(Font.font("华文中宋", 26));
        dialogText.setFill(Color.WHITE);
        dialogText.setWrappingWidth(1100);

        dialogContinueHint = new Text("▼ 点击继续");
        dialogContinueHint.setFont(Font.font("华文中宋", 26));
        dialogContinueHint.setFill(Color.WHITE);

        Pane dialogContentPane = new Pane();
        dialogContentPane.setPrefWidth(GAME_WIDTH);
        dialogContentPane.setPrefHeight(GAME_HEIGHT);

        dialogBackgroundImg.setLayoutX(0);
        dialogBackgroundImg.setLayoutY(0);
        dialogBackgroundImg.setFitWidth(GAME_WIDTH);
        dialogBackgroundImg.setFitHeight(GAME_HEIGHT);

        dialogText.setLayoutX(80);
        dialogText.setLayoutY(GAME_HEIGHT - 180 + 45);
        dialogText.setWrappingWidth(GAME_WIDTH - 160);

        dialogContinueHint.setLayoutX(GAME_WIDTH - 160);
        dialogContinueHint.setLayoutY(GAME_HEIGHT - 25);

        dialogContentPane.getChildren().addAll(dialogBackgroundImg, dialogText, dialogContinueHint);

        dialogChoiceBox = new VBox(10);
        dialogChoiceBox.setLayoutX(GAME_WIDTH / 2 - 200);
        dialogChoiceBox.setLayoutY(GAME_HEIGHT / 2 - 60);
        dialogChoiceBox.setPrefWidth(400);

        dialogContentPane.getChildren().add(dialogChoiceBox);

        dialogOverlay.getChildren().add(dialogContentPane);


        Pane hintLayer = new Pane();
        hintLayer.setPrefSize(GAME_WIDTH, GAME_HEIGHT);
        hintLayer.setId("hintLayer");
        hintLayer.setMouseTransparent(true);

        interactionHint = new Text("按 F 键交互");
        interactionHint.setFont(Font.font("华文中宋", 26));
        interactionHint.setFill(Color.WHITE);
        interactionHint.setStroke(Color.BLACK);
        interactionHint.setStrokeWidth(1.5);
        interactionHint.setVisible(false);
        interactionHint.setX(GAME_WIDTH / 2 - 70);
        interactionHint.setY(GAME_HEIGHT - 30);
        hintLayer.getChildren().add(interactionHint);

        Pane menuButtonLayer = new Pane();
        menuButtonLayer.setPrefSize(GAME_WIDTH, GAME_HEIGHT);
        menuButtonLayer.setId("menuButtonLayer");
        menuButtonLayer.setPickOnBounds(false);

        getChildren().addAll(mapPane, hintLayer, dialogOverlay, menuButtonLayer);

        setupClickHandler();
    }

    private void setupClickHandler() {
        setOnMouseClicked(e -> {
            if (waitingForClick) {
                waitingForClick = false;
                if (onClickCallback != null) {
                    Runnable cb = onClickCallback;
                    onClickCallback = null;
                    cb.run();
                }
            }
        });
    }

    private void setupInput() {
        sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                bindKeyHandlers(newScene);
            }
        });

        gameLoop = new javafx.animation.AnimationTimer() {
            @Override
            public void handle(long now) {
                if (inputLocked) return;
                updatePlayer();
                checkInteractionZones();
            }
        };
    }

    private void bindKeyHandlers(Scene scene) {
        scene.setOnKeyPressed(e -> {
            if (!inputLocked) {
                pressedKeys.add(e.getCode());
                if (e.getCode() == KeyCode.F) {
                    fKeyConsumed = false;
                }
            }
        });
        scene.setOnKeyReleased(e -> pressedKeys.remove(e.getCode()));
    }

    public void ensureKeyBindings() {
        Scene scene = getScene();
        if (scene != null) {
            bindKeyHandlers(scene);
        }
    }

    private void updatePlayer() {
        double dx = 0, dy = 0;

        if (pressedKeys.contains(KeyCode.UP) || pressedKeys.contains(KeyCode.W)) {
            dy = -PLAYER_SPEED;
            playerDirection = "up";
        }
        if (pressedKeys.contains(KeyCode.DOWN) || pressedKeys.contains(KeyCode.S)) {
            dy = PLAYER_SPEED;
            playerDirection = "down";
        }
        if (pressedKeys.contains(KeyCode.LEFT) || pressedKeys.contains(KeyCode.A)) {
            dx = -PLAYER_SPEED;
            playerDirection = "left";
        }
        if (pressedKeys.contains(KeyCode.RIGHT) || pressedKeys.contains(KeyCode.D)) {
            dx = PLAYER_SPEED;
            playerDirection = "right";
        }

        if (dx == 0 && dy == 0) return;

        if (!hasMovedOnce) {
            hasMovedOnce = true;
            if (onFirstMoveCallback != null) {
                onFirstMoveCallback.run();
                return;
            }
        }

        updatePlayerSprite();

        double newX = playerX + dx;
        double newY = playerY + dy;

        if (newX < 0 || newX + PLAYER_SIZE > mapWidth) dx = 0;
        if (newY < 0 || newY + PLAYER_SIZE > mapHeight) dy = 0;

        newX = playerX + dx;
        newY = playerY + dy;

        if (currentMapData != null) {
            if (currentMapData.isRectColliding(newX, newY, PLAYER_SIZE, PLAYER_SIZE)) {
                if (dx != 0 && currentMapData.isRectColliding(playerX + dx, playerY, PLAYER_SIZE, PLAYER_SIZE)) {
                    dx = 0;
                }
                if (dy != 0 && currentMapData.isRectColliding(playerX, playerY + dy, PLAYER_SIZE, PLAYER_SIZE)) {
                    dy = 0;
                }
                newX = playerX + dx;
                newY = playerY + dy;
                if (currentMapData.isRectColliding(newX, newY, PLAYER_SIZE, PLAYER_SIZE)) return;
            }
        }

        playerX = newX;
        playerY = newY;

        updateCamera();
        updatePlayerScreenPosition();

    }

    private void updateCamera() {
        if (mapWidth <= GAME_WIDTH) {
            cameraOffsetX = 0;
        } else {
            double targetX = playerX + PLAYER_SIZE / 2 - GAME_WIDTH / 2;
            cameraOffsetX = Math.max(0, Math.min(targetX, mapWidth - GAME_WIDTH));
        }

        if (mapHeight <= GAME_HEIGHT) {
            cameraOffsetY = 0;
        } else {
            double targetY = playerY + PLAYER_SIZE / 2 - GAME_HEIGHT / 2;
            cameraOffsetY = Math.max(0, Math.min(targetY, mapHeight - GAME_HEIGHT));
        }

        mapBackground.setLayoutX(-cameraOffsetX);
        mapBackground.setLayoutY(-cameraOffsetY);
        interactionLayer.setLayoutX(-cameraOffsetX);
        interactionLayer.setLayoutY(-cameraOffsetY);
        npcLayer.setLayoutX(-cameraOffsetX);
        npcLayer.setLayoutY(-cameraOffsetY);
    }

    private void updatePlayerSprite() {
        String[] skin = SKIN_PATHS[currentSkinIndex];
        String spritePath = switch (playerDirection) {
            case "up" -> skin[1];
            case "down" -> skin[0];
            case "left" -> skin[2];
            case "right" -> skin[3];
            default -> skin[0];
        };
        Image img = spriteManager.getSprite(spritePath);
        if (img != null) {
            logger.info("Sprite loaded: {} size={}x{}", spritePath, (int) img.getWidth(), (int) img.getHeight());
            playerSprite.setImage(img);
        } else {
            playerSprite.setImage(createPlaceholder(PLAYER_SIZE, PLAYER_SIZE));
        }
    }

    public void setPlayerVisible(boolean visible) {
        playerSprite.setVisible(visible);
    }

    public void waitForClick(Runnable onAdvance) {
        inputLocked = true;
        waitingForClick = true;
        onClickCallback = onAdvance;
    }

    private void updatePlayerScreenPosition() {
        playerSprite.setLayoutX(playerX - cameraOffsetX);
        playerSprite.setLayoutY(playerY - cameraOffsetY);
    }

    private void checkInteractionZones() {
        double playerCenterX = playerX + PLAYER_SIZE / 2;
        double playerCenterY = playerY + PLAYER_SIZE / 2;

        boolean anyOverlap = false;
        for (InteractionZone zone : interactionZones) {
            if (zone.completed) continue;
            if (zone.rect.contains(playerCenterX, playerCenterY)) {
                anyOverlap = true;
                if (!fKeyConsumed) {
                    fKeyConsumed = true;
                    interactionHint.setVisible(false);
                    zone.onTrigger.run();
                    return;
                }
            }
        }

        interactionHint.setVisible(anyOverlap);
    }

    public void loadMap(String mapImagePath, String tmjPath, double spawnX, double spawnY) {
        hideDialog();

        try {
            Image img = resourceLoader.loadImage(mapImagePath);
            mapBackground.setImage(img);
            mapWidth = img.getWidth();
            mapHeight = img.getHeight();
            mapBackground.setFitWidth(mapWidth);
            mapBackground.setFitHeight(mapHeight);
        } catch (Exception e) {
            logger.warn("Failed to load map image: {}", mapImagePath, e);
            mapBackground.setImage(createPlaceholder(GAME_WIDTH, GAME_HEIGHT));
            mapWidth = GAME_WIDTH;
            mapHeight = GAME_HEIGHT;
            mapBackground.setFitWidth(mapWidth);
            mapBackground.setFitHeight(mapHeight);
        }

        if (tmjPath != null) {
            currentMapData = TiledMapParser.parse(tmjPath);
            if (currentMapData != null) {
                logger.info("Loaded collision data: {} colliders from {}", currentMapData.colliders().size(), tmjPath);
                for (TiledMapParser.CollisionRect c : currentMapData.colliders()) {
                    logger.debug("  Collider: x={} y={} w={} h={}", c.x(), c.y(), c.width(), c.height());
                }
            }
        } else {
            currentMapData = null;
            logger.warn("No TMJ path provided, collision disabled");
        }

        playerX = spawnX;
        playerY = spawnY;
        cameraOffsetX = 0;
        cameraOffsetY = 0;

        interactionLayer.getChildren().clear();
        npcLayer.getChildren().clear();
        interactionZones.clear();
        npcSprites.clear();

        updatePlayerSprite();
        updateCamera();
        updatePlayerScreenPosition();

        logger.info("Map loaded: {} at ({}, {}) mapSize={}x{}", mapImagePath, spawnX, spawnY, mapWidth, mapHeight);
    }

    public void addInteractionZone(String id, double x, double y, double w, double h,
                                    Runnable onTrigger, boolean oneShot) {
        addInteractionZone(id, x, y, w, h, onTrigger, oneShot, x + w / 2, y + h / 2);
    }

    public void addInteractionZone(String id, double x, double y, double w, double h,
                                    Runnable onTrigger, boolean oneShot,
                                    double starTipCenterX, double starTipCenterY) {
        addInteractionZone(id, x, y, w, h, onTrigger, oneShot, starTipCenterX, starTipCenterY, "/images/ui/starTip.png");
    }

    public void addInteractionZone(String id, double x, double y, double w, double h,
                                    Runnable onTrigger, boolean oneShot,
                                    double starTipCenterX, double starTipCenterY, String starTipPath) {
        InteractionZone zone = new InteractionZone(id, new TiledMapParser.CollisionRect(x, y, w, h), onTrigger, oneShot);
        interactionZones.add(zone);

        try {
            Image starImg = resourceLoader.loadImage(starTipPath);
            ImageView starView = new ImageView(starImg);
            starView.setLayoutX(starTipCenterX - 16);
            starView.setLayoutY(starTipCenterY - 16);
            interactionLayer.getChildren().add(starView);
        } catch (Exception e) {
            logger.warn("Failed to load {}, using placeholder", starTipPath);
            Rectangle placeholder = new Rectangle(starTipCenterX - 16, starTipCenterY - 16, 32, 32);
            placeholder.setFill(Color.MAGENTA);
            interactionLayer.getChildren().add(placeholder);
        }
    }

    public void addNPC(String id, double x, double y, String spritePath, double width, double height) {
        ImageView npcView;
        try {
            npcView = spriteManager.createSpriteView(spritePath, width, height);
        } catch (Exception e) {
            logger.warn("Failed to load NPC sprite: {}, using placeholder", spritePath);
            npcView = new ImageView(createPlaceholder(width, height));
        }
        npcView.setLayoutX(x);
        npcView.setLayoutY(y);
        npcLayer.getChildren().add(npcView);
        npcSprites.add(new NPCSprite(id, x, y, npcView));
    }

    public void updateNPCSprite(String id, String newSpritePath) {
        for (NPCSprite npc : npcSprites) {
            if (npc.id.equals(id)) {
                Image img = spriteManager.getSprite(newSpritePath);
                if (img != null) {
                    npc.view.setImage(img);
                } else {
                    npc.view.setImage(createPlaceholder(npc.view.getFitWidth(), npc.view.getFitHeight()));
                }
                break;
            }
        }
    }

    public void removeNPC(String id) {
        npcSprites.removeIf(npc -> {
            if (npc.id.equals(id)) {
                npcLayer.getChildren().remove(npc.view);
                return true;
            }
            return false;
        });
    }

    private void applyDialogBackground(String dialogBgPath) {
        try {
            Image bgImg = resourceLoader.loadImage(dialogBgPath);
            dialogBackgroundImg.setImage(bgImg);
        } catch (Exception e) {
            logger.warn("Failed to load dialog background: {}", dialogBgPath);
        }
    }

    public void showDialogWithBackground(String dialogBgPath, String text, Runnable onAdvance) {
        showDialogWithBackground(dialogBgPath, text, onAdvance, true);
    }

    public void showDialogWithBackground(String dialogBgPath, String text, Runnable onAdvance, boolean autoHide) {
        inputLocked = true;
        applyDialogBackground(dialogBgPath);
        dialogText.setText(text);
        dialogContinueHint.setVisible(true);
        dialogChoiceBox.getChildren().clear();
        dialogOverlay.setVisible(true);
        dialogOverlay.setMouseTransparent(false);
        waitingForClick = true;
        onClickCallback = () -> {
            if (autoHide) hideDialog();
            if (onAdvance != null) onAdvance.run();
        };
    }

    public void showDialogWithChoice(String dialogBgPath, String text,
                                      List<String> choices, Consumer<Integer> onChoice) {
        inputLocked = true;
        applyDialogBackground(dialogBgPath);
        dialogText.setText(text);
        dialogContinueHint.setVisible(false);
        dialogChoiceBox.getChildren().clear();

        for (int i = 0; i < choices.size(); i++) {
            final int idx = i;
            Button btn = new Button(choices.get(i));
            btn.setFont(Font.font("华文中宋", 26));
            btn.setPrefWidth(400);
            btn.setStyle("-fx-background-color: rgba(40,40,40,0.9); -fx-text-fill: white; " +
                    "-fx-border-color: #5a5a5a; -fx-border-width: 2; -fx-padding: 8 16;");
            btn.setOnMouseEntered(e -> btn.setStyle(
                    "-fx-background-color: rgba(60,60,60,0.9); -fx-text-fill: cyan; " +
                            "-fx-border-color: cyan; -fx-border-width: 2; -fx-padding: 8 16;"));
            btn.setOnMouseExited(e -> btn.setStyle(
                    "-fx-background-color: rgba(40,40,40,0.9); -fx-text-fill: white; " +
                            "-fx-border-color: #5a5a5a; -fx-border-width: 2; -fx-padding: 8 16;"));
            btn.setOnAction(e -> {
                hideDialog();
                onChoice.accept(idx);
            });
            dialogChoiceBox.getChildren().add(btn);
        }

        dialogOverlay.setVisible(true);
        dialogOverlay.setMouseTransparent(false);
    }

    public void showFullScreenOverlay(String text, Runnable onAdvance) {
        inputLocked = true;

        StackPane overlay = new StackPane();
        overlay.setPrefSize(GAME_WIDTH, GAME_HEIGHT);

        Rectangle bg = new Rectangle(GAME_WIDTH, GAME_HEIGHT);
        bg.setFill(Color.BLACK);
        bg.setOpacity(0.7);

        Text overlayText = new Text(text);
        overlayText.setFont(Font.font("华文中宋", 26));
        overlayText.setFill(Color.WHITE);
        overlayText.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        overlayText.setWrappingWidth(1000);
        overlayText.setLineSpacing(24 * 0.8);

        Text continueHint = new Text("点击任意处继续");
        continueHint.setFont(Font.font("华文中宋", 26));
        continueHint.setFill(Color.WHITE);

        VBox contentBox = new VBox(20);
        contentBox.setAlignment(javafx.geometry.Pos.CENTER);
        contentBox.getChildren().add(overlayText);

        overlay.getChildren().addAll(bg, contentBox, continueHint);
        StackPane.setAlignment(contentBox, javafx.geometry.Pos.CENTER);
        StackPane.setAlignment(continueHint, javafx.geometry.Pos.BOTTOM_CENTER);
        StackPane.setMargin(continueHint, new javafx.geometry.Insets(0, 0, 30, 0));

        getChildren().add(overlay);
        waitingForClick = true;
        onClickCallback = () -> {
            getChildren().remove(overlay);
            if (onAdvance != null) onAdvance.run();
        };
    }

    public void showScreenShake(Runnable onComplete) {
        inputLocked = true;
        double origX = mapPane.getTranslateX();
        double origY = mapPane.getTranslateY();

        javafx.animation.Timeline shake = new javafx.animation.Timeline(
                new javafx.animation.KeyFrame(Duration.millis(50), e -> mapPane.setTranslateX(origX + 10)),
                new javafx.animation.KeyFrame(Duration.millis(100), e -> mapPane.setTranslateX(origX - 10)),
                new javafx.animation.KeyFrame(Duration.millis(150), e -> mapPane.setTranslateX(origX + 6)),
                new javafx.animation.KeyFrame(Duration.millis(200), e -> mapPane.setTranslateX(origX - 6)),
                new javafx.animation.KeyFrame(Duration.millis(250), e -> mapPane.setTranslateX(origX + 3)),
                new javafx.animation.KeyFrame(Duration.millis(300), e -> {
                    mapPane.setTranslateX(origX);
                    mapPane.setTranslateY(origY);
                })
        );
        shake.setOnFinished(e -> {
            if (onComplete != null) onComplete.run();
        });
        shake.play();
    }

    public void showRedFlash(Runnable onComplete) {
        Rectangle redFlash = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.RED);
        redFlash.setOpacity(0);
        redFlash.setMouseTransparent(true);
        getChildren().add(redFlash);

        FadeTransition flashIn = new FadeTransition(Duration.millis(150), redFlash);
        flashIn.setFromValue(0.0);
        flashIn.setToValue(0.8);

        FadeTransition flashOut = new FadeTransition(Duration.millis(300), redFlash);
        flashOut.setFromValue(0.8);
        flashOut.setToValue(0.0);
        flashOut.setOnFinished(e -> {
            getChildren().remove(redFlash);
            if (onComplete != null) onComplete.run();
        });

        SequentialTransition seq = new SequentialTransition(flashIn, flashOut);
        seq.play();
    }

    public void showBlackScreen(long waitMs, Runnable onComplete) {
        inputLocked = true;
        Rectangle black = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.BLACK);
        black.setMouseTransparent(true);
        getChildren().add(black);

        if (waitMs > 0) {
            PauseTransition wait = new PauseTransition(Duration.millis(waitMs));
            wait.setOnFinished(e -> {
                getChildren().remove(black);
                if (onComplete != null) onComplete.run();
            });
            wait.play();
        } else {
            waitingForClick = true;
            onClickCallback = () -> {
                getChildren().remove(black);
                if (onComplete != null) onComplete.run();
            };
        }
    }

    public void showBlackScreenWithText(String text, Runnable onAdvance) {
        showBlackScreenWithText(text, Color.WHITE, 24, onAdvance);
    }

    public void showBlackScreenWithText(String text, Color textColor, int fontSize, Runnable onAdvance) {
        inputLocked = true;

        StackPane overlay = new StackPane();
        overlay.setPrefSize(GAME_WIDTH, GAME_HEIGHT);

        Rectangle bg = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.BLACK);

        Text overlayText = new Text(text);
        overlayText.setFont(Font.font("华文中宋", fontSize));
        overlayText.setFill(textColor);
        overlayText.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        overlayText.setWrappingWidth(1000);
        overlayText.setLineSpacing(fontSize * 0.8);

        Text continueHint = new Text("点击任意处继续");
        continueHint.setFont(Font.font("华文中宋", 16));
        continueHint.setFill(Color.WHITE);

        VBox contentBox = new VBox(20);
        contentBox.setAlignment(javafx.geometry.Pos.CENTER);
        contentBox.getChildren().add(overlayText);

        overlay.getChildren().addAll(bg, contentBox, continueHint);
        StackPane.setAlignment(contentBox, javafx.geometry.Pos.CENTER);
        StackPane.setAlignment(continueHint, javafx.geometry.Pos.BOTTOM_CENTER);
        StackPane.setMargin(continueHint, new javafx.geometry.Insets(0, 0, 30, 0));

        getChildren().add(overlay);
        waitingForClick = true;
        onClickCallback = () -> {
            getChildren().remove(overlay);
            if (onAdvance != null) onAdvance.run();
        };
    }

    public void showBlackScreenTimed(long waitMs, Runnable onComplete) {
        inputLocked = true;
        Rectangle black = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.BLACK);
        black.setMouseTransparent(true);
        getChildren().add(black);

        PauseTransition wait = new PauseTransition(Duration.millis(waitMs));
        wait.setOnFinished(e -> {
            getChildren().remove(black);
            if (onComplete != null) onComplete.run();
        });
        wait.play();
    }

    private static final String CONTRACT_BG_PATH = "/images/ui/links.jpg";

    public void showContractScene(Runnable onComplete) {
        inputLocked = true;

        Pane scenePane = new Pane();
        scenePane.setPrefSize(GAME_WIDTH, GAME_HEIGHT);

        ImageView bgView = new ImageView();
        bgView.setFitWidth(GAME_WIDTH);
        bgView.setFitHeight(GAME_HEIGHT);
        bgView.setPreserveRatio(false);
        try {
            Image bgImg = resourceLoader.loadImage(CONTRACT_BG_PATH);
            bgView.setImage(bgImg);
        } catch (Exception e) {
            logger.warn("Contract background not found: {}, falling back to black", CONTRACT_BG_PATH);
            Rectangle blackBg = new Rectangle(GAME_WIDTH, GAME_HEIGHT);
            blackBg.setFill(Color.BLACK);
            scenePane.getChildren().add(blackBg);
        }
        if (bgView.getImage() != null) {
            scenePane.getChildren().add(bgView);
        }

        Text contractText = new Text();
        contractText.setFont(Font.font("华文中宋", 26));
        contractText.setFill(Color.WHITE);
        contractText.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        contractText.setLayoutX(GAME_WIDTH / 2 - 200);
        contractText.setLayoutY(GAME_HEIGHT / 2 - 13);
        contractText.setWrappingWidth(400);

        Text continueHint = new Text("点击任意处继续");
        continueHint.setFont(Font.font("华文中宋", 26));
        continueHint.setFill(Color.WHITE);
        continueHint.setLayoutX(GAME_WIDTH / 2 - 50);
        continueHint.setLayoutY(GAME_HEIGHT - 40);
        continueHint.setOpacity(0);

        scenePane.getChildren().addAll(contractText, continueHint);
        getChildren().add(scenePane);

        String fullText = "[契约缔结，从者现界]";
        javafx.animation.Timeline typewriter = new javafx.animation.Timeline();
        for (int i = 0; i < fullText.length(); i++) {
            final int idx = i;
            javafx.animation.KeyFrame kf = new javafx.animation.KeyFrame(
                    Duration.millis(120 * (i + 1)),
                    e -> contractText.setText(fullText.substring(0, idx + 1))
            );
            typewriter.getKeyFrames().add(kf);
        }

        typewriter.setOnFinished(e -> {
            FadeTransition fadeInHint = new FadeTransition(Duration.millis(400), continueHint);
            fadeInHint.setToValue(1.0);
            fadeInHint.play();
        });
        typewriter.play();

        waitingForClick = true;
        onClickCallback = () -> {
            getChildren().remove(scenePane);
            if (onComplete != null) onComplete.run();
        };
    }

    public void hideDialog() {
        dialogOverlay.setVisible(false);
        dialogOverlay.setMouseTransparent(true);
        dialogChoiceBox.getChildren().clear();
        inputLocked = false;
    }

    public void resetState() {
        hideDialog();
        stopGameLoop();
        interactionLayer.getChildren().clear();
        npcLayer.getChildren().clear();
        interactionZones.clear();
        npcSprites.clear();
        gameFlags.clear();
        inputLocked = false;
        waitingForClick = false;
        onClickCallback = null;
        cameraOffsetX = 0;
        cameraOffsetY = 0;
        hasMovedOnce = false;
        onFirstMoveCallback = null;
        com.game.rpg.view.component.AchievementPopup.reset();
        com.game.rpg.controller.battle.BattleSceneController.resetKillCount();

        getChildren().removeIf(node -> node instanceof Rectangle rect
                && rect.getWidth() == GAME_WIDTH && rect.getHeight() == GAME_HEIGHT
                && rect.getFill() == Color.BLACK);
    }

    public void unlockInput() {
        inputLocked = false;
    }

    public void lockInput() {
        inputLocked = true;
    }

    public void startGameLoop() {
        gameLoop.start();
    }

    public void stopGameLoop() {
        gameLoop.stop();
        pressedKeys.clear();
    }

    public void setFlag(String key, boolean value) {
        gameFlags.put(key, value);
    }

    public boolean getFlag(String key) {
        return gameFlags.getOrDefault(key, false);
    }

    public Map<String, Boolean> getGameFlags() {
        return gameFlags;
    }

    public void resetInteractionZone(String id) {
        for (InteractionZone zone : interactionZones) {
            if (zone.id.equals(id)) {
                zone.completed = false;
            }
        }
    }

    public void completeInteractionZone(String id) {
        for (InteractionZone zone : interactionZones) {
            if (zone.id.equals(id)) {
                zone.completed = true;
            }
        }
    }

    public void setPlayerPosition(double x, double y) {
        playerX = x;
        playerY = y;
        updateCamera();
        updatePlayerScreenPosition();
    }

    public double getPlayerX() {
        return playerX;
    }

    public double getPlayerY() {
        return playerY;
    }

    public void setSkinIndex(int index) {
        if (index >= 0 && index < SKIN_PATHS.length) {
            currentSkinIndex = index;
            updatePlayerSprite();
        }
    }

    public int getSkinIndex() {
        return currentSkinIndex;
    }

    public void showSkinUnlockHint(String skinName) {
        StackPane hintBox = new StackPane();
        hintBox.setLayoutX(20);
        hintBox.setLayoutY(20);
        hintBox.setPrefSize(260, 50);
        hintBox.setStyle("-fx-background-color: rgba(0, 0, 0, 0.7); -fx-background-radius: 8;");

        Text text = new Text("✨ 获得新外观: " + skinName);
        text.setFont(Font.font("华文中宋", 20));
        text.setFill(Color.valueOf("#FFD700"));

        hintBox.getChildren().add(text);
        hintBox.setOpacity(0);

        Pane hintLayer = null;
        for (var node : getChildren()) {
            if (node instanceof Pane p && "hintLayer".equals(p.getId())) {
                hintLayer = p;
                break;
            }
        }
        final Pane hintLayerRef = hintLayer;
        if (hintLayerRef != null) {
            hintLayerRef.getChildren().add(hintBox);
        } else {
            getChildren().add(hintBox);
        }

        FadeTransition fadeIn = new FadeTransition(Duration.millis(500), hintBox);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);

        PauseTransition hold = new PauseTransition(Duration.millis(3000));

        FadeTransition fadeOut = new FadeTransition(Duration.millis(800), hintBox);
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);
        fadeOut.setOnFinished(e -> {
            if (hintLayerRef != null) {
                hintLayerRef.getChildren().remove(hintBox);
            } else {
                getChildren().remove(hintBox);
            }
        });

        SequentialTransition seq = new SequentialTransition(fadeIn, hold, fadeOut);
        seq.play();
    }

    public SpriteManager getSpriteManager() {
        return spriteManager;
    }

    public void setCurrentMapId(String mapId) {
        this.currentMapId = mapId;
    }

    public String getCurrentMapId() {
        return currentMapId;
    }

    public Pane getMenuButtonLayer() {
        for (javafx.scene.Node node : getChildren()) {
            if (node instanceof Pane && "menuButtonLayer".equals(node.getId())) {
                return (Pane) node;
            }
        }
        return null;
    }

    public void setOnFirstMove(Runnable callback) {
        this.onFirstMoveCallback = callback;
    }

    private Image createPlaceholder(double w, double h) {
        javafx.scene.image.WritableImage placeholder = new javafx.scene.image.WritableImage((int) w, (int) h);
        var writer = placeholder.getPixelWriter();
        for (int py = 0; py < (int) h; py++) {
            for (int px = 0; px < (int) w; px++) {
                writer.setColor(px, py, Color.MAGENTA);
            }
        }
        return placeholder;
    }

    private static class InteractionZone {
        final String id;
        final TiledMapParser.CollisionRect rect;
        final Runnable onTrigger;
        final boolean oneShot;
        boolean completed;

        InteractionZone(String id, TiledMapParser.CollisionRect rect, Runnable onTrigger, boolean oneShot) {
            this.id = id;
            this.rect = rect;
            this.onTrigger = onTrigger;
            this.oneShot = oneShot;
            this.completed = false;
        }
    }

    private record NPCSprite(String id, double x, double y, ImageView view) {}

    public void showWhiteFlash(Runnable onComplete) {
        Rectangle whiteFlash = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.WHITE);
        whiteFlash.setOpacity(0);
        whiteFlash.setMouseTransparent(true);
        getChildren().add(whiteFlash);

        FadeTransition flashIn = new FadeTransition(Duration.millis(200), whiteFlash);
        flashIn.setFromValue(0.0);
        flashIn.setToValue(0.9);

        FadeTransition flashOut = new FadeTransition(Duration.millis(300), whiteFlash);
        flashOut.setFromValue(0.9);
        flashOut.setToValue(0.0);
        flashOut.setOnFinished(e -> {
            getChildren().remove(whiteFlash);
            if (onComplete != null) onComplete.run();
        });

        SequentialTransition seq = new SequentialTransition(flashIn, flashOut);
        seq.play();
    }

    public void playVideo(String videoPath, Runnable onFinished) {
        inputLocked = true;
        try {
            var url = getClass().getResource(videoPath);
            if (url == null) {
                logger.error("Video resource not found: {}", videoPath);
                inputLocked = false;
                if (onFinished != null) onFinished.run();
                return;
            }

            var media = new javafx.scene.media.Media(url.toExternalForm());
            var mediaPlayer = new javafx.scene.media.MediaPlayer(media);
            var mediaView = new javafx.scene.media.MediaView(mediaPlayer);
            mediaView.setFitWidth(GAME_WIDTH);
            mediaView.setFitHeight(GAME_HEIGHT);
            mediaView.setPreserveRatio(false);

            StackPane videoPane = new StackPane();
            videoPane.setPrefSize(GAME_WIDTH, GAME_HEIGHT);
            videoPane.getChildren().add(mediaView);
            getChildren().add(videoPane);

            mediaPlayer.setOnError(() -> {
                logger.error("MediaPlayer error: {}", mediaPlayer.getError());
                mediaPlayer.dispose();
                getChildren().remove(videoPane);
                inputLocked = false;
                if (onFinished != null) onFinished.run();
            });

            mediaPlayer.setOnEndOfMedia(() -> {
                mediaPlayer.dispose();
                getChildren().remove(videoPane);
                inputLocked = false;
                if (onFinished != null) onFinished.run();
            });

            mediaPlayer.setAutoPlay(true);
        } catch (Exception e) {
            logger.error("Failed to play video: {}", videoPath, e);
            inputLocked = false;
            if (onFinished != null) onFinished.run();
        }
    }

    public void fadeToBlack(Runnable onComplete) {
        inputLocked = true;

        Rectangle black = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.BLACK);
        black.setOpacity(0);
        black.setMouseTransparent(true);
        getChildren().add(black);

        FadeTransition fadeIn = new FadeTransition(Duration.millis(500), black);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        fadeIn.setOnFinished(e -> {
            if (onComplete != null) onComplete.run();
        });
        fadeIn.play();
    }

    public void fadeInFromBlack(Runnable onComplete) {
        Rectangle black = null;
        for (var node : getChildren()) {
            if (node instanceof Rectangle rect
                    && rect.getWidth() == GAME_WIDTH && rect.getHeight() == GAME_HEIGHT
                    && rect.getFill() == Color.BLACK && rect.getOpacity() >= 0.99) {
                black = rect;
                break;
            }
        }

        if (black == null) {
            black = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.BLACK);
            black.setOpacity(1.0);
            black.setMouseTransparent(true);
            getChildren().add(black);
        }

        Rectangle finalBlack = black;
        FadeTransition fadeOut = new FadeTransition(Duration.millis(500), finalBlack);
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);
        fadeOut.setOnFinished(e -> {
            getChildren().remove(finalBlack);
            if (onComplete != null) onComplete.run();
        });
        fadeOut.play();
    }

    public void showCGWithFadeIn(String imagePath, Runnable onAdvance) {
        inputLocked = true;

        StackPane overlay = new StackPane();
        overlay.setPrefSize(GAME_WIDTH, GAME_HEIGHT);

        ImageView cgView = new ImageView();
        try {
            Image img = resourceLoader.loadImage(imagePath);
            cgView.setImage(img);
            cgView.setFitWidth(GAME_WIDTH);
            cgView.setFitHeight(GAME_HEIGHT);
            cgView.setPreserveRatio(true);
        } catch (Exception e) {
            logger.warn("Failed to load CG image: {}", imagePath, e);
            Rectangle placeholder = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.MAGENTA);
            overlay.getChildren().add(placeholder);
        }

        overlay.getChildren().add(cgView);
        overlay.setOpacity(0);
        getChildren().add(overlay);

        FadeTransition fadeIn = new FadeTransition(Duration.millis(1000), overlay);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        fadeIn.setOnFinished(e -> {
            waitingForClick = true;
            onClickCallback = () -> {
                getChildren().remove(overlay);
                if (onAdvance != null) onAdvance.run();
            };
        });
        fadeIn.play();
    }

    public void showEndingScreen(String imagePath, String creditsText, Runnable onFinished) {
        inputLocked = true;

        StackPane overlay = new StackPane();
        overlay.setPrefSize(GAME_WIDTH, GAME_HEIGHT);

        ImageView bgView = new ImageView();
        try {
            Image img = resourceLoader.loadImage(imagePath);
            bgView.setImage(img);
            bgView.setFitWidth(GAME_WIDTH);
            bgView.setFitHeight(GAME_HEIGHT);
            bgView.setPreserveRatio(true);
        } catch (Exception e) {
            logger.warn("Failed to load ending image: {}", imagePath, e);
            Rectangle placeholder = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.MAGENTA);
            overlay.getChildren().add(placeholder);
        }

        overlay.getChildren().add(bgView);

        Text credits = new Text(creditsText);
        credits.setFont(Font.font("STSong", 20));
        credits.setFill(Color.WHITE);
        credits.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);
        overlay.getChildren().add(credits);

        Text hint = new Text("点击任意处结束");
        hint.setFont(Font.font("STSong", 16));
        hint.setFill(Color.WHITE);
        StackPane.setAlignment(hint, javafx.geometry.Pos.BOTTOM_CENTER);
        StackPane.setMargin(hint, new javafx.geometry.Insets(0, 0, 30, 0));
        overlay.getChildren().add(hint);

        overlay.setOpacity(0);
        getChildren().add(overlay);

        FadeTransition fadeIn = new FadeTransition(Duration.millis(500), overlay);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        fadeIn.setOnFinished(e -> {
            overlay.setOnMouseClicked(ev -> {
                getChildren().remove(overlay);
                if (onFinished != null) onFinished.run();
            });
        });
        fadeIn.play();
    }

    public void transitionToMap(String mapImagePath, String tmjPath, double spawnX, double spawnY, Runnable onComplete) {
        inputLocked = true;

        Rectangle black = new Rectangle(GAME_WIDTH, GAME_HEIGHT, Color.BLACK);
        black.setOpacity(0);
        black.setMouseTransparent(true);
        getChildren().add(black);

        FadeTransition fadeIn = new FadeTransition(Duration.millis(500), black);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        fadeIn.setOnFinished(e -> {
            loadMap(mapImagePath, tmjPath, spawnX, spawnY);

            FadeTransition fadeOut = new FadeTransition(Duration.millis(500), black);
            fadeOut.setFromValue(1.0);
            fadeOut.setToValue(0.0);
            fadeOut.setOnFinished(ev -> {
                getChildren().remove(black);
                if (onComplete != null) onComplete.run();
            });
            fadeOut.play();
        });
        fadeIn.play();
    }
}
