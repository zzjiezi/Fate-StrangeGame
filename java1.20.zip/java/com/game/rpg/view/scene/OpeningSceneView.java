package com.game.rpg.view.scene;

import com.game.rpg.controller.story.StoryController;
import com.game.rpg.util.resource.ResourceLoader;
import javafx.animation.FadeTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.util.Duration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class OpeningSceneView extends StackPane {
    private static final Logger logger = LoggerFactory.getLogger(OpeningSceneView.class);

    private static final int WINDOW_WIDTH = 800;
    private static final int WINDOW_HEIGHT = 600;
    private static final Duration TRANSITION_DURATION = Duration.seconds(3);

    private final ResourceLoader resourceLoader;
    private final StoryController storyController;

    private ImageView backgroundView;
    private ImageView blackBackgroundView;
    private Rectangle whiteFlashOverlay;
    private Text centerText;
    private VBox choiceBox;

    private int sleepCount = 0;
    private int choiceStep = 0;
    private Runnable onClickCallback;
    private boolean waitingForClick = false;
    private Runnable onSequenceComplete;

    public OpeningSceneView(ResourceLoader resourceLoader, StoryController storyController) {
        this.resourceLoader = resourceLoader;
        this.storyController = storyController;

        setPrefSize(WINDOW_WIDTH, WINDOW_HEIGHT);
        initializeUI();
        setupClickHandler();
    }

    private void initializeUI() {
        backgroundView = loadBackgroundImage("/images/ui/背景.png");
        blackBackgroundView = loadBackgroundImage("/images/ui/黑底背景.jpg");
        blackBackgroundView.setOpacity(0);

        whiteFlashOverlay = new Rectangle(WINDOW_WIDTH, WINDOW_HEIGHT, Color.WHITE);
        whiteFlashOverlay.setOpacity(0);
        whiteFlashOverlay.setMouseTransparent(true);

        centerText = new Text();
        centerText.setFont(Font.font("SimSun", 20));
        centerText.setFill(Color.WHITE);
        centerText.setOpacity(0);
        centerText.setMouseTransparent(true);
        centerText.setWrappingWidth(700);
        centerText.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);

        choiceBox = new VBox(15);
        choiceBox.setOpacity(0);
        choiceBox.setStyle("-fx-alignment: center;");

        getChildren().addAll(backgroundView, blackBackgroundView, whiteFlashOverlay, centerText, choiceBox);

        StackPane.setAlignment(centerText, javafx.geometry.Pos.CENTER);
        StackPane.setAlignment(choiceBox, javafx.geometry.Pos.CENTER);

        logger.info("Opening scene view initialized");
    }

    private void setupClickHandler() {
        setOnMouseClicked(e -> {
            if (waitingForClick && e.getButton() == MouseButton.PRIMARY) {
                waitingForClick = false;
                if (onClickCallback != null) {
                    Runnable cb = onClickCallback;
                    onClickCallback = null;
                    cb.run();
                }
            }
        });
    }

    private ImageView loadBackgroundImage(String path) {
        try {
            Image image = resourceLoader.loadImage(path);
            ImageView imageView = new ImageView(image);
            imageView.setFitWidth(WINDOW_WIDTH);
            imageView.setFitHeight(WINDOW_HEIGHT);
            imageView.setPreserveRatio(false);
            return imageView;
        } catch (Exception e) {
            logger.warn("Failed to load background image: {}", path, e);
            ImageView fallback = new ImageView();
            fallback.setFitWidth(WINDOW_WIDTH);
            fallback.setFitHeight(WINDOW_HEIGHT);
            return fallback;
        }
    }

    public void startOpeningSequence() {
        FadeTransition fadeOutBackground = new FadeTransition(TRANSITION_DURATION, backgroundView);
        fadeOutBackground.setFromValue(1.0);
        fadeOutBackground.setToValue(0.0);

        FadeTransition fadeInBlack = new FadeTransition(TRANSITION_DURATION, blackBackgroundView);
        fadeInBlack.setFromValue(0.0);
        fadeInBlack.setToValue(1.0);

        ParallelTransition transition = new ParallelTransition(fadeOutBackground, fadeInBlack);
        transition.setOnFinished(e -> showWhiteFlash());
        transition.play();
    }

    private void showWhiteFlash() {
        FadeTransition flashIn = new FadeTransition(Duration.millis(200), whiteFlashOverlay);
        flashIn.setFromValue(0.0);
        flashIn.setToValue(1.0);

        PauseTransition flashHold = new PauseTransition(Duration.millis(300));

        FadeTransition flashOut = new FadeTransition(Duration.millis(400), whiteFlashOverlay);
        flashOut.setFromValue(1.0);
        flashOut.setToValue(0.0);

        SequentialTransition flash = new SequentialTransition(flashIn, flashHold, flashOut);
        flash.setOnFinished(e -> showSecondText());
        flash.play();
    }

    private void showSecondText() {
        showTextAndWaitForClick("这是......", () -> fadeOutTextAndThen(() -> showFirstChoice()));
    }

    private void showTextAndWaitForClick(String text, Runnable onAdvance) {
        centerText.setText(text);
        centerText.setOpacity(0);

        FadeTransition fadeIn = new FadeTransition(Duration.seconds(0.5), centerText);
        fadeIn.setFromValue(0.0);
        fadeIn.setToValue(1.0);
        fadeIn.setOnFinished(e -> {
            waitingForClick = true;
            onClickCallback = onAdvance;
        });
        fadeIn.play();
    }

    private void fadeOutTextAndThen(Runnable then) {
        waitingForClick = false;
        FadeTransition fadeOut = new FadeTransition(Duration.seconds(0.5), centerText);
        fadeOut.setFromValue(1.0);
        fadeOut.setToValue(0.0);
        fadeOut.setOnFinished(e -> then.run());
        fadeOut.play();
    }

    private void showFirstChoice() {
        choiceStep = 1;
        showChoiceBox(List.of("管他呢，继续睡觉", "起床"), index -> {
            if (index == 0) {
                handleSleepChoice1();
            } else {
                handleWakeUp();
            }
        });
    }

    private void showSecondChoice() {
        choiceStep = 2;
        showChoiceBox(List.of("管他呢，继续睡觉", "起床"), index -> {
            if (index == 0) {
                handleSleepChoice2();
            } else {
                handleWakeUp();
            }
        });
    }

    private void showThirdChoice() {
        choiceStep = 3;
        showChoiceBox(List.of("继续睡觉", "起床"), index -> {
            if (index == 0) {
                handleSleepChoice3();
            } else {
                handleWakeUp();
            }
        });
    }

    private void showFourthChoice() {
        choiceStep = 4;
        showChoiceBox(List.of("起床"), index -> handleWakeUp());
    }

    private void showChoiceBox(List<String> choices, java.util.function.Consumer<Integer> onSelected) {
        choiceBox.getChildren().clear();
        choiceBox.setOpacity(1);

        List<Button> buttons = new ArrayList<>();
        for (int i = 0; i < choices.size(); i++) {
            final int choiceIndex = i;
            Button btn = new Button(choices.get(i));
            btn.setFont(Font.font("SimSun", 18));
            btn.setPrefWidth(300);
            btn.setStyle("-fx-background-color: rgba(40, 40, 40, 0.9); -fx-text-fill: white; " +
                    "-fx-border-color: #5a5a5a; -fx-border-width: 2; -fx-padding: 10 20; " +
                    "-fx-cursor: hand;");

            btn.setOnMouseEntered(e -> btn.setStyle(
                    "-fx-background-color: rgba(60, 60, 60, 0.9); -fx-text-fill: cyan; " +
                            "-fx-border-color: cyan; -fx-border-width: 2; -fx-padding: 10 20; " +
                            "-fx-cursor: hand;"));

            btn.setOnMouseExited(e -> btn.setStyle(
                    "-fx-background-color: rgba(40, 40, 40, 0.9); -fx-text-fill: white; " +
                            "-fx-border-color: #5a5a5a; -fx-border-width: 2; -fx-padding: 10 20; " +
                            "-fx-cursor: hand;"));

            btn.setOnAction(e -> {
                hideChoiceBox();
                onSelected.accept(choiceIndex);
            });

            buttons.add(btn);
        }

        choiceBox.getChildren().addAll(buttons);
    }

    private void hideChoiceBox() {
        choiceBox.setOpacity(0);
        choiceBox.getChildren().clear();
    }

    private void handleSleepChoice1() {
        sleepCount++;
        storyController.incrementSleepCount();
        showTextAndWaitForClick(
                "（你从未觉得眼皮如此沉重, 还好这里没有在早上八点半开始的什么课需要你,继续睡会儿吧……）",
                () -> fadeOutTextAndThen(() -> showSecondChoice())
        );
    }

    private void handleSleepChoice2() {
        sleepCount++;
        storyController.incrementSleepCount();
        showTextAndWaitForClick(
                "还是好困,昨晚是多久睡的来着……算了,不重要,我只想继续拥抱我的床……",
                () -> fadeOutTextAndThen(() -> showThirdChoice())
        );
    }

    private void handleSleepChoice3() {
        sleepCount++;
        storyController.incrementSleepCount();
        showTextAndWaitForClick(
                "（你是如此疲惫, 于是一直睡到宇宙大道都磨灭了……）",
                () -> fadeOutTextAndThen(() -> showAchievement())
        );
    }

    private void showAchievement() {
        centerText.setOpacity(0);
        com.game.rpg.view.component.AchievementPopup.unlockSleepWar();
        centerText.setText("[获得成就:昏睡战争](获得条件:选择继续睡觉3次)");
        centerText.setFill(Color.GOLD);

        FadeTransition flashIn = new FadeTransition(Duration.millis(100), centerText);
        flashIn.setFromValue(0.0);
        flashIn.setToValue(1.0);

        PauseTransition flashHold = new PauseTransition(Duration.millis(100));

        FadeTransition flashOut = new FadeTransition(Duration.millis(100), centerText);
        flashOut.setFromValue(1.0);
        flashOut.setToValue(0.0);

        PauseTransition flashPause = new PauseTransition(Duration.millis(100));

        FadeTransition finalIn = new FadeTransition(Duration.millis(100), centerText);
        finalIn.setFromValue(0.0);
        finalIn.setToValue(1.0);

        playAchievementSfx();

        SequentialTransition flashSequence = new SequentialTransition(flashIn, flashHold, flashOut, flashPause, finalIn);
        flashSequence.setOnFinished(e -> {
            waitingForClick = true;
            onClickCallback = () -> fadeOutTextAndThen(() -> {
                centerText.setFill(Color.WHITE);
                showFourthChoice();
            });
        });
        flashSequence.play();
    }

    private void playAchievementSfx() {
        try {
            resourceLoader.loadAudio("/audio/sfx/achievement.wav", false).play();
        } catch (Exception e) {
            logger.warn("Achievement SFX not available, skipping");
        }
    }

    private void handleWakeUp() {
        centerText.setOpacity(0);
        centerText.setFill(Color.WHITE);
        showTextAndWaitForClick("（该起床了,睁开眼）", () -> {
            logger.info("Opening sequence completed, player chose to wake up");
            if (onSequenceComplete != null) {
                onSequenceComplete.run();
            }
        });
    }

    public void setOnSequenceComplete(Runnable onSequenceComplete) {
        this.onSequenceComplete = onSequenceComplete;
    }
}
