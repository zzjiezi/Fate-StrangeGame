package com.game.rpg.view.component;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.util.ArrayList;
import java.util.List;

public class AchievementPopup {
    private static boolean ashGathererUnlocked = false;
    private static boolean grailWarVictorUnlocked = false;
    private static boolean sleepWarUnlocked = false;

    private static final String ASH_GATHERER_NAME = "拾烬者";
    private static final String GRAIL_WAR_VICTOR_NAME = "圣杯战争最终胜利者";
    private static final String SLEEP_WAR_NAME = "昏睡战争";

    public static boolean isAshGathererUnlocked() {
        return ashGathererUnlocked;
    }

    public static void unlockGrailWarVictor() {
        grailWarVictorUnlocked = true;
    }

    public static boolean isGrailWarVictorUnlocked() {
        return grailWarVictorUnlocked;
    }

    public static void unlockSleepWar() {
        sleepWarUnlocked = true;
    }

    public static boolean isSleepWarUnlocked() {
        return sleepWarUnlocked;
    }

    public static List<String> getUnlockedAchievementNames() {
        List<String> names = new ArrayList<>();
        if (sleepWarUnlocked) names.add(SLEEP_WAR_NAME);
        if (ashGathererUnlocked) names.add(ASH_GATHERER_NAME);
        if (grailWarVictorUnlocked) names.add(GRAIL_WAR_VICTOR_NAME);
        return names;
    }

    public static void reset() {
        ashGathererUnlocked = false;
        grailWarVictorUnlocked = false;
        sleepWarUnlocked = false;
    }

    public static void show(Stage ownerStage) {
        if (ashGathererUnlocked) {
            return;
        }
        ashGathererUnlocked = true;

        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.initOwner(ownerStage);
        popupStage.initStyle(StageStyle.UNDECORATED);
        popupStage.setWidth(1280);
        popupStage.setHeight(720);

        VBox root = new VBox(10);
        root.setAlignment(Pos.CENTER);
        root.setPrefSize(1280, 720);
        root.setStyle("-fx-background-color: #000000;");

        Label title = new Label("获得成就：【拾烬者】");
        title.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 24));
        title.setStyle("-fx-text-fill: #e6b800; -fx-alignment: center;");
        title.setTextAlignment(TextAlignment.CENTER);

        Label emptyLine = new Label("");

        Label line1 = new Label("散落尘世的百枚残烬，在汝掌心重新相认。");
        line1.setFont(Font.font("Microsoft YaHei", 16));
        line1.setStyle("-fx-text-fill: #cccccc; -fx-alignment: center;");
        line1.setTextAlignment(TextAlignment.CENTER);

        Label line2 = new Label("星火自灰烬中抬头——星坠·劫烬 已成。");
        line2.setFont(Font.font("Microsoft YaHei", 16));
        line2.setStyle("-fx-text-fill: #cccccc; -fx-alignment: center;");
        line2.setTextAlignment(TextAlignment.CENTER);

        HBox line3Box = new HBox();
        line3Box.setAlignment(Pos.CENTER);
        Label line3Pre = new Label("从此，你是");
        line3Pre.setFont(Font.font("Microsoft YaHei", 16));
        line3Pre.setStyle("-fx-text-fill: #cccccc;");
        Label line3Bold = new Label("拾烬之人");
        line3Bold.setFont(Font.font("Microsoft YaHei", FontWeight.BOLD, 16));
        line3Bold.setStyle("-fx-text-fill: #cccccc;");
        line3Box.getChildren().addAll(line3Pre, line3Bold);

        root.getChildren().addAll(title, emptyLine, line1, line2, line3Box);

        Scene scene = new Scene(root);
        popupStage.setScene(scene);

        root.setOnMouseClicked(e -> popupStage.close());

        popupStage.showAndWait();
    }
}